// Assets/Editor/Poly_Ling_/Core/Commands/SelectionCommands.cs
// 選択操作のコマンド化（頂点/面/辺/メッシュ）
// Phase 4: SelectionSnapshot版に統一

using System;
using System.Collections.Generic;
using Poly_Ling.UndoSystem;
using Poly_Ling.Selection;
using Poly_Ling.Tools;
using Poly_Ling.Commands;
using Poly_Ling.Context;

namespace Poly_Ling.Commands
{
    /// <summary>
    /// 選択変更記録コマンド（SelectionSnapshot版 — 推奨）
    /// </summary>
    public class RecordSelectionChangeSnapshotCommand : ICommand
    {
        private readonly MeshUndoController _controller;
        private readonly SelectionSnapshot _oldSnapshot;
        private readonly SelectionSnapshot _newSnapshot;
        private readonly WorkPlaneSnapshot? _oldWorkPlane;
        private readonly WorkPlaneSnapshot? _newWorkPlane;

        public string Description => "Record Selection Change";
        public MeshUpdateLevel UpdateLevel => MeshUpdateLevel.Selection;

        public RecordSelectionChangeSnapshotCommand(
            MeshUndoController controller,
            SelectionSnapshot oldSnapshot,
            SelectionSnapshot newSnapshot,
            WorkPlaneSnapshot? oldWorkPlane = null,
            WorkPlaneSnapshot? newWorkPlane = null)
        {
            _controller = controller;
            _oldSnapshot = oldSnapshot?.Clone();
            _newSnapshot = newSnapshot?.Clone();
            _oldWorkPlane = oldWorkPlane;
            _newWorkPlane = newWorkPlane;
        }

        public void Execute()
        {
            _controller?.RecordSelectionChangeInternal(
                _oldSnapshot, _newSnapshot, _oldWorkPlane, _newWorkPlane);
        }
    }

    /// <summary>
    /// 頂点/面選択変更記録コマンド（後方互換: HashSet版）
    /// </summary>
    public class RecordSelectionChangeCommand : ICommand
    {
        private readonly MeshUndoController _controller;
        private readonly HashSet<int> _oldVertices;
        private readonly HashSet<int> _newVertices;
        private readonly HashSet<int> _oldFaces;
        private readonly HashSet<int> _newFaces;
        private readonly WorkPlaneSnapshot? _oldWorkPlane;
        private readonly WorkPlaneSnapshot? _newWorkPlane;

        public string Description => "Record Selection Change";
        public MeshUpdateLevel UpdateLevel => MeshUpdateLevel.Selection;

        public RecordSelectionChangeCommand(
            MeshUndoController controller,
            HashSet<int> oldVertices,
            HashSet<int> newVertices,
            HashSet<int> oldFaces = null,
            HashSet<int> newFaces = null)
        {
            _controller = controller;
            _oldVertices = oldVertices != null ? new HashSet<int>(oldVertices) : null;
            _newVertices = newVertices != null ? new HashSet<int>(newVertices) : null;
            _oldFaces = oldFaces != null ? new HashSet<int>(oldFaces) : null;
            _newFaces = newFaces != null ? new HashSet<int>(newFaces) : null;
            _oldWorkPlane = null;
            _newWorkPlane = null;
        }

        public RecordSelectionChangeCommand(
            MeshUndoController controller,
            HashSet<int> oldVertices,
            HashSet<int> newVertices,
            WorkPlaneSnapshot? oldWorkPlane,
            WorkPlaneSnapshot? newWorkPlane,
            HashSet<int> oldFaces = null,
            HashSet<int> newFaces = null)
        {
            _controller = controller;
            _oldVertices = oldVertices != null ? new HashSet<int>(oldVertices) : null;
            _newVertices = newVertices != null ? new HashSet<int>(newVertices) : null;
            _oldFaces = oldFaces != null ? new HashSet<int>(oldFaces) : null;
            _newFaces = newFaces != null ? new HashSet<int>(newFaces) : null;
            _oldWorkPlane = oldWorkPlane;
            _newWorkPlane = newWorkPlane;
        }

        public void Execute()
        {
            if (_controller == null) return;

            if (_oldWorkPlane.HasValue || _newWorkPlane.HasValue)
            {
                _controller.RecordSelectionChangeWithWorkPlaneInternal(
                    _oldVertices, _newVertices,
                    _oldWorkPlane, _newWorkPlane,
                    _oldFaces, _newFaces);
            }
            else
            {
                _controller.RecordSelectionChangeInternal(_oldVertices, _newVertices, _oldFaces, _newFaces);
            }
        }
    }

    /// <summary>
    /// メッシュ選択変更記録コマンド
    /// </summary>
    public class RecordMeshSelectionChangeCommand : ICommand
    {
        private readonly MeshUndoController _controller;
        private readonly int _oldIndex;
        private readonly int _newIndex;
        private readonly CameraSnapshot? _oldCamera;
        private readonly CameraSnapshot? _newCamera;

        public string Description => "Record Mesh Selection Change";
        public MeshUpdateLevel UpdateLevel => MeshUpdateLevel.Selection;

        public RecordMeshSelectionChangeCommand(
            MeshUndoController controller,
            int oldIndex,
            int newIndex,
            CameraSnapshot? oldCamera = null,
            CameraSnapshot? newCamera = null)
        {
            _controller = controller;
            _oldIndex = oldIndex;
            _newIndex = newIndex;
            _oldCamera = oldCamera;
            _newCamera = newCamera;
        }

        public void Execute()
        {
            if (_controller == null) return;

            var oldIndices = _oldIndex >= 0 ? new List<int> { _oldIndex } : new List<int>();
            var newIndices = _newIndex >= 0 ? new List<int> { _newIndex } : new List<int>();

            if (_oldCamera.HasValue || _newCamera.HasValue)
            {
                _controller.RecordMeshSelectionChangeInternal(oldIndices, newIndices, _oldCamera, _newCamera);
            }
            else
            {
                _controller.RecordMeshSelectionChangeInternal(oldIndices, newIndices);
            }
        }
    }
}
