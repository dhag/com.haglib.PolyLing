// Assets/Editor/UndoSystem/MeshEditor/Records/MeshUndoRecord_Base.cs
// メッシュ編集用Undo記録の基底クラスと基本的な移動操作

using System.Collections.Generic;
using UnityEngine;
using Poly_Ling.Data;
using Poly_Ling.Model;

namespace Poly_Ling.UndoSystem
{
    // ============================================================
    // 更新レベル定義
    // ============================================================

    /// <summary>
    /// Undo/Redo後に必要な更新レベル
    /// 数字が大きいほど重い処理
    /// </summary>
    public enum MeshUpdateLevel
    {
        None = 0,       // 更新不要
        Selection = 3,  // 選択フラグのみ
        Position = 4,   // 頂点位置のみ（0.5〜2秒 @10M頂点）
        Topology = 5    // フル更新（5〜20秒 @10M頂点）
    }

    // ============================================================
    // Undo記録の基底
    // ============================================================

    /// <summary>
    /// メッシュ編集用Undo記録の基底クラス
    /// </summary>
    public abstract class MeshUndoRecord : IUndoRecord<MeshUndoContext>
    {
        public UndoOperationInfo Info { get; set; }
        public abstract void Undo(MeshUndoContext context);
        public abstract void Redo(MeshUndoContext context);

        /// <summary>
        /// この操作のUndo/Redo後に必要な更新レベル
        /// デフォルトはTopology（フル更新）- 安全側に倒す
        /// </summary>
        public virtual MeshUpdateLevel RequiredUpdateLevel => MeshUpdateLevel.Topology;

        /// <summary>
        /// ctx.MaterialOwner.GetMeshContext(index) のヘルパー。nullガード付き。
        /// </summary>
        protected static MeshContext ResolveMesh(MeshUndoContext ctx, int meshContextIndex)
        {
            return ctx.MaterialOwner?.GetMeshContext(meshContextIndex);
        }
    }

    // ============================================================
    // 頂点移動記録
    // ============================================================

    /// <summary>
    /// 頂点移動記録（軽量）
    /// Vertexインデックスと位置のみを保存
    /// </summary>
    public class VertexMoveRecord : MeshUndoRecord
    {
        /// <summary>操作対象メッシュのModelContext内インデックス</summary>
        public int MeshContextIndex;

        public int[] Indices;
        public Vector3[] OldPositions;
        public Vector3[] NewPositions;

        /// <summary>
        /// 頂点移動はLevel 4（位置のみ更新）で済む
        /// </summary>
        public override MeshUpdateLevel RequiredUpdateLevel => MeshUpdateLevel.Position;
        //public Vector3[] NewPositions;

        public VertexMoveRecord(int[] indices, Vector3[] oldPositions, Vector3[] newPositions)
        {
            Indices = indices;
            OldPositions = oldPositions;
            NewPositions = newPositions;
        }

        public override void Undo(MeshUndoContext ctx)
        {
            var mc = ResolveMesh(ctx, MeshContextIndex);
            if (mc == null) return;

            for (int i = 0; i < Indices.Length; i++)
            {
                mc.SetVertexPosition(Indices[i], OldPositions[i]);
            }
            ctx.DirtyMeshIndices.Add(MeshContextIndex);
        }

        public override void Redo(MeshUndoContext ctx)
        {
            var mc = ResolveMesh(ctx, MeshContextIndex);
            if (mc == null) return;

            for (int i = 0; i < Indices.Length; i++)
            {
                mc.SetVertexPosition(Indices[i], NewPositions[i]);
            }
            ctx.DirtyMeshIndices.Add(MeshContextIndex);
        }
    }

    /// <summary>
    /// 頂点グループ移動記録（グループ化された頂点用）
    /// 新構造ではVertexがグループに相当
    /// </summary>
    public class VertexGroupMoveRecord : MeshUndoRecord
    {
        /// <summary>操作対象メッシュのModelContext内インデックス</summary>
        public int MeshContextIndex;

        public List<int>[] Groups;  // グループごとの頂点インデックス
        public Vector3[] OldOffsets;
        public Vector3[] NewOffsets;
        public Vector3[] OriginalPositions;  // 元の頂点位置

        /// <summary>
        /// 頂点グループ移動もLevel 4（位置のみ更新）で済む
        /// </summary>
        public override MeshUpdateLevel RequiredUpdateLevel => MeshUpdateLevel.Position;

        public VertexGroupMoveRecord(
            List<int>[] groups,
            Vector3[] oldOffsets,
            Vector3[] newOffsets,
            Vector3[] originalPositions)
        {
            Groups = groups;
            OldOffsets = oldOffsets;
            NewOffsets = newOffsets;
            OriginalPositions = originalPositions;
        }

        public override void Undo(MeshUndoContext ctx)
        {
            ApplyOffsets(ctx, OldOffsets);
        }

        public override void Redo(MeshUndoContext ctx)
        {
            ApplyOffsets(ctx, NewOffsets);
        }

        private void ApplyOffsets(MeshUndoContext ctx, Vector3[] offsets)
        {
            var mc = ResolveMesh(ctx, MeshContextIndex);
            if (mc == null) return;

            for (int g = 0; g < Groups.Length; g++)
            {
                foreach (int vi in Groups[g])
                {
                    if (vi < mc.VertexCount && vi < OriginalPositions.Length)
                    {
                        mc.SetVertexPosition(vi, OriginalPositions[vi] + offsets[g]);
                    }
                }
            }
            ctx.DirtyMeshIndices.Add(MeshContextIndex);
        }
    }

    // ============================================================
    // 頂点UV/法線変更記録
    // ============================================================

    /// <summary>
    /// 頂点UV変更記録
    /// </summary>
    public class VertexUVChangeRecord : MeshUndoRecord
    {
        /// <summary>操作対象メッシュのModelContext内インデックス</summary>
        public int MeshContextIndex;

        public int VertexIndex;
        public int UVIndex;
        public Vector2 OldUV;
        public Vector2 NewUV;

        public VertexUVChangeRecord(int vertexIndex, int uvIndex, Vector2 oldUV, Vector2 newUV)
        {
            VertexIndex = vertexIndex;
            UVIndex = uvIndex;
            OldUV = oldUV;
            NewUV = newUV;
        }

        public override void Undo(MeshUndoContext ctx)
        {
            var mc = ResolveMesh(ctx, MeshContextIndex);
            if (mc?.MeshObject != null && VertexIndex < mc.MeshObject.VertexCount)
            {
                var vertex = mc.MeshObject.Vertices[VertexIndex];
                if (UVIndex < vertex.UVs.Count)
                    vertex.UVs[UVIndex] = OldUV;
            }
            ctx.DirtyMeshIndices.Add(MeshContextIndex);
        }

        public override void Redo(MeshUndoContext ctx)
        {
            var mc = ResolveMesh(ctx, MeshContextIndex);
            if (mc?.MeshObject != null && VertexIndex < mc.MeshObject.VertexCount)
            {
                var vertex = mc.MeshObject.Vertices[VertexIndex];
                if (UVIndex < vertex.UVs.Count)
                    vertex.UVs[UVIndex] = NewUV;
            }
            ctx.DirtyMeshIndices.Add(MeshContextIndex);
        }
    }

    // ============================================================
    // ボーンウェイト変更記録
    // ============================================================

    /// <summary>
    /// ボーンウェイト変更記録
    /// </summary>
    public class BoneWeightChangeRecord : MeshUndoRecord
    {
        /// <summary>操作対象メッシュのModelContext内インデックス</summary>
        public int MeshContextIndex;

        public int[] Indices;
        public BoneWeight?[] OldWeights;
        public BoneWeight?[] NewWeights;

        public BoneWeightChangeRecord(int[] indices, BoneWeight?[] oldWeights, BoneWeight?[] newWeights)
        {
            Indices = indices;
            OldWeights = oldWeights;
            NewWeights = newWeights;
        }

        public override void Undo(MeshUndoContext ctx)
        {
            ApplyWeights(ctx, OldWeights);
        }

        public override void Redo(MeshUndoContext ctx)
        {
            ApplyWeights(ctx, NewWeights);
        }

        private void ApplyWeights(MeshUndoContext ctx, BoneWeight?[] weights)
        {
            var mc = ResolveMesh(ctx, MeshContextIndex);
            if (mc?.MeshObject == null) return;

            for (int i = 0; i < Indices.Length; i++)
            {
                int idx = Indices[i];
                if (idx >= 0 && idx < mc.MeshObject.VertexCount)
                {
                    mc.MeshObject.Vertices[idx].BoneWeight = weights[i];
                }
            }
            ctx.DirtyMeshIndices.Add(MeshContextIndex);
        }
    }

    // ============================================================
    // 複数メッシュ頂点移動記録
    // ============================================================

    /// <summary>
    /// メッシュ頂点移動エントリ（全メッシュ対等）
    /// </summary>
    public struct MeshMoveEntry
    {
        public int MeshContextIndex;
        public int[] Indices;
        public Vector3[] OldPositions;
        public Vector3[] NewPositions;
    }

    /// <summary>
    /// 複数メッシュ対応の頂点移動記録
    /// 全メッシュを対等に扱う。プライマリ/セカンダリの区別なし。
    /// </summary>
    public class MultiMeshVertexMoveRecord : MeshUndoRecord
    {
        public MeshMoveEntry[] Entries;

        public override MeshUpdateLevel RequiredUpdateLevel => MeshUpdateLevel.Position;

        public MultiMeshVertexMoveRecord(MeshMoveEntry[] entries)
        {
            Entries = entries;
        }

        public override void Undo(MeshUndoContext ctx)
        {
            ApplyPositions(ctx, isUndo: true);
        }

        public override void Redo(MeshUndoContext ctx)
        {
            ApplyPositions(ctx, isUndo: false);
        }

        private void ApplyPositions(MeshUndoContext ctx, bool isUndo)
        {
            if (Entries == null || Entries.Length == 0)
                return;

            var model = ctx.MaterialOwner;
            if (model == null)
                return;

            ctx.DirtyMeshIndices.Clear();

            for (int e = 0; e < Entries.Length; e++)
            {
                var entry = Entries[e];
                var meshContext = model.GetMeshContext(entry.MeshContextIndex);
                if (meshContext?.MeshObject == null)
                    continue;

                var meshObject = meshContext.MeshObject;
                var positions = isUndo ? entry.OldPositions : entry.NewPositions;

                for (int i = 0; i < entry.Indices.Length; i++)
                {
                    int idx = entry.Indices[i];
                    if (idx >= 0 && idx < meshObject.VertexCount)
                    {
                        meshObject.Vertices[idx].Position = positions[i];
                    }
                }
                meshObject.InvalidatePositionCache();

                // OriginalPositions更新
                if (meshContext.OriginalPositions != null)
                {
                    for (int i = 0; i < entry.Indices.Length; i++)
                    {
                        int idx = entry.Indices[i];
                        if (idx >= 0 && idx < meshContext.OriginalPositions.Length)
                        {
                            meshContext.OriginalPositions[idx] = meshObject.Vertices[idx].Position;
                        }
                    }
                }

                ctx.DirtyMeshIndices.Add(entry.MeshContextIndex);
            }
        }
    }

}
