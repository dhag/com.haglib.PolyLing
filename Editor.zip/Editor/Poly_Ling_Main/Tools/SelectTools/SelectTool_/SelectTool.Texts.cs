// Tools/SelectTool.Texts.cs

using System.Collections.Generic;
using Poly_Ling.Localization;

namespace Poly_Ling.Tools
{
    public partial class SelectTool
    {
        private static readonly Dictionary<string, Dictionary<string, string>> Texts = new()
        {
            ["ClickToSelect"] = new() { ["en"] = "Click to select vertices", ["ja"] = "クリックで頂点を選択", ["hi"] = "クリックしてえらぶ" },
            ["ShiftClick"] = new() { ["en"] = "Shift+Click: Add to selection", ["ja"] = "Shift+クリック: 選択に追加", ["hi"] = "Shift+クリック: ついか" },
            ["DragSelect"] = new() { ["en"] = "Drag: Box/Lasso select", ["ja"] = "ドラッグ: 矩形/投げ縄選択", ["hi"] = "ドラッグ: しかく/なげなわでえらぶ" },
        };

        private static string T(string key) => L.GetFrom(Texts, key);
        private static string T(string key, params object[] args) => L.GetFrom(Texts, key, args);
    }
}
