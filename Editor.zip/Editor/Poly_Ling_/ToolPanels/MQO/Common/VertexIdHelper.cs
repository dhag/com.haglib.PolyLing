// Assets/Editor/Poly_Ling/MQO/Common/VertexIdHelper.cs
// =====================================================================
// 頂点ID操作ヘルパー
// 
// 【頂点IDの3つの用途】
// 1. 頂点位置操作用途
//    - IDで特定の頂点を識別し、位置・UV・法線などを操作
//    - 例: ID=100の頂点を移動
// 
// 2. データ欠損・ミス検出用途
//    - IDの欠損、重複、範囲外などをチェック
//    - 例: ID=50が2回出現している、ID=100-110が欠損している
// 
// 3. オブジェクト間同一頂点認識用途
//    - 異なるMQOオブジェクト間で同一頂点を関連付け
//    - 例: Body と Cloth で境界頂点を共有
// 
// 【ID転送パターン】
// - 重みCSV → MQO: CSVのVertexIDをMQOの特殊面に埋め込み
// - MQO → 重みCSV: MQOの特殊面からVertexIDを抽出してCSVに出力
// - 新規割り振り → MQO, CSV: 連番IDを生成してMQO・CSVに出力
// =====================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Poly_Ling.MQO
{
    /// <summary>
    /// 頂点ID操作ヘルパー
    /// </summary>
    public static class VertexIdHelper
    {
        // =====================================================================
        // ID検証
        // =====================================================================

        /// <summary>
        /// 頂点ID検証結果
        /// </summary>
        public class ValidationResult
        {
            /// <summary>有効かどうか</summary>
            public bool IsValid => Errors.Count == 0;
            
            /// <summary>エラーリスト</summary>
            public List<string> Errors { get; } = new List<string>();
            
            /// <summary>警告リスト</summary>
            public List<string> Warnings { get; } = new List<string>();
            
            /// <summary>使用されているID一覧</summary>
            public HashSet<int> UsedIds { get; } = new HashSet<int>();
            
            /// <summary>重複しているID一覧</summary>
            public HashSet<int> DuplicateIds { get; } = new HashSet<int>();
            
            /// <summary>欠損しているID一覧（連番チェック時）</summary>
            public List<int> MissingIds { get; } = new List<int>();
            
            /// <summary>未設定（-1）の頂点数</summary>
            public int UnsetCount { get; set; }
            
            /// <summary>総頂点数</summary>
            public int TotalVertexCount { get; set; }
            
            public void AddError(string message) => Errors.Add(message);
            public void AddWarning(string message) => Warnings.Add(message);
        }

        /// <summary>
        /// 頂点IDの検証
        /// </summary>
        /// <param name="ids">頂点IDの配列（-1は未設定）</param>
        /// <param name="checkConsecutive">連番チェックを行うか</param>
        /// <param name="expectedStartId">連番チェック時の開始ID（デフォルト0）</param>
        /// <returns>検証結果</returns>
        public static ValidationResult ValidateIds(IEnumerable<int> ids, bool checkConsecutive = false, int expectedStartId = 0)
        {
            var result = new ValidationResult();
            var seenIds = new Dictionary<int, int>(); // ID → 出現回数
            int index = 0;
            
            foreach (var id in ids)
            {
                result.TotalVertexCount++;
                
                if (id < 0)
                {
                    // 未設定
                    result.UnsetCount++;
                }
                else
                {
                    // 有効なID
                    result.UsedIds.Add(id);
                    
                    if (seenIds.ContainsKey(id))
                    {
                        seenIds[id]++;
                        result.DuplicateIds.Add(id);
                    }
                    else
                    {
                        seenIds[id] = 1;
                    }
                }
                
                index++;
            }
            
            // 重複エラー
            foreach (var dupId in result.DuplicateIds)
            {
                result.AddError($"頂点ID {dupId} が {seenIds[dupId]} 回重複しています");
            }
            
            // 連番チェック
            if (checkConsecutive && result.UsedIds.Count > 0)
            {
                int minId = result.UsedIds.Min();
                int maxId = result.UsedIds.Max();
                
                // 期待される開始IDと異なる場合は警告
                if (minId != expectedStartId)
                {
                    result.AddWarning($"頂点IDが {expectedStartId} からではなく {minId} から開始しています");
                }
                
                // 欠損チェック
                for (int id = minId; id <= maxId; id++)
                {
                    if (!result.UsedIds.Contains(id))
                    {
                        result.MissingIds.Add(id);
                    }
                }
                
                if (result.MissingIds.Count > 0)
                {
                    if (result.MissingIds.Count <= 10)
                    {
                        result.AddWarning($"頂点IDが欠損しています: {string.Join(", ", result.MissingIds)}");
                    }
                    else
                    {
                        result.AddWarning($"頂点IDが {result.MissingIds.Count} 件欠損しています " +
                            $"(例: {string.Join(", ", result.MissingIds.Take(5))}...)");
                    }
                }
            }
            
            // 部分的に未設定がある場合は警告
            if (result.UnsetCount > 0 && result.UnsetCount < result.TotalVertexCount)
            {
                result.AddWarning($"{result.TotalVertexCount} 頂点中 {result.UnsetCount} 頂点のIDが未設定です");
            }
            
            return result;
        }

        // =====================================================================
        // ID生成
        // =====================================================================

        /// <summary>
        /// 連番IDを生成
        /// </summary>
        /// <param name="count">生成する数</param>
        /// <param name="startId">開始ID（デフォルト0）</param>
        /// <returns>ID配列</returns>
        public static int[] GenerateSequentialIds(int count, int startId = 0)
        {
            var ids = new int[count];
            for (int i = 0; i < count; i++)
            {
                ids[i] = startId + i;
            }
            return ids;
        }

        /// <summary>
        /// 未使用のIDを取得（既存IDの最大値+1から開始）
        /// </summary>
        /// <param name="existingIds">既存のID一覧</param>
        /// <param name="count">必要な数</param>
        /// <returns>新規ID配列</returns>
        public static int[] GetUnusedIds(IEnumerable<int> existingIds, int count)
        {
            int maxId = existingIds.Any() ? existingIds.Max() : -1;
            return GenerateSequentialIds(count, maxId + 1);
        }

        // =====================================================================
        // ID変換・マッピング
        // =====================================================================

        /// <summary>
        /// ID→インデックスのマッピングを作成
        /// </summary>
        /// <param name="idsWithIndex">（インデックス, ID）のペア</param>
        /// <returns>ID → インデックス の辞書</returns>
        public static Dictionary<int, int> CreateIdToIndexMap(IEnumerable<(int index, int id)> idsWithIndex)
        {
            var map = new Dictionary<int, int>();
            
            foreach (var (index, id) in idsWithIndex)
            {
                if (id >= 0 && !map.ContainsKey(id))
                {
                    map[id] = index;
                }
            }
            
            return map;
        }

        /// <summary>
        /// インデックス→IDのマッピングを作成
        /// </summary>
        /// <param name="ids">インデックス順のID配列</param>
        /// <returns>インデックス → ID の辞書</returns>
        public static Dictionary<int, int> CreateIndexToIdMap(IReadOnlyList<int> ids)
        {
            var map = new Dictionary<int, int>();
            
            for (int i = 0; i < ids.Count; i++)
            {
                if (ids[i] >= 0)
                {
                    map[i] = ids[i];
                }
            }
            
            return map;
        }

        // =====================================================================
        // オブジェクト間のID共有
        // =====================================================================

        /// <summary>
        /// 共有頂点検出結果
        /// </summary>
        public class SharedVertexResult
        {
            /// <summary>共有されているID一覧</summary>
            public HashSet<int> SharedIds { get; } = new HashSet<int>();
            
            /// <summary>オブジェクト名 → そのオブジェクトが持つ共有ID</summary>
            public Dictionary<string, HashSet<int>> ObjectSharedIds { get; } = new Dictionary<string, HashSet<int>>();
        }

        /// <summary>
        /// 複数オブジェクト間で共有されている頂点IDを検出
        /// </summary>
        /// <param name="objectIds">オブジェクト名 → ID一覧 のマッピング</param>
        /// <returns>共有頂点検出結果</returns>
        public static SharedVertexResult FindSharedVertices(Dictionary<string, IEnumerable<int>> objectIds)
        {
            var result = new SharedVertexResult();
            var idToObjects = new Dictionary<int, List<string>>();
            
            // IDごとに、それを持つオブジェクトを収集
            foreach (var (objectName, ids) in objectIds)
            {
                foreach (var id in ids)
                {
                    if (id < 0) continue;
                    
                    if (!idToObjects.ContainsKey(id))
                    {
                        idToObjects[id] = new List<string>();
                    }
                    idToObjects[id].Add(objectName);
                }
            }
            
            // 複数オブジェクトに出現するIDを共有IDとする
            foreach (var (id, objects) in idToObjects)
            {
                if (objects.Count > 1)
                {
                    result.SharedIds.Add(id);
                    
                    foreach (var objName in objects)
                    {
                        if (!result.ObjectSharedIds.ContainsKey(objName))
                        {
                            result.ObjectSharedIds[objName] = new HashSet<int>();
                        }
                        result.ObjectSharedIds[objName].Add(id);
                    }
                }
            }
            
            return result;
        }

        // =====================================================================
        // ID転送（MQO ↔ CSV）
        // =====================================================================

        /// <summary>
        /// MQOの特殊面からVertexIDを抽出
        /// 特殊面: 全頂点インデックスが同じ面（メタデータ格納用）
        /// 三角形特殊面: COL属性の3番目の値がVertexID
        /// </summary>
        /// <param name="faces">MQOの面リスト</param>
        /// <returns>頂点インデックス → VertexID のマッピング</returns>
        public static Dictionary<int, int> ExtractIdsFromSpecialFaces(IEnumerable<MQOFace> faces)
        {
            var vertexIdMap = new Dictionary<int, int>();
            
            foreach (var face in faces)
            {
                // 三角形特殊面のみ対象（四角形はボーンウェイト用）
                if (!face.IsSpecialFace || face.VertexCount != 3)
                    continue;
                
                // COL属性から頂点IDを取得
                if (face.VertexColors != null && face.VertexColors.Length >= 3)
                {
                    // 三角形特殊面の識別: COL[0]==1, COL[1]==1
                    if (face.VertexColors[0] == 1 && face.VertexColors[1] == 1)
                    {
                        int vertexIndex = face.VertexIndices[0];
                        int vertexId = (int)face.VertexColors[2];
                        
                        if (vertexIndex >= 0 && vertexId >= 0)
                        {
                            vertexIdMap[vertexIndex] = vertexId;
                        }
                    }
                }
            }
            
            return vertexIdMap;
        }

        /// <summary>
        /// VertexIDを埋め込むための特殊面を生成
        /// </summary>
        /// <param name="vertexIndex">頂点インデックス</param>
        /// <param name="vertexId">頂点ID</param>
        /// <param name="materialIndex">マテリアルインデックス（デフォルト0）</param>
        /// <returns>特殊面データ</returns>
        public static MQOFace CreateSpecialFaceForVertexId(int vertexIndex, int vertexId, int materialIndex = 0)
        {
            return new MQOFace
            {
                // 3頂点すべて同じインデックス（特殊面の印）
                VertexIndices = new int[] { vertexIndex, vertexIndex, vertexIndex },
                MaterialIndex = materialIndex,
                // UVは (0,0) で統一
                UVs = new Vector2[] { Vector2.zero, Vector2.zero, Vector2.zero },
                // COL属性: [1, 1, vertexId]（1,1は識別用マーカー）
                VertexColors = new uint[] { 1, 1, (uint)vertexId }
            };
        }

        // =====================================================================
        // ボーンウェイト特殊面（四角形）
        // =====================================================================

        /// <summary>
        /// MQOの四角形特殊面からボーンウェイトを抽出
        /// 四角形特殊面: 全頂点インデックスが同じ四角形面
        /// UV[0].x=weight0, UV[0].y=weight1, UV[1].x=weight2, UV[1].y=weight3
        /// COL(boneIndex0, boneIndex1, boneIndex2, boneIndex3)
        /// </summary>
        /// <param name="faces">MQOの面リスト</param>
        /// <returns>頂点インデックス → ボーンウェイト情報 のマッピング</returns>
        public static Dictionary<int, BoneWeightData> ExtractBoneWeightsFromSpecialFaces(IEnumerable<MQOFace> faces)
        {
            var boneWeightMap = new Dictionary<int, BoneWeightData>();
            
            foreach (var face in faces)
            {
                // 四角形特殊面のみ対象
                if (!face.IsSpecialFace || face.VertexCount != 4)
                    continue;
                
                // UV属性とCOL属性が必要
                if (face.UVs == null || face.UVs.Length < 2)
                    continue;
                if (face.VertexColors == null || face.VertexColors.Length < 4)
                    continue;
                
                int vertexIndex = face.VertexIndices[0];
                
                var boneWeight = new BoneWeightData
                {
                    BoneIndex0 = (int)face.VertexColors[0],
                    BoneIndex1 = (int)face.VertexColors[1],
                    BoneIndex2 = (int)face.VertexColors[2],
                    BoneIndex3 = (int)face.VertexColors[3],
                    Weight0 = face.UVs[0].x,
                    Weight1 = face.UVs[0].y,
                    Weight2 = face.UVs[1].x,
                    Weight3 = face.UVs[1].y
                };
                
                boneWeightMap[vertexIndex] = boneWeight;
            }
            
            return boneWeightMap;
        }

        /// <summary>
        /// ボーンウェイトを埋め込むための四角形特殊面を生成
        /// </summary>
        /// <param name="vertexIndex">頂点インデックス</param>
        /// <param name="boneWeight">ボーンウェイト情報</param>
        /// <param name="materialIndex">マテリアルインデックス（デフォルト0）</param>
        /// <returns>四角形特殊面データ</returns>
        public static MQOFace CreateSpecialFaceForBoneWeight(int vertexIndex, BoneWeightData boneWeight, int materialIndex = 0)
        {
            return new MQOFace
            {
                // 4頂点すべて同じインデックス（四角形特殊面の印）
                VertexIndices = new int[] { vertexIndex, vertexIndex, vertexIndex, vertexIndex },
                MaterialIndex = materialIndex,
                // UV属性: [weight0, weight1], [weight2, weight3], [0, 0], [0, 0]
                UVs = new Vector2[]
                {
                    new Vector2(boneWeight.Weight0, boneWeight.Weight1),
                    new Vector2(boneWeight.Weight2, boneWeight.Weight3),
                    Vector2.zero,
                    Vector2.zero
                },
                // COL属性: [boneIndex0, boneIndex1, boneIndex2, boneIndex3]
                VertexColors = new uint[]
                {
                    (uint)boneWeight.BoneIndex0,
                    (uint)boneWeight.BoneIndex1,
                    (uint)boneWeight.BoneIndex2,
                    (uint)boneWeight.BoneIndex3
                }
            };
        }

        /// <summary>
        /// ボーンウェイトデータ（MQO特殊面用）
        /// </summary>
        public class BoneWeightData
        {
            public int BoneIndex0 { get; set; }
            public int BoneIndex1 { get; set; }
            public int BoneIndex2 { get; set; }
            public int BoneIndex3 { get; set; }
            public float Weight0 { get; set; }
            public float Weight1 { get; set; }
            public float Weight2 { get; set; }
            public float Weight3 { get; set; }
            
            /// <summary>有効なウェイトを持つか（合計が0より大きいか）</summary>
            public bool HasWeight => Weight0 + Weight1 + Weight2 + Weight3 > 0;
        }

        // =====================================================================
        // ログ出力ヘルパー
        // =====================================================================

        /// <summary>
        /// 検証結果をログ出力
        /// </summary>
        public static void LogValidationResult(ValidationResult result, string contextName = "")
        {
            string prefix = string.IsNullOrEmpty(contextName) ? "" : $"[{contextName}] ";
            
            if (result.IsValid)
            {
                Debug.Log($"{prefix}頂点ID検証: OK " +
                    $"(総数: {result.TotalVertexCount}, " +
                    $"有効: {result.UsedIds.Count}, " +
                    $"未設定: {result.UnsetCount})");
            }
            else
            {
                Debug.LogError($"{prefix}頂点ID検証: エラーあり");
                foreach (var error in result.Errors)
                {
                    Debug.LogError($"  {error}");
                }
            }
            
            foreach (var warning in result.Warnings)
            {
                Debug.LogWarning($"{prefix}{warning}");
            }
        }
    }
}
