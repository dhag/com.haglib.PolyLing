// Assets/Editor/Poly_Ling/Core/UnifiedSystemAdapter.cs
// 統合システムアダプター
// SimpleMeshFactoryとUnifiedMeshSystemを接続するブリッジクラス

using System;
using System.Collections.Generic;
using UnityEngine;
using Poly_Ling.Data;
using Poly_Ling.Context;
using Poly_Ling.Selection;
using Poly_Ling.Symmetry;
using Poly_Ling.Rendering;
using Poly_Ling.Core.Rendering;

namespace Poly_Ling.Core
{
    /// <summary>
    /// 統合システムアダプター
    /// 既存のSimpleMeshFactoryとUnifiedMeshSystemを段階的に統合
    /// </summary>
    public partial class UnifiedSystemAdapter : IDisposable
    {
        // ============================================================
        // コンポーネント
        // ============================================================

        private UnifiedMeshSystem _unifiedSystem;
        private UnifiedRenderer _renderer;

        // ============================================================
        // 外部参照
        // ============================================================

        private ModelContext _modelContext;
        private SelectionState _selectionState;
        private SymmetrySettings _symmetrySettings;

        // ============================================================
        // 状態
        // ============================================================

        private bool _isInitialized = false;
        private bool _disposed = false;
        private bool _useUnifiedRendering = false; // 統合レンダリング使用フラグ

        // ★ ホバー軽量更新用のviewport記録
        // UpdateFrame（Repaint, Normalモード時）で更新される。
        // UpdateHoverOnly（MouseMove時）でviewport変更を検出するために使用。
        private Rect _lastKnownViewport;

        // クワッドメッシュ（頂点描画用）
        private Mesh _quadMesh;

        // ============================================================
        // プロパティ
        // ============================================================

        public bool IsInitialized => _isInitialized;
        public bool UseUnifiedRendering
        {
            get => _useUnifiedRendering;
            set => _useUnifiedRendering = value;
        }

        /// <summary>
        /// 背面カリングを有効にするか
        /// </summary>
        public bool BackfaceCullingEnabled
        {
            get => _renderer?.BackfaceCullingEnabled ?? true;
            set
            {
                if (_renderer != null) _renderer.BackfaceCullingEnabled = value;
                if (_unifiedSystem != null) _unifiedSystem.BackfaceCullingEnabled = value;
            }
        }

        public UnifiedMeshSystem UnifiedSystem => _unifiedSystem;
        public UnifiedRenderer Renderer => _renderer;
        public UnifiedBufferManager BufferManager => _unifiedSystem?.BufferManager;

        // 既存システムとの互換用（グローバルインデックス）
        public int HoverVertexIndex => _unifiedSystem?.HoveredVertexIndex ?? -1;
        public int HoverLineIndex => _unifiedSystem?.HoveredLineIndex ?? -1;
        public int HoverFaceIndex => _unifiedSystem?.HoveredFaceIndex ?? -1;

        /// <summary>
        /// ホバー状態を全てクリアする。
        /// マウスが表示エリア外に出た場合に呼び出す。
        /// </summary>
        public void ClearMouseHover()
        {
            if (!_isInitialized)
                return;
            _unifiedSystem?.ClearAllHover();
        }

        /// <summary>
        /// 指定メッシュのローカル頂点ホバーインデックスを取得
        /// </summary>
        public int GetLocalHoverVertexIndex(int meshIndex)
        {
            int globalIndex = HoverVertexIndex;
            if (globalIndex < 0) return -1;

            if (BufferManager?.GlobalToLocalVertexIndex(globalIndex, out int meshIdx, out int localIdx) == true)
            {
                if (meshIdx == meshIndex)
                    return localIdx;
            }
            return -1;
        }

        /// <summary>
        /// 指定メッシュのローカル線分ホバーインデックスを取得
        /// グローバルLineIndexを返す（EdgeCacheはグローバルリスト）
        /// ただし指定メッシュの線分でない場合は-1
        /// </summary>
        public int GetLocalHoverLineIndex(int meshIndex)
        {
            int globalIndex = HoverLineIndex;
            if (globalIndex < 0) return -1;

            if (BufferManager?.GlobalToLocalLineIndex(globalIndex, out int meshIdx, out int localIdx) == true)
            {
                if (meshIdx == meshIndex)
                    return globalIndex;  // EdgeCacheはグローバルリストなのでグローバルインデックスを返す
            }
            return -1;
        }

        /// <summary>
        /// 指定メッシュのローカル面ホバーインデックスを取得
        /// </summary>
        public int GetLocalHoverFaceIndex(int meshIndex)
        {
            int globalIndex = HoverFaceIndex;
            if (globalIndex < 0) return -1;

            if (BufferManager?.GlobalToLocalFaceIndex(globalIndex, out int meshIdx, out int localIdx) == true)
            {
                if (meshIdx == meshIndex)
                    return localIdx;
            }
            return -1;
        }

        // ============================================================
        // コンストラクタ
        // ============================================================

        public UnifiedSystemAdapter()
        {
            _unifiedSystem = new UnifiedMeshSystem();
            _renderer = new UnifiedRenderer(_unifiedSystem.BufferManager);
        }

        // ============================================================
        // 初期化
        // ============================================================

        /// <summary>
        /// アダプターを初期化
        /// </summary>
        public bool Initialize()
        {
            if (_isInitialized)
                return true;

            _unifiedSystem.Initialize();

            if (!_renderer.Initialize())
            {
                Debug.LogWarning("[UnifiedSystemAdapter] Failed to initialize renderer");
                return false;
            }

            // クワッドメッシュを作成（頂点描画用）
            CreateQuadMesh();

            _isInitialized = true;
            return true;
        }

        /// <summary>
        /// クワッドメッシュを作成
        /// </summary>
        private void CreateQuadMesh()
        {
            _quadMesh = new Mesh();
            _quadMesh.name = "UnifiedPointQuad";

            // 単位正方形（中心原点）
            _quadMesh.vertices = new Vector3[]
            {
                new Vector3(-0.5f, -0.5f, 0),
                new Vector3(0.5f, -0.5f, 0),
                new Vector3(0.5f, 0.5f, 0),
                new Vector3(-0.5f, 0.5f, 0)
            };

            _quadMesh.uv = new Vector2[]
            {
                new Vector2(0, 0),
                new Vector2(1, 0),
                new Vector2(1, 1),
                new Vector2(0, 1)
            };

            _quadMesh.triangles = new int[] { 0, 2, 1, 0, 3, 2 };
            _quadMesh.RecalculateNormals();
        }

        // ============================================================
        // 参照設定
        // ============================================================

        /// <summary>
        /// モデルコンテキストを設定
        /// </summary>
        public void SetModelContext(ModelContext modelContext)
        {
            _modelContext = modelContext;

            _unifiedSystem.SetModel(modelContext);

            // 即座にトポロジー更新を実行（遅延せずにバッファを構築）
            _unifiedSystem.ExecuteUpdates(DirtyLevel.Topology);
        }

        /// <summary>
        /// 選択状態を設定
        /// </summary>
        public void SetSelectionState(SelectionState selectionState)
        {
            _selectionState = selectionState;
            _unifiedSystem.SetSelectionState(selectionState);
        }

        /// <summary>
        /// 対称設定を設定
        /// </summary>
        public void SetSymmetrySettings(SymmetrySettings settings)
        {
            _symmetrySettings = settings;
            _unifiedSystem.SetSymmetrySettings(settings);
        }

        /// <summary>
        /// アクティブメッシュを設定
        /// meshIndexはMeshContexts配列のインデックス（ボーン含む）
        /// 内部でUnifiedMeshインデックスに変換される
        /// </summary>
        public void SetActiveMesh(int modelIndex, int contextIndex)
        {
            // MeshContextインデックス → UnifiedMeshインデックスに変換
            int unifiedMeshIndex = BufferManager?.ContextToUnifiedMeshIndex(contextIndex) ?? contextIndex;
            _unifiedSystem.SetActiveMesh(modelIndex, unifiedMeshIndex);
        }

        /// <summary>
        /// MeshContextインデックスをUnifiedMeshインデックスに変換
        /// </summary>
        public int ContextToUnifiedMeshIndex(int contextIndex)
        {
            return BufferManager?.ContextToUnifiedMeshIndex(contextIndex) ?? -1;
        }

        // ============================================================
        // 更新通知
        // ============================================================

        /// <summary>
        /// トポロジー変更を通知
        /// </summary>
        public void NotifyTopologyChanged()
        {
            _unifiedSystem.NotifyTopologyChanged();
            // 即座にトポロジー更新を実行
            _unifiedSystem.ExecuteUpdates(DirtyLevel.Topology);
            RequestNormal();
        }

        /// <summary>
        /// 位置変更を通知
        /// </summary>
        public void NotifyTransformChanged()
        {
            _unifiedSystem.NotifyTransformChanged();
            RequestNormal();
        }

        /// <summary>
        /// 選択変更を通知
        /// </summary>
        public void NotifySelectionChanged()
        {
            _unifiedSystem.NotifySelectionChanged();
            RequestNormal();
        }

        // ============================================================
        // フレーム更新
        // ============================================================

        /// <summary>
        /// フレーム更新（毎フレーム呼ばれる）
        /// 
        /// ★★★ 禁忌（絶対厳守） ★★★
        /// この関数はAllowHitTest=false時に早期リターンする。
        /// TransformDragging中にこのガードを迂回・削除してはならない。
        /// BeginFrame/ProcessUpdates/ExecuteUpdates/EndFrame の全パイプラインが
        /// 毎ドラッグフレームで実行されると、全メッシュのGPU転送・スクリーン座標計算・
        /// ヒットテストが毎フレーム走り、1FPS以下に落ちる。
        ///
        /// ドラッグ中のリアルタイム表示更新が必要な場合:
        /// - トポロジ変更を伴わない表示専用入口を使用すること
        ///   → UnifiedMeshSystem.ProcessTransformUpdate()
        ///     （_bufferManager.UpdatePositions: Array.Copy + SetData のみ）
        /// - ホバーチェック無効化はUpdateModeProfile.AllowHitTest=falseで制御
        ///   （TransformDraggingプロファイルで既にfalse）
        /// - この関数を経由してはならない
        ///
        /// 過去の障害: RequestNormal迂回 + AllowMeshRebuild=true → 1FPS
        /// ★★★★★★★★★★★★★★★★★★★★
        /// </summary>
        public void UpdateFrame(
            Vector3 cameraPosition,
            Vector3 cameraTarget,
            float fov,
            Rect viewport,
            Vector2 mousePosition,
            float rotationZ = 0f)
        {
            if (!_isInitialized)
                return;

            // ★禁忌ガード: このreturnを削除・迂回してはならない
            if (!_currentProfile.AllowHitTest)
                return;

            // ★ viewport記録: UpdateHoverOnlyのviewport変更検出で参照される
            _lastKnownViewport = viewport;

            _unifiedSystem.BeginFrame();

            // カメラ更新
            _unifiedSystem.UpdateCamera(cameraPosition, cameraTarget, fov, viewport, rotationZ);

            // マウス更新
            _unifiedSystem.UpdateMousePosition(mousePosition);

            // 更新実行
            DirtyLevel level = _unifiedSystem.ProcessUpdates();
            _unifiedSystem.ExecuteUpdates(level);

            _unifiedSystem.EndFrame();
        }

        /// <summary>
        /// フレーム更新（Camera オブジェクト直接版）。
        /// 正射影カメラ（Top / Front ビューポート）に対応するため、
        /// camera.worldToCameraMatrix / camera.projectionMatrix を使用する。
        /// fov=0 で Perspective 行列を構築する旧パスは正射影で縮退するため使用しない。
        /// </summary>
        public void UpdateFrame(Camera camera, Rect viewport, Vector2 mousePosition)
        {
            if (!_isInitialized || camera == null)
                return;

            if (!_currentProfile.AllowHitTest)
                return;

            _lastKnownViewport = viewport;

            _unifiedSystem.BeginFrame();

            Vector3 camPos    = camera.transform.position;
            Vector3 camTarget = camPos + camera.transform.forward;

            _unifiedSystem.UpdateCameraFromMatrix(
                camera.worldToCameraMatrix,
                camera.projectionMatrix,
                camPos,
                camTarget,
                viewport);

            _unifiedSystem.UpdateMousePosition(mousePosition);

            DirtyLevel level = _unifiedSystem.ProcessUpdates();
            _unifiedSystem.ExecuteUpdates(level);

            _unifiedSystem.EndFrame();
        }

        // ============================================================
        // 軽量ホバー更新
        // ============================================================
        //
        // 【背景】
        // ワンショット方式により、通常時はIdleモード（AllowHitTest=false）で
        // UpdateFrameが全スキップされ、ホバー結果（_hoveredVertexIndex等）が凍結する。
        // これにより「マウス直下の要素」が古いまま残り、クリック+ドラッグ=選択同時移動が失敗する。
        //
        // 【解決策】
        // MouseMoveイベント時にヒットテストのみを実行する軽量パスを提供する。
        // スクリーン座標は直前のRepaintで計算済みのものを再利用するため、
        // Topology/Transform/Selection/Cameraの再計算は不要。
        //
        // 【★★★ 禁忌（絶対厳守） ★★★】
        // このメソッドをRepaintイベントやOnGUIの毎フレーム処理に組み込んではならない。
        // MouseMoveイベント（ユーザーがマウスを動かした時のみ発火）からのみ呼び出すこと。
        // Repaint毎に呼ぶとGPUヒットテスト（ComputeScreenPositions+DispatchVertexHitTest等）が
        // 毎描画フレームで実行され、パフォーマンスが深刻に劣化する。
        //
        // 呼び出し元: PolyLing_Input.UpdateHoverOnMouseMove()
        //   → EventType.MouseMove かつ rect.Contains(mousePos) の場合のみ
        // ★★★★★★★★★★★★★★★★★★★★

        /// <summary>
        /// ホバー専用の軽量更新パス
        ///
        /// TransformDragging/CameraDragging中は何もしない（禁忌維持）。
        /// viewportが変更された場合（ウインドウリサイズ等）はスクリーン座標が無効なため
        /// RequestNormal()を発行して次のRepaintでフルパイプラインを実行させ、
        /// この回のヒットテストはスキップする。
        /// </summary>
        /// <param name="localMousePos">ローカル座標系のマウス位置（rect.position を引いた値）</param>
        /// <param name="viewport">現在のプレビューエリアサイズ new Rect(0, 0, width, height)</param>
        public void UpdateHoverOnly(Vector2 localMousePos, Rect viewport)
        {
            if (!_isInitialized)
                return;

            // ドラッグ中はホバー更新禁止（TransformDragging/CameraDragging）
            if (_currentMode == UpdateMode.TransformDragging ||
                _currentMode == UpdateMode.CameraDragging)
                return;

            // viewport変更検出（ウインドウリサイズ等）
            // スクリーン座標が古いためヒットテスト結果は不正確になる。
            // RequestNormal()で次のRepaintでフルパイプラインを実行させ、
            // _lastKnownViewportはそのUpdateFrame内で更新される。
            //
            // ★ 近似比較（1px許容）を使う理由:
            //   Rect.operator!= は浮動小数点の完全一致比較。
            //   IMGUIのGUILayoutUtility.GetRectはRepaintイベントとMouseMoveイベントで
            //   微小な浮動小数点差（DPIスケーリング等）を返すことがある。
            //   完全一致だとProcessHoverOnlyが一度も実行されず、ホバーが凍結する。
            //   1px以上の変更は実際のリサイズとみなしてフルパイプラインに委譲する。
            if (Mathf.Abs(_lastKnownViewport.width - viewport.width) > 1f ||
                Mathf.Abs(_lastKnownViewport.height - viewport.height) > 1f)
            {
                RequestNormal();
                return;
            }

            // 軽量パス: マウス位置更新 + ヒットテストのみ
            _unifiedSystem.ProcessHoverOnly(localMousePos);
        }

        /// <summary>
        /// 変換行列を更新してGPUで頂点変換を実行
        /// </summary>
        /// <param name="useWorldTransform">ワールド変換を使用するか</param>
        public void UpdateTransform(bool useWorldTransform)
        {
            if (!_isInitialized || _modelContext == null)
                return;

            var bufferManager = _unifiedSystem?.BufferManager;
            if (bufferManager == null)
                return;

            // 変換行列をGPUにアップロード
            bufferManager.UpdateTransformMatrices(_modelContext.MeshContextList, useWorldTransform);

            // TransformVerticesカーネルを実行
            // ReadBackは必要（ワイヤフレーム・頂点描画がGetDisplayPositions()を使うため）
            bufferManager.DispatchTransformVertices(useWorldTransform, false, readbackToCPU: true);

            // UV展開済み頂点を生成（面シェーダ描画用）
            bufferManager.DispatchExpandVertices(transformNormals: false);
        }

        /// <summary>
        /// GPU変換後の頂点をUnityMeshに設定
        /// 展開済み頂点バッファから一度ReadBackして各メッシュに配分
        /// </summary>
        public void WritebackTransformedVertices()
        {
            if (!_isInitialized || _modelContext == null)
                return;

            var bufferManager = _unifiedSystem?.BufferManager;
            if (bufferManager == null)
                return;

            var meshContextList = _modelContext.MeshContextList;
            if (meshContextList == null)
                return;

            int totalExpandedCount = bufferManager.TotalExpandedVertexCount;
            if (totalExpandedCount == 0)
            {
                // 展開バッファが未構築の場合はフォールバック
                WritebackTransformedVerticesFallback();
                return;
            }

            // 展開済み頂点をGPUから一度だけReadBack
            var expandedPositions = bufferManager.GetExpandedPositions();
            if (expandedPositions == null || expandedPositions.Length == 0)
            {
                WritebackTransformedVerticesFallback();
                return;
            }

            // 展開済み頂点のオフセットを追跡
            int expandedOffset = 0;

            // 各MeshContextのUnityMeshを更新
            for (int ctxIdx = 0; ctxIdx < meshContextList.Count; ctxIdx++)
            {
                var ctx = meshContextList[ctxIdx];
                if (ctx?.MeshObject == null)
                    continue;

                // ボーン・モーフはスキップ（GPUバッファはDrawableのみ）
                if (ctx.Type == MeshType.Bone || ctx.Type == MeshType.Morph)
                    continue;

                var meshObject = ctx.MeshObject;

                // このメッシュの展開後頂点数を計算
                int expandedVertexCount = 0;
                foreach (var vertex in meshObject.Vertices)
                {
                    int uvCount = vertex.UVs.Count > 0 ? vertex.UVs.Count : 1;
                    expandedVertexCount += uvCount;
                }

                if (expandedVertexCount == 0)
                    continue;

                // 境界チェック: expandedPositions配列の範囲外アクセスを防ぐ
                if (expandedOffset + expandedVertexCount > expandedPositions.Length)
                {
                    /*
                    // バッファサイズ不整合 - フォールバック処理へ
                    Debug.LogWarning($"[WritebackTransformedVertices] Buffer size mismatch for mesh '{ctx.Name}': " +
                        $"offset={expandedOffset}, count={expandedVertexCount}, bufferSize={expandedPositions.Length}. " +
                        $"Skipping this mesh.");
                    */
                    expandedOffset += expandedVertexCount;
                    continue;
                }

                // UnityMeshが存在し、頂点数が一致する場合は位置のみ更新
                var unityMesh = ctx.UnityMesh;
                if (unityMesh != null && unityMesh.vertexCount == expandedVertexCount)
                {
                    // NativeArrayを使ってコピー（GC削減）
                    var nativeArray = new Unity.Collections.NativeArray<Vector3>(
                        expandedVertexCount,
                        Unity.Collections.Allocator.Temp,
                        Unity.Collections.NativeArrayOptions.UninitializedMemory);

                    Unity.Collections.NativeArray<Vector3>.Copy(expandedPositions, expandedOffset, nativeArray, 0, expandedVertexCount);

                    unityMesh.SetVertices(nativeArray);
                    unityMesh.RecalculateBounds();

                    nativeArray.Dispose();
                }
                else
                {
                    // UnityMeshが存在しないか頂点数が違う場合は再生成
                    var meshInfos = bufferManager.MeshInfos;
                    int unifiedMeshIdx = bufferManager.ContextToUnifiedMeshIndex(ctxIdx);
                    if (unifiedMeshIdx >= 0 && meshInfos != null)
                    {
                        var meshInfo = meshInfos[unifiedMeshIdx];
                        int vertexStart = (int)meshInfo.VertexStart;
                        var worldPositions = bufferManager.GetWorldPositions();
                        if (worldPositions != null)
                        {
                            for (int i = 0; i < meshObject.VertexCount && (vertexStart + i) < worldPositions.Length; i++)
                            {
                                meshObject.Vertices[i].Position = worldPositions[vertexStart + i];
                            }
                        }
                    }
                    ctx.UnityMesh = meshObject.ToUnityMesh();
                }

                expandedOffset += expandedVertexCount;
            }
        }

        /// <summary>
        /// フォールバック: 従来のCPU経由の書き戻し
        /// </summary>
        private void WritebackTransformedVerticesFallback()
        {
            var bufferManager = _unifiedSystem?.BufferManager;
            if (bufferManager == null)
                return;

            var meshContextList = _modelContext.MeshContextList;
            if (meshContextList == null)
                return;

            // GPU変換後の頂点座標を取得（CPU ReadBack）
            var worldPositions = bufferManager.GetWorldPositions();
            if (worldPositions == null || worldPositions.Length == 0)
                return;

            var meshInfos = bufferManager.MeshInfos;
            if (meshInfos == null)
                return;

            // 各MeshContextの頂点を書き戻す
            for (int ctxIdx = 0; ctxIdx < meshContextList.Count; ctxIdx++)
            {
                var ctx = meshContextList[ctxIdx];
                if (ctx?.MeshObject == null)
                    continue;

                if (ctx.Type == MeshType.Bone || ctx.Type == MeshType.Morph)
                    continue;

                int unifiedMeshIdx = bufferManager.ContextToUnifiedMeshIndex(ctxIdx);
                if (unifiedMeshIdx < 0)
                    continue;

                var meshInfo = meshInfos[unifiedMeshIdx];
                int vertexStart = (int)meshInfo.VertexStart;
                int vertexCount = (int)meshInfo.VertexCount;

                if (vertexCount == 0)
                    continue;

                var meshObject = ctx.MeshObject;
                if (meshObject.VertexCount != vertexCount)
                    continue;

                // MeshObject.Verticesに書き戻し
                for (int i = 0; i < vertexCount; i++)
                {
                    int globalIdx = vertexStart + i;
                    if (globalIdx < worldPositions.Length)
                    {
                        meshObject.Vertices[i].Position = worldPositions[globalIdx];
                    }
                }

                // UnityMeshを再生成
                ctx.UnityMesh = meshObject.ToUnityMesh();
            }
        }

        // ============================================================
        // 描画
        // ============================================================
        /*
        /// <summary>
        /// メッシュを構築してキューに追加（後方互換用オーバーロード）
        /// </summary>
        public void PrepareDrawing(Camera camera, bool showWireframe, bool showVertices, float pointSize = 0.02f, float alpha = 1f)
        {
            // 全メッシュ描画（後方互換）
            PrepareDrawing(camera, showWireframe, showVertices, true, true, -1, pointSize, alpha);
        }
        */
        /// <summary>
        /// 描画準備（ワイヤーフレーム・頂点メッシュの構築とキューイング）
        ///
        /// ★★★ 禁忌（絶対厳守） ★★★
        /// AllowMeshRebuild=true のプロファイルを TransformDragging中に適用してはならない。
        /// UpdateWireframeMesh / UpdatePointMesh は全ライン・全頂点を走査して
        /// Mesh頂点・カラー・インデックスを毎回再構築する重い処理であり、
        /// 毎ドラッグフレームで実行すると1FPS以下に落ちる。
        ///
        /// ドラッグ中のワイヤーフレーム更新が必要な場合:
        /// - トポロジ（インデックス・カラー・フラグ）は不変のまま
        ///   頂点位置のみを差し替える軽量パスを使用すること
        ///   → UnifiedMeshSystem.ProcessTransformUpdateSelectedOnly()
        ///     （選択メッシュの _bufferManager.UpdatePositions のみ）
        /// - この関数のrebuildMeshパスを経由してはならない
        ///
        /// 過去の障害: AllowMeshRebuild=true → 1FPS（ワイヤー全再構築が毎フレーム実行）
        /// ★★★★★★★★★★★★★★★★★★★★
        /// </summary>
        /// <param name="camera">カメラ</param>
        /// <param name="showWireframe">ワイヤーフレームを表示するか</param>
        /// <param name="showVertices">頂点を表示するか</param>
        /// <param name="showUnselectedWireframe">非選択メッシュのワイヤーフレームを表示するか</param>
        /// <param name="showUnselectedVertices">非選択メッシュの頂点を表示するか</param>
        /// <param name="selectedMeshIndex">選択メッシュインデックス（-1で全選択扱い）</param>
        /// <param name="pointSize">頂点サイズ</param>
        /// <param name="alpha">アルファ値</param>
        public void PrepareDrawing(
            Camera camera,
            bool showWireframe,
            bool showVertices,
            bool showUnselectedWireframe,
            bool showUnselectedVertices,
            int selectedMeshIndex,
            float pointSize,
            float alpha = 1f,
            int cullingSlot = 0,
            bool showFaceOverlay = true)
        {
            if (!_isInitialized)
            {
                return;
            }

            bool rebuildMesh = _currentProfile.AllowMeshRebuild;

            bool lightweightPositionUpdate = !rebuildMesh
                && _currentMode == UpdateMode.TransformDragging
                && RealtimeTransformUpdate;

            if (lightweightPositionUpdate)
            {
                _unifiedSystem.ProcessTransformUpdateSelectedOnly();

                var bm = BufferManager;
                bm?.DispatchTransformVertices(useWorldTransform: true, transformNormals: false, readbackToCPU: true);

                if (showWireframe)
                    _renderer.UpdateWireframePositionsOnly();
                if (showVertices)
                    _renderer.UpdatePointPositionsOnly(camera, pointSize);
                // Phase 2c: 面塗り overlay は頂点位置に連動するため、軽量更新時も再構築が必要。
                // ただし wireframe の UpdateWireframePositionsOnly 相当の軽量経路は現状未実装のため、
                // やむをえずフル再構築する（ドラッグ中は毎フレーム走る点、許容する）。
                if (showFaceOverlay)
                    _renderer.UpdateFaceOverlayMeshSelected();
            }

            if (showWireframe)
            {
                if (rebuildMesh)
                {
                    _renderer.UpdateWireframeMeshSelected(alpha);
                    _renderer.UpdateWireframeMeshUnselected(0.4f);
                }
                _renderer.QueueWireframe(showUnselectedWireframe, cullingSlot);
            }

            if (showVertices)
            {
                if (rebuildMesh)
                {
                    _renderer.UpdatePointMeshSelected(camera, pointSize, alpha);
                    _renderer.UpdatePointMeshUnselected(camera, pointSize, 0.4f);
                }
                _renderer.QueuePoints(showUnselectedVertices, cullingSlot);
            }

            // Phase 2c: 面塗り overlay
            if (showFaceOverlay)
            {
                if (rebuildMesh)
                {
                    _renderer.UpdateFaceOverlayMeshSelected();
                }
                _renderer.QueueFaceOverlay(cullingSlot);
            }
        }

        /// <summary>
        /// ★★★ 厳守: この関数は Graphics.DrawMesh 提出のみを行う ★★★
        /// 指定 slot のキューに入っているメッシュを指定カメラに描画する。
        /// 計算処理は一切禁止。全ての準備は PrepareDrawing で完了させておくこと。
        /// ★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★★
        /// </summary>
        public void DrawQueued(Camera camera, int slot)
        {
            if (!_isInitialized) return;
            _renderer.DrawQueued(camera, slot);
        }

        /// <summary>
        /// 【重大規約違反: 旧 API】slot 非対応版。slot=0 で動作する。Phase 1 で削除予定。
        /// </summary>
        [System.Obsolete("Use DrawQueued(camera, slot) instead.")]
        public void DrawQueued(Camera camera)
        {
            if (!_isInitialized) return;
            _renderer.DrawQueued(camera, 0);
        }


        /// <summary>
        /// 指定 slot の描画後クリーンアップ。
        /// </summary>
        public void CleanupQueued(int slot)
        {
            if (!_isInitialized) return;
            _renderer.CleanupQueued(slot);
        }

        /// <summary>
        /// 【重大規約違反: 旧 API】全 slot をクリア。Phase 1 で削除予定。
        /// </summary>
        [System.Obsolete("Use CleanupQueued(slot) instead.")]
        public void CleanupQueued()
        {
            if (!_isInitialized) return;
#pragma warning disable CS0618
            _renderer.CleanupQueued();
#pragma warning restore CS0618
        }

        /// <summary>
        /// プレイヤービルド用: カメラ情報からGPUカリングを実行して per-slot カリングバッファを更新する。
        /// DrawQueued の前に呼ぶこと。
        /// </summary>
        public void DispatchCullingForDisplay(Camera camera, bool backfaceCulling = true, int slot = 0)
        {
            if (!_isInitialized || camera == null) return;
            var bm = _unifiedSystem?.BufferManager;
            if (bm == null || !bm.GpuComputeAvailable) return;

            Matrix4x4 vp = camera.projectionMatrix * camera.worldToCameraMatrix;
            var viewport = new Rect(0f, 0f, camera.pixelWidth, camera.pixelHeight);

            // 対象スロットのカリングバッファのみクリアする。
            // DispatchClearBuffersGPU は呼ばない（ヒットテストバッファのクリアは不要、
            // かつ呼ぶと他スロットの slot 0 自動クリアが発生する可能性があるため）。
            bm.DispatchClearCulledBuffersGPU(slot);
            bm.ComputeScreenPositionsGPU(vp, viewport, slot);

            if (backfaceCulling)
            {
                bm.DispatchFaceVisibilityGPU(slot);
                bm.DispatchLineVisibilityGPU(slot);
            }
            else
            {
                bm.ClearCulledFlagsGPU(slot);
            }

            // 永続ミラーの最終カリング（両分岐後に適用し、上書きを受けないようにする）。
            bm.DispatchApplyMirrorCullGPU(slot);
        }

        /// <summary>
        /// 旧API互換（非推奨）
        /// </summary>
        [Obsolete("Use PrepareDrawing + DrawQueued + CleanupQueued instead")]
        public void Draw(Matrix4x4 modelMatrix, Camera camera = null)
        {
            // 旧APIは機能しない
        }

        // ============================================================
        // ヒットテスト
        // ============================================================

        /// <summary>
        /// v2.1: 指定メッシュの頂点オフセット（グローバルインデックス）を取得
        /// </summary>
        public int GetVertexOffset(int meshIndex)
        {
            if (!_isInitialized || BufferManager == null)
                return 0;
                
            int unifiedMeshIndex = ContextToUnifiedMeshIndex(meshIndex);
            if (unifiedMeshIndex < 0)
                return 0;
                
            var meshInfos = BufferManager.MeshInfos;
            if (meshInfos == null || unifiedMeshIndex >= meshInfos.Length)
                return 0;
                
            return (int)meshInfos[unifiedMeshIndex].VertexStart;
        }

        /// <summary>
        /// 頂点ヒットテスト
        /// </summary>
        public int FindNearestVertex(Vector2 screenPos, float radius)
        {
            if (!_isInitialized)
                return -1;

            int globalIndex = _unifiedSystem.FindVertexAtScreenPos(screenPos, radius);

            if (globalIndex >= 0)
            {
                // グローバルインデックスをローカルに変換
                if (_unifiedSystem.GlobalToLocal(globalIndex, out int meshIndex, out int localIndex))
                {
                    // アクティブメッシュの頂点のみ返す（既存動作と互換）
                    if (meshIndex == _unifiedSystem.ActiveMeshIndex)
                    {
                        return localIndex;
                    }
                }
            }

            return -1;
        }

        /// <summary>
        /// ラインヒットテスト
        /// </summary>
        public int FindNearestLine(Vector2 screenPos, float radius)
        {
            if (!_isInitialized)
                return -1;

            int globalIndex = _unifiedSystem.FindLineAtScreenPos(screenPos, radius);

            // TODO: グローバル→ローカル変換
            return globalIndex;
        }

        /// <summary>
        /// ホバー頂点のローカルインデックスを取得
        /// </summary>
        public int GetHoveredVertexLocal()
        {
            if (!_isInitialized)
                return -1;

            if (_unifiedSystem.GetHoveredVertexLocal(out int meshIndex, out int localIndex))
            {
                if (meshIndex == _unifiedSystem.ActiveMeshIndex)
                {
                    return localIndex;
                }
            }

            return -1;
        }

        // ============================================================
        // 色設定
        // ============================================================

        /// <summary>
        /// 色設定を取得
        /// </summary>
        public ShaderColorSettings ColorSettings => _renderer?.ColorSettings;

        /// <summary>
        /// 色設定を変更
        /// </summary>
        public void SetColorSettings(ShaderColorSettings settings)
        {
            _renderer?.SetColorSettings(settings);
        }

        // ============================================================
        // カリング
        // ============================================================

        /// <summary>
        /// 指定メッシュのローカル頂点がカリング（背面）されているかを取得
        /// </summary>
        /// <param name="meshIndex">メッシュインデックス</param>
        /// <param name="localVertexIndex">ローカル頂点インデックス</param>
        /// <returns>カリングされている場合true</returns>
        public bool IsVertexCulled(int meshIndex, int localVertexIndex)
        {
            var bufferManager = _unifiedSystem?.BufferManager;
            if (!_isInitialized || bufferManager == null)
                return false;

            int globalIndex = bufferManager.LocalToGlobalVertexIndex(meshIndex, localVertexIndex);
            if (globalIndex < 0)
                return false;

            var vertexFlags = bufferManager.VertexFlags;
            if (vertexFlags == null || globalIndex >= vertexFlags.Length)
                return false;

            return (vertexFlags[globalIndex] & (uint)SelectionFlags.Culled) != 0;
        }

        /// <summary>
        /// 指定メッシュのローカル頂点が「表面の面に属さない」(背面カリング対象) かを取得。
        ///
        /// IsVertexCulled (_vertexFlags & FLAG_CULLED) は画面外判定専用で、
        /// 背面カリングの結果は反映されていない。本メソッドは GPU 側
        /// _VertexCulledBuffer を ReadBackVertexCulled で CPU に読み戻した
        /// _vertexCulledCache を参照する。矩形・投げ縄選択の CPU ループから使う。
        ///
        /// 呼出前に必ず ReadBackVertexCulled(slot) を呼ぶこと。
        /// </summary>
        public bool IsVertexBackfaceCulled(int meshIndex, int localVertexIndex)
        {
            var bufferManager = _unifiedSystem?.BufferManager;
            if (!_isInitialized || bufferManager == null)
                return false;

            int globalIndex = bufferManager.LocalToGlobalVertexIndex(meshIndex, localVertexIndex);
            if (globalIndex < 0)
                return false;

            var vertexCulled = bufferManager.VertexCulled;
            if (vertexCulled == null || globalIndex >= vertexCulled.Length)
                return false;

            return vertexCulled[globalIndex] != 0u;
        }

        /// <summary>
        /// GPUの頂点フラグをCPUに読み戻す。
        ///
        /// 呼出し元は MoveToolHandler.OnLeftDragEnd 内の矩形/投げ縄選択確定直前
        /// のワンショットのみ。ドラッグ中は UpdateMode が TransformDragging 等で
        /// AllowVertexFlagsReadback=false になっているが、本メソッドは矩形選択
        /// 確定時に CPU カリング判定を行うための必須処理のためガードを設けない。
        /// </summary>
        public void ReadBackVertexFlags()
        {
            _unifiedSystem?.BufferManager?.ReadBackVertexFlags();
        }

        /// <summary>
        /// 指定スロットの GPU 頂点カリングバッファを CPU キャッシュに読み戻す。
        /// 矩形選択・投げ縄選択の直前に呼ぶこと。IsVertexBackfaceCulled はこの
        /// キャッシュを参照する。
        ///
        /// ReadBackVertexFlags と同じ理由 (ワンショット呼出し) でガードは設けない。
        /// </summary>
        public void ReadBackVertexCulled(int slot = 0)
        {
            _unifiedSystem?.BufferManager?.ReadBackVertexCulled(slot);
        }

        // ============================================================
        // デバッグ
        // ============================================================

        /// <summary>
        /// 統計情報をログ出力
        /// </summary>
        public void LogStatus()
        {
            Debug.Log($"[UnifiedSystemAdapter] Initialized={_isInitialized}, UseUnifiedRendering={_useUnifiedRendering}");
            _unifiedSystem?.LogStatus();
        }

        // ============================================================
        // IDisposable
        // ============================================================

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _renderer?.Dispose();
                    _unifiedSystem?.Dispose();

                    if (_quadMesh != null)
                    {
                        UnityEngine.Object.DestroyImmediate(_quadMesh);
                        _quadMesh = null;
                    }
                }

                _disposed = true;
                _isInitialized = false;
            }
        }

        ~UnifiedSystemAdapter()
        {
            Dispose(false);
        }
    }
}