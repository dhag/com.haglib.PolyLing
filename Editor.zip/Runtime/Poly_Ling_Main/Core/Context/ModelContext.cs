// Assets/Editor/Poly_Ling/Model/ModelContext.cs
// ランタイム用モデルコンテキスト
// ModelDataのランタイム版 - SimpleMeshFactory内のモデルデータを一元管理
// v1.3: MeshListUndoContext統合（複数選択、Undoコールバック対応）

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Poly_Ling.EditorBridge;
using Poly_Ling.Data;
using Poly_Ling.Context;
using Poly_Ling.Ops;
using Poly_Ling.Tools;
using Poly_Ling.Symmetry;
using Poly_Ling.UndoSystem;
using Poly_Ling.Materials;

// MeshContextはSimpleMeshFactoryのネストクラスを参照
////using MeshContext = MeshContext;

namespace Poly_Ling.Context
{
    /// <summary>
    /// モデル全体のランタイムコンテキスト
    /// SimpleMeshFactory内のデータを一元管理
    /// Undo用コンテキストとしても使用（旧MeshListUndoContextを統合）
    /// </summary>
    public class ModelContext
    {
        // ================================================================
        // モデル情報
        // ================================================================

        /// <summary>モデル名</summary>
        public string Name { get; set; } = "Untitled";

        /// <summary>ファイルパス（保存済みの場合）</summary>
        public string FilePath { get; set; }

        /// <summary>変更フラグ</summary>
        public bool IsDirty { get; set; }

        /// <summary>
        /// インポート元ドキュメント（PMXDocument等）
        /// エクスポート時に物理データ等のパススルーに使用
        /// </summary>
        public object SourceDocument { get; set; }

        /// <summary>
        /// 各ボーンのPMXワールド位置（インポート時の初期位置）
        /// MikuMikuFlexの「ローカル位置」に相当。CCDIKSolverで使用。
        /// </summary>
        public Vector3[] BoneWorldPositions { get; set; }

        /// <summary>
        /// Tポーズ変換前の姿勢バックアップ（CSV保存対象）
        /// </summary>
        public TPoseBackup TPoseBackup { get; set; }

        // ================================================================
        // メッシュリスト
        // ================================================================

        /// <summary>メッシュコンテキストリスト</summary>
        public List<MeshContext> MeshContextList { get; set; } = new List<MeshContext>();

        /// <summary>メッシュ数</summary>
        public int Count => MeshContextList?.Count ?? 0;

        /// <summary>メッシュ数（後方互換）</summary>
        public int MeshContextCount => Count;

        // ================================================================
        // タイプ別メッシュインデックス
        // ================================================================

        /// <summary>タイプ別インデックスキャッシュ（遅延初期化）</summary>
        private TypedMeshIndices _typedIndices;

        /// <summary>
        /// タイプ別メッシュインデックスへのアクセス
        /// カテゴリ別のフィルタリングとボーンインデックス変換を提供
        /// </summary>
        public TypedMeshIndices TypedIndices
        {
            get
            {
                if (_typedIndices == null)
                    _typedIndices = new TypedMeshIndices(this);
                return _typedIndices;
            }
        }

        /// <summary>タイプ別インデックスキャッシュを無効化（リスト変更時に呼ぶ）</summary>
        public void InvalidateTypedIndices()
        {
            _typedIndices?.Invalidate();
        }

        // ================================================================
        // タイプ別アクセス（ショートカット）
        // ================================================================

        /// <summary>描画可能メッシュ（Mesh + BakedMirror）</summary>
        public IReadOnlyList<TypedMeshEntry> DrawableMeshes => TypedIndices.GetEntries(MeshCategory.Drawable);

        /// <summary>通常メッシュのみ</summary>
        public IReadOnlyList<TypedMeshEntry> Meshes => TypedIndices.GetEntries(MeshCategory.Mesh);

        /// <summary>ボーンリスト</summary>
        public IReadOnlyList<TypedMeshEntry> Bones => TypedIndices.GetEntries(MeshCategory.Bone);

        /// <summary>モーフリスト</summary>
        public IReadOnlyList<TypedMeshEntry> Morphs => TypedIndices.GetEntries(MeshCategory.Morph);

        /// <summary>剛体リスト</summary>
        public IReadOnlyList<TypedMeshEntry> RigidBodies => TypedIndices.GetEntries(MeshCategory.RigidBody);

        /// <summary>剛体ジョイントリスト</summary>
        public IReadOnlyList<TypedMeshEntry> RigidBodyJoints => TypedIndices.GetEntries(MeshCategory.RigidBodyJoint);

        /// <summary>ヘルパーリスト</summary>
        public IReadOnlyList<TypedMeshEntry> Helpers => TypedIndices.GetEntries(MeshCategory.Helper);

        /// <summary>グループリスト</summary>
        public IReadOnlyList<TypedMeshEntry> Groups => TypedIndices.GetEntries(MeshCategory.Group);

        /// <summary>ボーン数</summary>
        public int BoneCount => TypedIndices.BoneCount;

        /// <summary>描画可能メッシュ数</summary>
        public int DrawableCount => TypedIndices.DrawableCount;

        /// <summary>ボーンがあるか</summary>
        public bool HasBones => TypedIndices.HasBones;

        // ================================================================
        // 選択状態（カテゴリ別・複数選択対応）
        // v2.0: 選択メッシュ/選択ボーン/選択頂点モーフに分離
        // ================================================================

        /// <summary>選択カテゴリ</summary>
        public enum SelectionCategory { Mesh, Bone, Morph }

        /// <summary>現在アクティブな選択カテゴリ</summary>
        public SelectionCategory ActiveCategory { get; private set; } = SelectionCategory.Mesh;

        /// <summary>選択中のメッシュインデックス（Mesh, BakedMirror タイプ）- 選択順序を保持</summary>
        public List<int> SelectedDrawableMeshIndices { get; set; } = new List<int>();


        /// <summary>選択中のボーンインデックス（Bone タイプ）- 選択順序を保持</summary>
        public List<int> SelectedBoneIndices { get; set; } = new List<int>();

        /// <summary>選択中の頂点モーフインデックス（Morph タイプ）- 選択順序を保持</summary>
        public List<int> SelectedMorphIndices { get; set; } = new List<int>();



        /// <summary>メッシュが選択されているか</summary>
        public bool HasMeshSelection => SelectedDrawableMeshIndices.Count > 0;

        /// <summary>ボーンが選択されているか</summary>
        public bool HasBoneSelection => SelectedBoneIndices.Count > 0;

        /// <summary>頂点モーフが選択されているか</summary>
        public bool HasMorphSelection => SelectedMorphIndices.Count > 0;

        /// <summary>メッシュが複数選択されているか</summary>
        public bool IsMeshMultiSelected => SelectedDrawableMeshIndices.Count > 1;

        /// <summary>ボーンが複数選択されているか</summary>
        public bool IsBoneMultiSelected => SelectedBoneIndices.Count > 1;

        /// <summary>頂点モーフが複数選択されているか</summary>
        public bool IsMorphMultiSelected => SelectedMorphIndices.Count > 1;

        /// <summary>メッシュ選択リストの先頭インデックス</summary>
        public int FirstMeshIndex => SelectedDrawableMeshIndices.Count > 0 ? SelectedDrawableMeshIndices[0] : -1;

        /// <summary>ボーン選択リストの先頭インデックス</summary>
        public int FirstBoneIndex => SelectedBoneIndices.Count > 0 ? SelectedBoneIndices[0] : -1;

        /// <summary>モーフ選択リストの先頭インデックス</summary>
        public int FirstMorphIndex => SelectedMorphIndices.Count > 0 ? SelectedMorphIndices[0] : -1;

        // ================================================================
        // カテゴリ別選択操作
        // ================================================================

        /// <summary>Drawableメッシュを選択（単一選択・Mesh/BakedMirrorカテゴリ専用）</summary>
        public void SelectMesh(int index)
        {
            ClearMeshSelection();
            if (index >= 0 && index < Count)
            {
                SelectedDrawableMeshIndices.Add(index);
                ActiveCategory = SelectionCategory.Mesh;
            }
        }

        /// <summary>ボーンを選択（単一選択）</summary>
        public void SelectBone(int index)
        {
            ClearBoneSelection();
            if (index >= 0 && index < Count)
            {
                SelectedBoneIndices.Add(index);
                ActiveCategory = SelectionCategory.Bone;
            }
        }

        /// <summary>頂点モーフを選択（単一選択）</summary>
        public void SelectMorph(int index)
        {
            ClearMorphSelection();
            if (index >= 0 && index < Count)
            {
                SelectedMorphIndices.Add(index);
                ActiveCategory = SelectionCategory.Morph;
            }
        }

        /// <summary>メッシュ選択に追加（重複防止・順序保持）</summary>
        public void AddToMeshSelection(int index)
        {
            if (index >= 0 && index < Count && !SelectedDrawableMeshIndices.Contains(index))
            {
                SelectedDrawableMeshIndices.Add(index);
                ActiveCategory = SelectionCategory.Mesh;
            }
        }

        /// <summary>メッシュ選択をトグル（Ctrl+クリック用）</summary>
        public void ToggleMeshSelection(int index)
        {
            if (index < 0 || index >= Count) return;
            
            if (SelectedDrawableMeshIndices.Contains(index))
            {
                SelectedDrawableMeshIndices.Remove(index);
            }
            else
            {
                SelectedDrawableMeshIndices.Add(index);
            }
            ActiveCategory = SelectionCategory.Mesh;
        }

        /// <summary>メッシュ範囲選択（Shift+クリック用）</summary>
        public void SelectMeshRange(int fromIndex, int toIndex)
        {
            int start = Mathf.Min(fromIndex, toIndex);
            int end = Mathf.Max(fromIndex, toIndex);
            start = Mathf.Max(0, start);
            end = Mathf.Min(Count - 1, end);
            
            for (int i = start; i <= end; i++)
            {
                if (!SelectedDrawableMeshIndices.Contains(i))
                    SelectedDrawableMeshIndices.Add(i);
            }
            ActiveCategory = SelectionCategory.Mesh;
        }

        /// <summary>メッシュ選択から除去</summary>
        public void RemoveFromMeshSelection(int index)
        {
            SelectedDrawableMeshIndices.Remove(index);
        }

        /// <summary>ボーン選択に追加（重複防止・順序保持）</summary>
        public void AddToBoneSelection(int index)
        {
            if (index >= 0 && index < Count && !SelectedBoneIndices.Contains(index))
            {
                SelectedBoneIndices.Add(index);
                ActiveCategory = SelectionCategory.Bone;
            }
        }

        /// <summary>頂点モーフ選択に追加（重複防止・順序保持）</summary>
        public void AddToMorphSelection(int index)
        {
            if (index >= 0 && index < Count && !SelectedMorphIndices.Contains(index))
            {
                SelectedMorphIndices.Add(index);
                ActiveCategory = SelectionCategory.Morph;
            }
        }

        /// <summary>メッシュ選択をクリア</summary>
        public void ClearMeshSelection() => SelectedDrawableMeshIndices.Clear();

        /// <summary>ボーン選択をクリア</summary>
        public void ClearBoneSelection() => SelectedBoneIndices.Clear();

        /// <summary>頂点モーフ選択をクリア</summary>
        public void ClearMorphSelection() => SelectedMorphIndices.Clear();

        /// <summary>
        /// アクティブ選択カテゴリを設定する。
        /// リモート選択反映（軽量クライアント）で選択リストと併せて復元するために使用。
        /// </summary>
        public void SetActiveCategory(SelectionCategory category) => ActiveCategory = category;

        // ================================================================
        // 後方互換プロパティ（全カテゴリ統合ビュー）
        // ================================================================

        /// <summary>
        /// 選択中の全インデックス（読み取り専用）
        /// 設定にはSelect/SelectMesh/SelectBone/SelectMorph等を使用
        /// </summary>
        public HashSet<int> SelectedMeshContextIndices
        {
            get
            {
                var all = new HashSet<int>(SelectedDrawableMeshIndices);
                foreach (var i in SelectedBoneIndices)
                    all.Add(i);
                foreach (var i in SelectedMorphIndices)
                    all.Add(i);
                return all;
            }
        }

        /// <summary>ActiveCategoryの選択インデックスリスト</summary>
        public List<int> ActiveSelectedIndices
        {
            get
            {
                return ActiveCategory switch
                {
                    SelectionCategory.Mesh => SelectedDrawableMeshIndices,
                    SelectionCategory.Bone => SelectedBoneIndices,
                    SelectionCategory.Morph => SelectedMorphIndices,
                    _ => new List<int>()
                };
            }
        }

        /// <summary>選択があるか</summary>
        public bool HasSelection => HasMeshSelection || HasBoneSelection || HasMorphSelection;

        /// <summary>複数選択されているか</summary>
        public bool IsMultiSelected => SelectedMeshContextIndices.Count > 1;

        /// <summary>選択中の全MeshContext（ActiveCategory準拠）</summary>
        public List<MeshContext> SelectedMeshContexts
        {
            get
            {
                var result = new List<MeshContext>();
                foreach (int idx in ActiveSelectedIndices)
                {
                    if (idx >= 0 && idx < Count)
                        result.Add(MeshContextList[idx]);
                }
                return result;
            }
        }

        /// <summary>選択リストの先頭MeshContext（便宜アクセサ・特別扱いではない）</summary>
        public MeshContext FirstSelectedMeshContext
        {
            get
            {
                var indices = ActiveSelectedIndices;
                if (indices.Count == 0) return null;
                int idx = indices[0];
                return (idx >= 0 && idx < Count) ? MeshContextList[idx] : null;
            }
        }

        /// <summary>
        /// ActiveCategoryに依存せず、常にSelectedMeshIndicesから描画メッシュを返す。
        /// SelectBoneでActiveCategoryがBoneに変わっても描画メッシュ参照を維持する。
        /// 用途: SkinWeightPaintTool/Panel等、ボーン選択中も描画メッシュへの参照が必要な場面。
        /// </summary>
        public MeshContext FirstDrawableMeshContext
        {
            get
            {
                if (SelectedDrawableMeshIndices.Count == 0) return null;
                int idx = SelectedDrawableMeshIndices[0];
                return (idx >= 0 && idx < Count) ? MeshContextList[idx] : null;
            }
        }

        // ================================================================
        // 編集対象メッシュの取得元（一本化）
        // ================================================================
        //
        // FirstSelectedMeshContext は ActiveCategory が Bone/Morph のとき
        // メッシュ以外を指し得る。FirstDrawableMeshContext は常に描画メッシュを返す。
        // メッシュ編集ツール・ハンドラ・オーバーレイは必ず ActiveMeshContext /
        // ActiveMeshIndex を使うこと。MeshObject と行列の取得元がずれると座標がずれる。
        // ================================================================

        /// <summary>編集対象メッシュ（描画メッシュ優先）。</summary>
        public MeshContext ActiveMeshContext => FirstDrawableMeshContext ?? FirstSelectedMeshContext;

        /// <summary>編集対象メッシュの MeshContextList インデックス。未解決は -1。</summary>
        public int ActiveMeshIndex
        {
            get
            {
                if (SelectedDrawableMeshIndices.Count > 0) return SelectedDrawableMeshIndices[0];
                return FirstSelectedIndex;
            }
        }

        /// <summary>選択リストの先頭インデックス（便宜アクセサ）</summary>
        public int FirstSelectedIndex
        {
            get
            {
                var indices = ActiveSelectedIndices;
                return indices.Count > 0 ? indices[0] : -1;
            }
        }

        /// <summary>有効なメッシュコンテキストが選択されているか</summary>
        public bool HasValidMeshContextSelection => ActiveSelectedIndices.Count > 0 && ActiveSelectedIndices[0] >= 0 && ActiveSelectedIndices[0] < Count;

        // ================================================================
        // カテゴリ別選択ヘルパー
        // ================================================================

        /// <summary>タイプに基づいて適切なカテゴリに選択を追加（重複防止）</summary>
        public void AddMeshContextToSelection(int index)
        {
            if (index < 0 || index >= Count) return;
            var meshContext = MeshContextList[index];
            if (meshContext == null) return;

            switch (meshContext.Type)
            {
                case MeshType.Bone:
                    if (!SelectedBoneIndices.Contains(index))
                        SelectedBoneIndices.Add(index);
                    ActiveCategory = SelectionCategory.Bone;
                    break;
                case MeshType.Morph:
                    if (!SelectedMorphIndices.Contains(index))
                        SelectedMorphIndices.Add(index);
                    ActiveCategory = SelectionCategory.Morph;
                    break;
                default:
                    // Mesh, BakedMirror, Helper, Group, RigidBody, RigidBodyJoint等
                    if (!SelectedDrawableMeshIndices.Contains(index))
                        SelectedDrawableMeshIndices.Add(index);
                    ActiveCategory = SelectionCategory.Mesh;
                    break;
            }
        }

        /// <summary>
        /// タイプに基づいて同一カテゴリのみをクリアして選択（他カテゴリは維持）
        /// メインパネルでの選択操作用
        /// </summary>
        public void SelectMeshContextExclusive(int index)
        {
            if (index < 0 || index >= Count) return;
            var meshContext = MeshContextList[index];
            if (meshContext == null) return;

            switch (meshContext.Type)
            {
                case MeshType.Bone:
                    ClearBoneSelection();
                    SelectedBoneIndices.Add(index);
                    ActiveCategory = SelectionCategory.Bone;
                    break;
                case MeshType.Morph:
                    ClearMorphSelection();
                    SelectedMorphIndices.Add(index);
                    ActiveCategory = SelectionCategory.Morph;
                    break;
                default:
                    // Mesh, BakedMirror, Helper, Group, RigidBody, RigidBodyJoint等
                    ClearMeshSelection();
                    SelectedDrawableMeshIndices.Add(index);
                    ActiveCategory = SelectionCategory.Mesh;
                    break;
            }
        }

        /// <summary>タイプに基づいて適切なカテゴリから選択を解除</summary>
        public void RemoveFromSelectionByCategory(int index)
        {
            if (index < 0 || index >= Count) return;
            var meshContext = MeshContextList[index];
            if (meshContext == null) return;
            switch (meshContext.Type)
            {
                case MeshType.Bone:
                    SelectedBoneIndices.Remove(index);
                    break;
                case MeshType.Morph:
                    SelectedMorphIndices.Remove(index);
                    break;
                default:
                    SelectedDrawableMeshIndices.Remove(index);
                    break;
            }
        }

        /// <summary>指定インデックスがどのカテゴリで選択されているか確認</summary>
        public bool IsSelectedInAnyCategory(int index)
        {
            return SelectedDrawableMeshIndices.Contains(index) ||
                   SelectedBoneIndices.Contains(index) ||
                   SelectedMorphIndices.Contains(index);
        }

        /// <summary>全カテゴリの選択をクリア</summary>
        public void ClearAllCategorySelection()
        {
            SelectedDrawableMeshIndices.Clear();
            SelectedBoneIndices.Clear();
            SelectedMorphIndices.Clear();
            SelectedDrawableMeshIndices.Clear();
        }

        // ================================================================
        // Undoコールバック（旧MeshListUndoContextから統合）
        // ================================================================

        /// <summary>Undo/Redo実行後のコールバック（UI更新等）</summary>
        public Action OnListChanged;

        /// <summary>カメラ状態復元リクエスト時のコールバック（MeshSelectionChangeRecord用）</summary>
        public Action<CameraSnapshot> OnCameraRestoreRequested;
        
        /// <summary>MeshListStackへのフォーカス切り替えリクエスト</summary>
        public Action OnFocusMeshListRequested;

        /// <summary>メッシュリスト順序変更後のCG再構築リクエスト</summary>
        public Action OnReorderCompleted;

        /// <summary>VertexEditStackクリアリクエスト（メッシュ順序変更で古い記録が無効になるため）</summary>
        public Action OnVertexEditStackClearRequested;

        /// <summary>選択ボーンのTransform変更通知（UI→UndoHelperへの橋渡し）</summary>
        public Action<BoneTransformSnapshot, BoneTransformSnapshot, string> OnBoneTransformChanged;

        // ================================================================
        // WorkPlaneContext
        // ================================================================

        /// <summary>作業平面</summary>
        public WorkPlaneContext WorkPlane { get; set; }

        // ================================================================
        // WorkAxisContext（作業用ローカル軸）
        // ================================================================

        /// <summary>
        /// 作業用ローカル軸。回転 / 曲げの基準フレーム。Origin はワールド座標。
        /// null にはせず常にインスタンスを持たせる（呼び出し側の null 判定を減らすため）。
        /// </summary>
        public WorkAxisContext WorkAxis { get; set; } = new WorkAxisContext();

        // ================================================================
        // MorphExpressions（モーフグループ管理）
        // ================================================================

        /// <summary>モーフエクスプレッションリスト</summary>
        public List<MorphExpression> MorphExpressions { get; set; } = new List<MorphExpression>();

        /// <summary>モーフエクスプレッション数</summary>
        public int MorphExpressionCount => MorphExpressions?.Count ?? 0;

        /// <summary>モーフエクスプレッションがあるか</summary>
        public bool HasMorphExpressions => MorphExpressionCount > 0;

        /// <summary>モーフエクスプレッションを追加</summary>
        public MorphExpression AddMorphExpression(string name, MorphType type = MorphType.Vertex)
        {
            var set = new MorphExpression(name, type);
            MorphExpressions.Add(set);
            return set;
        }

        /// <summary>モーフエクスプレッションを削除</summary>
        public bool RemoveMorphExpression(MorphExpression set)
        {
            return MorphExpressions.Remove(set);
        }

        /// <summary>名前でモーフエクスプレッションを検索</summary>
        public MorphExpression FindMorphExpressionByName(string name)
        {
            return MorphExpressions.Find(s => s.Name == name);
        }

        /// <summary>メッシュインデックスでモーフエクスプレッションを検索</summary>
        public MorphExpression FindMorphExpressionByMesh(int meshIndex)
        {
            return MorphExpressions.Find(s => s.ContainsMesh(meshIndex));
        }

        /// <summary>一意なモーフエクスプレッション名を生成</summary>
        public string GenerateUniqueMorphExpressionName(string baseName = "Morph")
        {
            string name = baseName;
            int counter = 1;

            while (FindMorphExpressionByName(name) != null)
            {
                name = $"{baseName}_{counter}";
                counter++;
            }

            return name;
        }
        
        // ================================================================
        // MeshSelectionSets（メッシュ選択セット・名前ベース）
        // ================================================================

        /// <summary>メッシュ選択セットリスト</summary>
        public List<MeshSelectionSet> MeshSelectionSets { get; set; } = new List<MeshSelectionSet>();

        /// <summary>メッシュ選択セット数</summary>
        public int MeshSelectionSetCount => MeshSelectionSets?.Count ?? 0;

        /// <summary>メッシュ選択セットがあるか</summary>
        public bool HasMeshSelectionSets => MeshSelectionSetCount > 0;

        /// <summary>現在の選択をメッシュ選択セットとして保存</summary>
        public MeshSelectionSet SaveCurrentMeshSelectionAsSet(string name, SelectionCategory category)
        {
            var set = MeshSelectionSet.FromCurrentSelection(name, this, category);
            MeshSelectionSets.Add(set);
            return set;
        }

        /// <summary>メッシュ選択セットを削除</summary>
        public bool RemoveMeshSelectionSet(MeshSelectionSet set)
        {
            return MeshSelectionSets.Remove(set);
        }

        /// <summary>名前でメッシュ選択セットを検索</summary>
        public MeshSelectionSet FindMeshSelectionSetByName(string name)
        {
            return MeshSelectionSets.Find(s => s.Name == name);
        }

        /// <summary>一意なメッシュ選択セット名を生成</summary>
        public string GenerateUniqueMeshSelectionSetName(string baseName = "MeshSet")
        {
            string name = baseName;
            int counter = 1;
            while (FindMeshSelectionSetByName(name) != null)
            {
                name = $"{baseName}_{counter}";
                counter++;
            }
            return name;
        }

        /// <summary>名前で描画オブジェクト(MeshContext)を検索。見つからなければ null。</summary>
        public MeshContext FindMeshContextByName(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            return MeshContextList.Find(mc => mc != null && mc.Name == name);
        }

        /// <summary>
        /// 一意な描画オブジェクト名を生成する。
        /// 既存名と衝突する場合のみ _1, _2 ... を付ける（規則は選択セット名と同じ）。
        /// </summary>
        public string GenerateUniqueMeshName(string baseName = "Mesh")
        {
            if (string.IsNullOrEmpty(baseName)) baseName = "Mesh";

            string name = baseName;
            int counter = 1;
            while (FindMeshContextByName(name) != null)
            {
                name = $"{baseName}_{counter}";
                counter++;
            }
            return name;
        }

        // ================================================================
        // Materials（モデル単位で実データを保持）
        // MaterialReference によるパラメータ＋キャッシュ管理
        // ================================================================
        
        // v1.2: 空リストで初期化（インポート時に自動追加されないように）
        private List<MaterialReference> _materialRefs = new List<MaterialReference>();
        private int _currentMaterialIndex = 0;
        
        /// <summary>
        /// マテリアル参照リスト（新API）
        /// パラメータデータ＋アセットパス＋キャッシュを管理
        /// </summary>
        public List<MaterialReference> MaterialReferences
        {
            get => _materialRefs;
            set => _materialRefs = value ?? new List<MaterialReference>();
        }
        
        /// <summary>
        /// マテリアルリスト（後方互換API）
        /// 内部的にはMaterialReferenceから取得/設定
        /// </summary>
        public List<Material> Materials
        {
            get => _materialRefs.Select(r => r?.Material).ToList();
            set
            {
                if (value == null || value.Count == 0)
                {
                    _materialRefs = new List<MaterialReference>();
                }
                else
                {
                    _materialRefs = value.Select(m => new MaterialReference(m)).ToList();
                }
            }
        }
        
        /// <summary>
        /// 現在選択中のマテリアルインデックス
        /// </summary>
        public int CurrentMaterialIndex
        {
            get => _currentMaterialIndex;
            set => _currentMaterialIndex = value;
        }
        
        // ================================================================
        // デフォルトマテリアル設定
        // ================================================================
        
        private List<MaterialReference> _defaultMaterialRefs = new List<MaterialReference> { new MaterialReference() };
        
        /// <summary>新規メッシュ作成時に適用されるデフォルトマテリアル参照リスト</summary>
        public List<MaterialReference> DefaultMaterialReferences
        {
            get => _defaultMaterialRefs;
            set => _defaultMaterialRefs = value ?? new List<MaterialReference> { new MaterialReference() };
        }
        
        /// <summary>新規メッシュ作成時に適用されるデフォルトマテリアルリスト（後方互換API）</summary>
        public List<Material> DefaultMaterials
        {
            get => _defaultMaterialRefs.Select(r => r?.Material).ToList();
            set
            {
                if (value == null || value.Count == 0)
                {
                    _defaultMaterialRefs = new List<MaterialReference> { new MaterialReference() };
                }
                else
                {
                    _defaultMaterialRefs = value.Select(m => new MaterialReference(m)).ToList();
                }
            }
        }
        
        /// <summary>新規メッシュ作成時に適用されるデフォルトカレントマテリアルインデックス</summary>
        public int DefaultCurrentMaterialIndex { get; set; } = 0;
        
        /// <summary>マテリアル変更時に自動でデフォルトに設定するか</summary>
        public bool AutoSetDefaultMaterials { get; set; } = true;
        
        // ================================================================
        // マテリアル操作ヘルパーメソッド
        // ================================================================
        
        /// <summary>マテリアル数</summary>
        public int MaterialCount => _materialRefs.Count;
        
        /// <summary>インデックスでマテリアルを取得</summary>
        public Material GetMaterial(int index)
        {
            if (index < 0 || index >= _materialRefs.Count)
                return null;
            return _materialRefs[index]?.Material;
        }
        
        /// <summary>インデックスでマテリアルを設定</summary>
        public void SetMaterial(int index, Material mat)
        {
            if (index < 0 || index >= _materialRefs.Count)
                return;
            _materialRefs[index] = new MaterialReference(mat);
        }
        
        /// <summary>マテリアルを追加</summary>
        public void AddMaterial(Material mat)
        {
            _materialRefs.Add(new MaterialReference(mat));
        }
        
        /// <summary>インデックスでマテリアルを削除</summary>
        public void RemoveMaterialAt(int index)
        {
            if (index < 0 || index >= _materialRefs.Count)
                return;
            if (_materialRefs.Count <= 1)
                return; // 最低1つは残す
            
            _materialRefs.RemoveAt(index);
            
            // CurrentMaterialIndexを調整
            if (_currentMaterialIndex >= _materialRefs.Count)
            {
                _currentMaterialIndex = _materialRefs.Count - 1;
            }
        }
        
        /// <summary>全マテリアルをクリア（1つのnullマテリアルにリセット）</summary>
        public void ClearMaterials()
        {
            _materialRefs.Clear();
            _materialRefs.Add(new MaterialReference());
            _currentMaterialIndex = 0;
        }
        
        /// <summary>インデックスでマテリアル参照を取得</summary>
        public MaterialReference GetMaterialReference(int index)
        {
            if (index < 0 || index >= _materialRefs.Count)
                return null;
            return _materialRefs[index];
        }
        
        /// <summary>マテリアルリストを一括設定</summary>
        public void SetMaterials(IList<Material> materials)
        {
            if (materials == null || materials.Count == 0)
            {
                _materialRefs = new List<MaterialReference> { new MaterialReference() };
            }
            else
            {
                _materialRefs = materials.Select(m => new MaterialReference(m)).ToList();
            }
        }
        
        /// <summary>オンメモリマテリアル（アセット未保存）があるか</summary>
        public bool HasOnMemoryMaterials()
        {
            return _materialRefs.Any(r => r != null && !r.HasAssetPath && r.Material != null);
        }
        
        /// <summary>オンメモリマテリアルをアセットとして保存</summary>
        /// <param name="saveDir">保存先ディレクトリ（Assets/...）</param>
        /// <returns>保存したマテリアル数</returns>
        public int SaveOnMemoryMaterialsAsAssets(string saveDir)
        {
            if (string.IsNullOrEmpty(saveDir))
                return 0;
            
            // ディレクトリを作成
            if (!System.IO.Directory.Exists(saveDir))
            {
                System.IO.Directory.CreateDirectory(saveDir);
                PLEditorBridge.I.Refresh();
            }
            
            int savedCount = 0;
            for (int i = 0; i < _materialRefs.Count; i++)
            {
                var matRef = _materialRefs[i];
                if (matRef == null || matRef.HasAssetPath || matRef.Material == null)
                    continue;
                
                // ファイル名を生成
                string matName = matRef.Name ?? $"Material_{i}";
                // 無効な文字を置換
                foreach (char c in System.IO.Path.GetInvalidFileNameChars())
                {
                    matName = matName.Replace(c, '_');
                }
                
                string savePath = $"{saveDir}/{matName}.mat";

                // 決定論パス：同名は同一 .mat に収束（_counter 廃止）。
                // 既存があれば SaveAsAsset 内で内容上書き（GUID/参照保持）＝増殖しない。
                if (matRef.SaveAsAsset(savePath))
                {
                    savedCount++;
                }
            }
            
            return savedCount;
        }

        // ================================================================
        // 対称設定
        // ================================================================

        /// <summary>対称モード設定</summary>
        public SymmetrySettings SymmetrySettings { get; } = new SymmetrySettings();

        // ================================================================
        // ミラーペア
        // ================================================================

        /// <summary>ミラーペアのリスト（実体側↔ミラー側の対応）</summary>
        public List<MirrorPair> MirrorPairs { get; set; } = new List<MirrorPair>();

        // ================================================================
        // スプリングボーン・コライダーグループ（モデルレベル：名前のみ保持）
        //   VRM SpringBone の colliderGroups に相当。ここには名前だけを持ち、
        //   index＝この並び順。コライダー本体は各ボーンの
        //   MeshObject.SpringBoneColliders が保持し、所属は index で参照する。
        // ================================================================

        /// <summary>スプリングボーン・コライダーグループ名リスト（index＝並び順）。</summary>
        public List<string> SpringBoneColliderGroupNames { get; set; } = new List<string>();

        /// <summary>
        /// 指定MeshContextが属するMirrorPairを取得（実体側・ミラー側どちらでも検索）
        /// </summary>
        public MirrorPair GetMirrorPair(MeshContext meshContext)
        {
            if (meshContext == null || MirrorPairs == null) return null;
            for (int i = 0; i < MirrorPairs.Count; i++)
            {
                var pair = MirrorPairs[i];
                if (pair.Real == meshContext || pair.Mirror == meshContext)
                    return pair;
            }
            return null;
        }

        /// <summary>
        /// 指定MeshContextがミラー側（編集不可側）かどうか
        /// MirrorPair方式と旧BakedMirror方式の両方をチェック
        /// </summary>
        public bool IsMirrorSide(MeshContext meshContext)
        {
            if (meshContext == null) return false;

            // 旧BakedMirror方式
            if (meshContext.IsBakedMirror) return true;

            // MirrorPair方式
            if (MirrorPairs != null)
            {
                for (int i = 0; i < MirrorPairs.Count; i++)
                {
                    if (MirrorPairs[i].Mirror == meshContext)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// 指定MeshContextが実体側（ミラー元）かどうか
        /// </summary>
        public bool IsRealSide(MeshContext meshContext)
        {
            if (meshContext == null || MirrorPairs == null) return false;
            for (int i = 0; i < MirrorPairs.Count; i++)
            {
                if (MirrorPairs[i].Real == meshContext)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// 全ミラーペアの位置を同期する（Real→Mirror）
        /// </summary>
        public void SyncAllMirrorPositions()
        {
            if (MirrorPairs == null) return;
            for (int i = 0; i < MirrorPairs.Count; i++)
            {
                MirrorPairs[i].SyncPositions();
            }
        }

        /// <summary>
        /// モーフMeshContextのミラー側カウンターパートを検索する。
        /// MorphParentIndex→MirrorPair→同一MorphExpression内のミラー側モーフを返す。
        /// </summary>
        /// <param name="morphCtx">Real側のモーフMeshContext</param>
        /// <returns>Mirror側のモーフMeshContext、見つからない場合null</returns>
        public MeshContext FindMirrorMorph(MeshContext morphCtx)
        {
            if (morphCtx == null || !morphCtx.IsMorph) return null;

            // モーフの親メッシュを取得
            int parentIdx = morphCtx.MorphParentIndex;
            if (parentIdx < 0 || parentIdx >= Count) return null;
            var parentCtx = GetMeshContext(parentIdx);

            // 親メッシュのMirrorPairを検索（Real側であること）
            var pair = GetMirrorPair(parentCtx);
            if (pair == null || pair.Real != parentCtx) return null;

            // Mirror側親メッシュのインデックス
            int mirrorParentIdx = MeshContextList.IndexOf(pair.Mirror);
            if (mirrorParentIdx < 0) return null;

            // このモーフが属するMorphExpressionを検索
            int morphIdx = MeshContextList.IndexOf(morphCtx);
            if (morphIdx < 0) return null;

            foreach (var expr in MorphExpressions)
            {
                bool containsThisMorph = false;
                for (int i = 0; i < expr.MeshEntries.Count; i++)
                {
                    if (expr.MeshEntries[i].MeshIndex == morphIdx)
                    {
                        containsThisMorph = true;
                        break;
                    }
                }
                if (!containsThisMorph) continue;

                // 同じMorphExpression内でMirror側親のモーフを検索
                for (int i = 0; i < expr.MeshEntries.Count; i++)
                {
                    int candidateIdx = expr.MeshEntries[i].MeshIndex;
                    if (candidateIdx == morphIdx) continue;
                    if (candidateIdx < 0 || candidateIdx >= Count) continue;

                    var candidate = GetMeshContext(candidateIdx);
                    if (candidate != null && candidate.IsMorph && candidate.MorphParentIndex == mirrorParentIdx)
                        return candidate;
                }
            }

            return null;
        }

        // ================================================================
        // Humanoidボーンマッピング
        // ================================================================

        /// <summary>Humanoid Avatar用のボーンマッピング</summary>
        private HumanoidBoneMapping _humanoidMapping = new HumanoidBoneMapping();

        /// <summary>Humanoidボーンマッピング</summary>
        public HumanoidBoneMapping HumanoidMapping => _humanoidMapping;

        // ================================================================
        // コンストラクタ
        // ================================================================

        public ModelContext()
        {
        }

        public ModelContext(string name)
        {
            Name = name;
        }

        // ================================================================
        // 選択操作（カテゴリ対応・旧MeshListUndoContextから統合）
        // ================================================================

        /// <summary>全選択をクリア（後方互換）</summary>
        public void ClearSelection()
        {
            ClearAllCategorySelection();
        }

        /// <summary>単一選択（既存選択をクリアして選択・タイプ自動判定）</summary>
        public void Select(int index)
        {
            ClearAllCategorySelection();
            if (index >= 0 && index < Count)
                AddMeshContextToSelection(index);
        }

        /// <summary>選択を追加（タイプ自動判定）</summary>
        public void AddToSelection(int index)
        {
            if (index >= 0 && index < Count)
                AddMeshContextToSelection(index);
        }

        /// <summary>選択を解除（全カテゴリ）</summary>
        public void RemoveFromSelection(int index)
        {
            RemoveFromSelectionByCategory(index);
        }

        /// <summary>選択をトグル（タイプ自動判定）</summary>
        public void ToggleMeshContextSelection(int index)
        {
            if (IsSelectedInAnyCategory(index))
                RemoveFromSelectionByCategory(index);
            else if (index >= 0 && index < Count)
                AddMeshContextToSelection(index);
        }

        /// <summary>範囲選択（from から to まで・タイプ自動判定）</summary>
        public void SelectRange(int from, int to)
        {
            int min = Mathf.Min(from, to);
            int max = Mathf.Max(from, to);
            for (int i = min; i <= max; i++)
            {
                if (i >= 0 && i < Count)
                    AddMeshContextToSelection(i);
            }
        }

        /// <summary>全選択（タイプ自動判定）</summary>
        public void SelectAll()
        {
            ClearAllCategorySelection();
            for (int i = 0; i < Count; i++)
                AddMeshContextToSelection(i);
        }

        /// <summary>インデックスセットから選択状態を復元（Undo用）</summary>
        public void RestoreSelectionFromIndices(IEnumerable<int> indices)
        {
            ClearAllCategorySelection();
            if (indices == null) return;
            foreach (var index in indices)
            {
                if (index >= 0 && index < Count)
                    AddMeshContextToSelection(index);
            }
        }

        /// <summary>選択されているか（全カテゴリ）</summary>
        public bool IsSelected(int index)
        {
            return IsSelectedInAnyCategory(index);
        }

        /// <summary>選択インデックスを検証して無効なものを除去（全カテゴリ）</summary>
        public void ValidateSelection()
        {
            SelectedDrawableMeshIndices.RemoveAll(i => i < 0 || i >= Count);
            SelectedBoneIndices.RemoveAll(i => i < 0 || i >= Count);
            SelectedMorphIndices.RemoveAll(i => i < 0 || i >= Count);
        }

        /// <summary>全カテゴリの選択インデックスをフラットリストとして取得（Undo記録用）</summary>
        public List<int> CaptureAllSelectedIndices()
        {
            var indices = new List<int>(SelectedDrawableMeshIndices.Count + SelectedBoneIndices.Count + SelectedMorphIndices.Count);
            indices.AddRange(SelectedDrawableMeshIndices);
            indices.AddRange(SelectedBoneIndices);
            indices.AddRange(SelectedMorphIndices);
            return indices;
        }

        // ================================================================
        // リスト構造変更に伴う索引参照の付け替え
        //
        // 【なぜ要るか】
        //   MeshContext は他要素を「MeshContextList の索引」で指す。
        //     ParentIndex / HierarchyParentIndex … 階層
        //     MorphParentIndex                   … モーフの所属
        //     BakedMirrorSourceIndex             … ミラーの実体側
        //   さらに ModelContext 側にも索引参照がある。
        //     HumanoidMapping (name→index)       … Avatar 割当
        //     TPoseBackup      (index→姿勢)      … T ポーズ退避
        //   Insert / RemoveAt / Move はこれらを一切詰め直していなかったため、
        //   ミラーの付け外し（EnableMirror/DisableMirror が Insert/RemoveAt を呼ぶ）
        //   のたびに階層と Avatar 割当が静かに壊れていた。
        //
        // 【表の意味】
        //   map[old] = new。new が -1 なら「その要素は消えた」。
        //   親系フィールドは -1 のとき祖先へ繰り上げる（BuildRemoveMap が解決済み）。
        // ================================================================

        /// <summary>挿入用の付け替え表を作る。newCount は挿入後の件数。</summary>
        private static int[] BuildInsertMap(int oldCount, int insertIndex)
        {
            var map = new int[oldCount];
            for (int i = 0; i < oldCount; i++)
                map[i] = i >= insertIndex ? i + 1 : i;
            return map;
        }

        /// <summary>
        /// 削除用の付け替え表を作る（削除前に呼ぶこと）。
        /// 削除された要素は -1 ではなく「削除要素の親」へ繰り上げる。
        /// 子を根へ吹き飛ばさないため。祖先も削除されていれば更に上へたどる。
        /// </summary>
        private int[] BuildRemoveMap(int removeIndex)
        {
            int oldCount = MeshContextList.Count;
            var map = new int[oldCount];

            for (int i = 0; i < oldCount; i++)
                map[i] = i < removeIndex ? i : (i == removeIndex ? -1 : i - 1);

            // 削除要素の親へ繰り上げる（自己参照・循環はカウンタで打ち切る）。
            int cur = MeshContextList[removeIndex]?.HierarchyParentIndex ?? -1;
            int safety = oldCount + 1;
            while (cur >= 0 && cur < oldCount && cur == removeIndex && safety-- > 0)
                cur = MeshContextList[cur]?.HierarchyParentIndex ?? -1;

            map[removeIndex] = (cur >= 0 && cur < oldCount) ? map[cur] : -1;
            return map;
        }

        /// <summary>移動用の付け替え表を作る。count は移動後（＝移動前）の件数。</summary>
        private static int[] BuildMoveMap(int count, int fromIndex, int toIndex)
        {
            var map = new int[count];
            for (int i = 0; i < count; i++)
            {
                if (i == fromIndex)                       map[i] = toIndex;
                else if (fromIndex < toIndex)             map[i] = (i > fromIndex && i <= toIndex) ? i - 1 : i;
                else                                      map[i] = (i >= toIndex && i < fromIndex) ? i + 1 : i;
            }
            return map;
        }

        /// <summary>
        /// 並べ替え（MeshContextList をまるごと差し替える操作）のあとに索引参照を付け替える。
        ///
        /// oldOrder は差し替え前の並び。実体の参照一致で新しい位置を引くので、
        /// 「どの要素がどこへ動いたか」を呼び出し側が計算しなくてよい。
        /// 新リストに居ない実体は -1 へ落ちる。
        ///
        /// 付け替える中身は Insert / RemoveAt / Move と同じ RemapIndexReferences。
        /// 索引参照フィールドの列挙をここに複製しないこと。
        /// </summary>
        public void RemapIndexReferencesAfterReorder(IReadOnlyList<MeshContext> oldOrder)
        {
            if (oldOrder == null || oldOrder.Count == 0) return;
            if (MeshContextList == null) return;

            var newIndexOf = new Dictionary<MeshContext, int>(MeshContextList.Count);
            for (int i = 0; i < MeshContextList.Count; i++)
            {
                var mc = MeshContextList[i];
                if (mc != null) newIndexOf[mc] = i;
            }

            var map = new int[oldOrder.Count];
            for (int i = 0; i < oldOrder.Count; i++)
            {
                var mc = oldOrder[i];
                map[i] = (mc != null && newIndexOf.TryGetValue(mc, out int ni)) ? ni : -1;
            }

            RemapIndexReferences(map);
        }

        /// <summary>索引で他要素を指している全参照を付け替える。</summary>
        private void RemapIndexReferences(int[] map)
        {
            if (map == null) return;

            int Map(int old)
            {
                if (old < 0 || old >= map.Length) return -1;
                return map[old];
            }

            // 1) メッシュ側の索引参照
            for (int i = 0; i < MeshContextList.Count; i++)
            {
                var mc = MeshContextList[i];
                if (mc == null) continue;

                // ParentIndex は HierarchyParentIndex と同じ入れ物なので 1 回だけ写す。
                // 2 回書くと +1 が 2 度掛かり、親が 1 つ先の要素（多くは自分自身）を指す。
                if (mc.HierarchyParentIndex >= 0) mc.HierarchyParentIndex = Map(mc.HierarchyParentIndex);
                if (mc.MorphParentIndex     >= 0) mc.MorphParentIndex     = Map(mc.MorphParentIndex);

                // 左右対のボーン索引。スキンド変換が確定させた値なので、
                // 索引が動いたら必ず付け替える（切らない）。
                if (mc.MirrorBoneIndex      >= 0) mc.MirrorBoneIndex      = Map(mc.MirrorBoneIndex);

                // ミラー元が消えたらミラーとしての意味を失うので関係ごと切る。
                if (mc.BakedMirrorSourceIndex >= 0)
                    mc.BakedMirrorSourceIndex = Map(mc.BakedMirrorSourceIndex);
            }

            // 2) Humanoid 割当（実行時 working 表現）
            //    per-bone の HumanBodyBone が canonical だが、保存時に
            //    SyncPerBoneFromMapping がこの Dict を per-bone へ書き戻すため、
            //    ここが stale だと canonical まで壊れる。
            if (_humanoidMapping != null && !_humanoidMapping.IsEmpty)
            {
                var remapped = new Dictionary<string, int>();
                foreach (var kv in _humanoidMapping.BoneIndexMap)
                {
                    int ni = Map(kv.Value);
                    if (ni >= 0 && ni < MeshContextList.Count) remapped[kv.Key] = ni;
                }
                _humanoidMapping.FromDictionary(remapped);
            }

            // 3) T ポーズ退避（索引をキーに持つ Dictionary 群）
            TPoseBackup?.RemapIndices(Map);
        }

        // ================================================================
        // メッシュリスト操作
        // ================================================================

        /// <summary>メッシュを追加</summary>
        /// <returns>追加されたインデックス</returns>
        public int Add(MeshContext meshContext)
        {
            if (meshContext == null)
                throw new ArgumentNullException(nameof(meshContext));

            // 協働編集用の安定ID。未割当(0)のときだけ発行する。
            // Undo/Redo の復元は既にIDを持った実体を挿し戻すので、ここでは変化しない。
            if (meshContext.ObjectId == Poly_Ling.Data.ObjectIdAllocator.Unassigned)
                meshContext.ObjectId = Poly_Ling.Data.ObjectIdAllocator.Next();

            meshContext.ParentModelContext = this;
            MeshContextList.Add(meshContext);
            InvalidateTypedIndices();
            IsDirty = true;
            return MeshContextList.Count - 1;
        }

        /// <summary>メッシュを挿入</summary>
        /// <param name="adjustSelection">選択インデックスを調整するか（Undo/Redo時はfalse）</param>
        public void Insert(int index, MeshContext meshContext, bool adjustSelection = true)
        {
            if (meshContext == null)
                throw new ArgumentNullException(nameof(meshContext));
            if (index < 0 || index > MeshContextList.Count)
                throw new ArgumentOutOfRangeException(nameof(index));

            // 複製で作られた新規 MeshContext は ObjectId==0 なのでここで新IDを得る。
            // Undo/Redo の挿し戻しは既存IDを保つ（＝担当や参照が維持される）。
            if (meshContext.ObjectId == Poly_Ling.Data.ObjectIdAllocator.Unassigned)
                meshContext.ObjectId = Poly_Ling.Data.ObjectIdAllocator.Next();

            meshContext.ParentModelContext = this;
            MeshContextList.Insert(index, meshContext);
            InvalidateTypedIndices();
            IsDirty = true;

            // 索引で他要素を指している参照（親・ミラー元・Humanoid 割当・Tポーズ退避）を
            // 挿入分だけ繰り下げる。ここを飛ばすと親子が迷子になり、depth からの
            // 復元に頼らないと階層が壊れたままになる。
            //   ※挿入した meshContext 自身の親・ミラー元も「挿入前の索引」で
            //     設定されている前提で一緒に付け替える（EnableMirror がそう書く）。
            //   ※adjustSelection==false は Undo/Redo の挿し戻し。スナップショットが
            //     既に正しい索引を持っているので、ここで動かすと二重適用になる。
            if (adjustSelection)
                RemapIndexReferences(BuildInsertMap(MeshContextList.Count - 1, index));

            if (adjustSelection)
            {
                // 選択インデックス調整（挿入位置以降は+1）- 各カテゴリ個別に
                SelectedDrawableMeshIndices = AdjustIndicesForInsert(SelectedDrawableMeshIndices, index);
                SelectedBoneIndices = AdjustIndicesForInsert(SelectedBoneIndices, index);
                SelectedMorphIndices = AdjustIndicesForInsert(SelectedMorphIndices, index);
            }

            // モーフエクスプレッションのインデックス調整（常に実行）
            foreach (var set in MorphExpressions)
            {
                set.AdjustIndicesOnInsert(index);
            }
        }

        /// <summary>挿入時のインデックス調整ヘルパー</summary>
        private static List<int> AdjustIndicesForInsert(List<int> indices, int insertIndex)
        {
            var adjusted = new List<int>(indices.Count);
            foreach (var i in indices)
            {
                adjusted.Add(i >= insertIndex ? i + 1 : i);
            }
            return adjusted;
        }

        /// <summary>メッシュを削除</summary>
        /// <param name="adjustSelection">選択インデックスを調整するか（Undo/Redo時はfalse）</param>
        /// <returns>削除成功したか</returns>
        public bool RemoveAt(int index, bool adjustSelection = true)
        {
            if (index < 0 || index >= MeshContextList.Count)
                return false;

            // 付け替え表は削除前に作る（削除された親は祖父へ繰り上げるため、
            // 削除前の親子関係を読む必要がある）。
            // adjustSelection==false は Undo/Redo の巻き戻しなので付け替えない。
            int[] removeMap = adjustSelection ? BuildRemoveMap(index) : null;

            MeshContextList.RemoveAt(index);
            InvalidateTypedIndices();
            IsDirty = true;

            if (removeMap != null) RemapIndexReferences(removeMap);

            if (adjustSelection)
            {
                // 選択インデックス調整 - 各カテゴリ個別に
                SelectedDrawableMeshIndices = AdjustIndicesForRemove(SelectedDrawableMeshIndices, index);
                SelectedBoneIndices = AdjustIndicesForRemove(SelectedBoneIndices, index);
                SelectedMorphIndices = AdjustIndicesForRemove(SelectedMorphIndices, index);

                ValidateSelection();
            }

            // モーフエクスプレッションのインデックス調整（常に実行）
            foreach (var set in MorphExpressions)
            {
                set.AdjustIndicesOnRemove(index);
            }

            return true;
        }

        /// <summary>削除時のインデックス調整ヘルパー</summary>
        private static List<int> AdjustIndicesForRemove(List<int> indices, int removeIndex)
        {
            var adjusted = new List<int>(indices.Count);
            foreach (var i in indices)
            {
                if (i < removeIndex)
                    adjusted.Add(i);
                else if (i > removeIndex)
                    adjusted.Add(i - 1);
                // i == removeIndex の場合は削除されるので追加しない
            }
            return adjusted;
        }

        /// <summary>メッシュを移動（順序変更）</summary>
        /// <returns>移動成功したか</returns>
        public bool Move(int fromIndex, int toIndex)
        {
            if (fromIndex < 0 || fromIndex >= MeshContextList.Count)
                return false;
            if (toIndex < 0 || toIndex >= MeshContextList.Count)
                return false;
            if (fromIndex == toIndex)
                return false;

            var meshContext = MeshContextList[fromIndex];
            MeshContextList.RemoveAt(fromIndex);
            MeshContextList.Insert(toIndex, meshContext);

            RemapIndexReferences(BuildMoveMap(MeshContextList.Count, fromIndex, toIndex));

            // 選択インデックス調整 - 各カテゴリ個別に
            SelectedDrawableMeshIndices = AdjustIndicesForMove(SelectedDrawableMeshIndices, fromIndex, toIndex);
            SelectedBoneIndices = AdjustIndicesForMove(SelectedBoneIndices, fromIndex, toIndex);
            SelectedMorphIndices = AdjustIndicesForMove(SelectedMorphIndices, fromIndex, toIndex);

            InvalidateTypedIndices();
            IsDirty = true;
            return true;
        }

        /// <summary>移動時のインデックス調整ヘルパー</summary>
        private static List<int> AdjustIndicesForMove(List<int> indices, int fromIndex, int toIndex)
        {
            var adjusted = new List<int>(indices.Count);
            foreach (var i in indices)
            {
                if (i == fromIndex)
                {
                    adjusted.Add(toIndex);
                }
                else if (fromIndex < i && toIndex >= i)
                {
                    adjusted.Add(i - 1);
                }
                else if (fromIndex > i && toIndex <= i)
                {
                    adjusted.Add(i + 1);
                }
                else
                {
                    adjusted.Add(i);
                }
            }
            return adjusted;
        }

        /// <summary>インデックスでメッシュコンテキストを取得</summary>
        public MeshContext GetMeshContext(int index)
        {
            if (index < 0 || index >= MeshContextList.Count)
                return null;
            return MeshContextList[index];
        }

        /// <summary>メッシュコンテキストのインデックスを取得</summary>
        public int IndexOf(MeshContext meshContext)
        {
            return MeshContextList.IndexOf(meshContext);
        }

        // ================================================================
        // 全体操作
        // ================================================================

        /// <summary>全メッシュをクリア</summary>
        /// <param name="destroyMeshes">Unity Meshリソースを破棄するか</param>
        public void Clear(bool destroyMeshes = true)
        {
            if (destroyMeshes)
            {
                foreach (var meshContext in MeshContextList)
                {
                    if (meshContext.UnityMesh != null)
                        UnityEngine.Object.DestroyImmediate(meshContext.UnityMesh);
                }
            }

            MeshContextList.Clear();
            MirrorPairs.Clear();
            ClearAllCategorySelection();
            InvalidateTypedIndices();
            IsDirty = true;
        }

        /// <summary>新規モデルとしてリセット</summary>
        public void Reset(string name = "Untitled")
        {
            Clear();
            Name = name;
            FilePath = null;
            IsDirty = false;
            WorkPlane?.Reset();
            WorkAxis?.Reset();
            SymmetrySettings?.Reset();
            _humanoidMapping?.ClearAll();
        }

        // ================================================================
        // 複製
        // ================================================================

        /// <summary>指定メッシュコンテキストを複製</summary>
        /// <returns>複製されたメッシュコンテキストのインデックス、失敗時は-1</returns>
        /// <remarks>MeshContext.Clone()が必要。Phase 2以降で実装</remarks>
        public int Duplicate(int index)
        {
            // TODO: MeshContext.Clone()を実装後に有効化
            throw new NotImplementedException("MeshContext.Clone() is required");
        }

        // ================================================================
        // バウンディングボックス
        // ================================================================

        /// <summary>全メッシュのバウンディングボックスを計算</summary>
        public Bounds CalculateBounds()
        {
            if (MeshContextList.Count == 0)
                return new Bounds(Vector3.zero, Vector3.one);

            Bounds? combinedBounds = null;

            foreach (var meshContext in MeshContextList)
            {
                if (meshContext.MeshObject == null)
                    continue;

                var meshContextBounds = meshContext.MeshObject.CalculateBounds();

                if (!combinedBounds.HasValue)
                {
                    combinedBounds = meshContextBounds;
                }
                else
                {
                    var bounds = combinedBounds.Value;
                    bounds.Encapsulate(meshContextBounds);
                    combinedBounds = bounds;
                }
            }

            return combinedBounds ?? new Bounds(Vector3.zero, Vector3.one);
        }

        /// <summary>選択中の全メッシュのバウンディングボックス</summary>
        public Bounds CalculateCurrentBounds()
        {
            Bounds? combined = null;
            foreach (var mc in SelectedMeshContexts)
            {
                if (mc?.MeshObject == null) continue;
                var b = mc.MeshObject.CalculateBounds();
                combined = combined.HasValue
                    ? new Bounds(
                        (combined.Value.center + b.center) * 0.5f,
                        Vector3.Max(combined.Value.max, b.max) - Vector3.Min(combined.Value.min, b.min))
                    : b;
            }
            return combined ?? new Bounds(Vector3.zero, Vector3.one);
        }

        // ================================================================
        // ワールド変換行列計算
        // ================================================================

        /// <summary>
        /// 全MeshContextのワールド変換行列を計算
        /// HierarchyParentIndexに基づいて親子関係を解決し、
        /// 累積変換行列をWorldMatrixに設定する
        /// </summary>
        public void ComputeWorldMatrices()
        {
            if (MeshContextList == null || MeshContextList.Count == 0)
                return;

            // 生成ミラーは自前の姿勢を持たない。実体側から必ず引き写しておく。
            // 値コピーなので、実体側だけを動かす操作（原点CSV読込・姿勢くさび取込・
            // オブジェクト姿勢ツール等）のあとは放っておくとずれる。
            // ワールド行列を組む直前にここで一括同期しておけば、どの経路から
            // 変更されても H_M = H_R が保たれる。
            SyncDerivedMirrorTransforms(MeshContextList);

            // 階層ワールド（鏡像を掛ける前）。子はこちらを親として積む。
            var hierarchyWorld = new Matrix4x4[MeshContextList.Count];
            for (int i = 0; i < hierarchyWorld.Length; i++) hierarchyWorld[i] = Matrix4x4.identity;

            // トポロジカルソートして親から順に処理
            var sortedIndices = TopologicalSortByHierarchy();

            foreach (int index in sortedIndices)
            {
                var ctx = MeshContextList[index];
                if (ctx == null) continue;

                Matrix4x4 localMatrix = ctx.LocalMatrix;
                int parentIndex = ctx.HierarchyParentIndex;

                Matrix4x4 h = (parentIndex >= 0 && parentIndex < MeshContextList.Count)
                    ? hierarchyWorld[parentIndex] * localMatrix   // 親のワールド × 自身のローカル
                    : localMatrix;                                // ルート

                hierarchyWorld[index] = h;

                // ミラー側は実効ワールドを共役 S·H·S にする。
                //
                // ミラー側メッシュの頂点は実体側の素直な鏡像（v_M = S·v_R）として
                // 焼き込まれており、姿勢は持たない（実体側と同じ階層ワールドを取る）。
                // このとき
                //   M_world = (S·H·S)·v_M = (S·H·S)·(S·v_R) = S·H·v_R = S·(R_world)
                // となり、階層のどこを動かしても鏡像関係が保たれる。
                // S の共役なのでミラー面が原点を通るかどうかに依存せず、
                // det(S·H·S) = det(H) > 0 なので面の向きも変わらない。
                //
                // ここで WorldMatrix に入れておくことで、描画・エクスポート・
                // ピッキング・各ツールが無改修で正しい行列を見る。
                ctx.WorldMatrix = (ctx.MirrorGeometryDerived && MirrorBranchOps.IsMirrorSideContext(ctx))
                    ? ApplyMirrorConjugate(h, ctx)
                    : h;

                // 逆行列をキャッシュ
                ctx.WorldMatrixInverse = ctx.WorldMatrix.inverse;
            }
        }

        /// <summary>
        /// 生成ミラー（MirrorGeometryDerived）の姿勢と親を、実体側から引き写す。
        ///
        /// ミラー側は姿勢を持たない設計（実効ワールドは S·H·S で解く）なので、
        /// H_M = H_R でなければならない。BoneTransform は値コピーで作られており
        /// 参照共有ではないため、実体側だけが変わるとずれる。
        /// ワールド行列の算出前に毎回そろえる。
        /// </summary>
        public static void SyncDerivedMirrorTransforms(List<MeshContext> meshContexts)
        {
            if (meshContexts == null) return;

            for (int i = 0; i < meshContexts.Count; i++)
            {
                var mc = meshContexts[i];
                if (mc == null || !mc.MirrorGeometryDerived) continue;

                int src = mc.BakedMirrorSourceIndex;
                if (src < 0 || src >= meshContexts.Count) continue;

                var real = meshContexts[src];
                if (real?.BoneTransform == null || mc.BoneTransform == null) continue;

                mc.BoneTransform.Position          = real.BoneTransform.Position;
                mc.BoneTransform.Rotation          = real.BoneTransform.Rotation;
                mc.BoneTransform.Scale             = real.BoneTransform.Scale;
                mc.BoneTransform.UseLocalTransform = real.BoneTransform.UseLocalTransform;

                // 親が違うと H そのものが変わる。実体側の兄弟であるべきなので合わせる。
                mc.HierarchyParentIndex = real.HierarchyParentIndex;
            }
        }

        /// <summary>
        /// ミラー側の実効ワールド行列 S·H·S を返す。
        /// ミラー軸は自身の設定、無ければ焼き込み元（BakedMirrorSourceIndex）の設定を使う。
        /// </summary>
        private Matrix4x4 ApplyMirrorConjugate(Matrix4x4 h, MeshContext ctx)
        {
            int   axis = ctx.MirrorAxis;
            float dist = ctx.MirrorDistance;

            int src = ctx.BakedMirrorSourceIndex;
            if (src >= 0 && src < MeshContextList.Count && MeshContextList[src] != null)
            {
                axis = MeshContextList[src].MirrorAxis;
                dist = MeshContextList[src].MirrorDistance;
            }

            Matrix4x4 s = MirrorBranchOps.MirrorMatrix(axis, dist);
            return s * h * s;
        }

        /// <summary>
        /// 全ボーンのBindPoseを計算（WorldMatrix.inverse）
        /// ComputeWorldMatrices()の後に呼ぶこと
        /// </summary>
        public void ComputeBindPoses()
        {
            if (MeshContextList == null) return;

            for (int i = 0; i < MeshContextList.Count; i++)
            {
                var ctx = MeshContextList[i];
                if (ctx == null || ctx.Type != MeshType.Bone) continue;

                ctx.BindPose = ctx.WorldMatrix.inverse;
            }
        }

        /// <summary>
        /// ワールド行列とBindPoseを一括計算
        /// </summary>
        public void ComputeWorldAndBindPoses()
        {
            ComputeWorldMatrices();
            ComputeBindPoses();
        }

        /// <summary>
        /// スキンドでない（BoneWeight を持たない）DrawableコンテキストのBindPoseを
        /// 現在のWorldMatrix.inverseで更新する。
        ///
        /// RebuildAdapter直前（ComputeWorldMatrices()の後）に呼ぶこと。
        /// これにより UpdateTransform(useWorldTransform:true) が
        ///   worldPos = WorldMatrix * WorldMatrix.inverse * localPos = localPos（初期）
        ///   worldPos = newWorldMatrix * rebuildInverse * localPos（移動後）
        /// と計算され、スキンドメッシュと統一されたパスで扱える。
        /// </summary>
        public void ComputeMeshFilterBindPoses()
        {
            if (MeshContextList == null) return;

            for (int i = 0; i < MeshContextList.Count; i++)
            {
                var ctx = MeshContextList[i];
                if (ctx == null) continue;

                // ボーン・モーフ・剛体・ジョイント・グループは対象外
                var t = ctx.Type;
                if (t == MeshType.Bone     || t == MeshType.Morph       ||
                    t == MeshType.RigidBody || t == MeshType.RigidBodyJoint ||
                    t == MeshType.Group)
                    continue;

                // スキンド頂点を持つ場合はインポート時BindPoseを維持する
                if (ctx.MeshObject != null && ctx.MeshObject.HasBoneWeight)
                    continue;

                ctx.BindPose = ctx.WorldMatrix.inverse;
            }
        }

        /// <summary>
        /// MeshContextリストからワールド行列を計算（静的メソッド・インポート時用）
        /// HierarchyParentIndexとBoneTransformに基づいて親→子の順で計算
        /// </summary>
        public static Dictionary<int, Matrix4x4> CalculateWorldMatrices(List<MeshContext> meshContexts)
        {
            // ComputeWorldMatrices と同様、生成ミラーの姿勢を実体側からそろえる
            SyncDerivedMirrorTransforms(meshContexts);

            var worldMatrices  = new Dictionary<int, Matrix4x4>();
            var hierarchyWorld = new Dictionary<int, Matrix4x4>();

            int maxIterations = meshContexts.Count;
            for (int iteration = 0; iteration < maxIterations; iteration++)
            {
                bool anyAdded = false;

                for (int i = 0; i < meshContexts.Count; i++)
                {
                    if (worldMatrices.ContainsKey(i))
                        continue;

                    var ctx = meshContexts[i];
                    if (ctx?.BoneTransform == null)
                        continue;

                    int parentIndex = ctx.HierarchyParentIndex;
                    Matrix4x4 parentWorld;

                    if (parentIndex < 0)
                    {
                        parentWorld = Matrix4x4.identity;
                    }
                    else if (hierarchyWorld.TryGetValue(parentIndex, out parentWorld))
                    {
                        // 親が計算済み（鏡像を掛ける前の階層ワールドを積む）
                    }
                    else
                    {
                        continue;
                    }

                    Matrix4x4 localMatrix = Matrix4x4.TRS(
                        ctx.BoneTransform.Position,
                        Quaternion.Euler(ctx.BoneTransform.Rotation),
                        ctx.BoneTransform.Scale
                    );

                    // ComputeWorldMatrices と同じ規則。階層ワールドは hierarchyWorld に、
                    // ミラー側の実効ワールド S·H·S は戻り値に入れる。
                    Matrix4x4 h = parentWorld * localMatrix;
                    hierarchyWorld[i] = h;

                    worldMatrices[i] = (ctx.MirrorGeometryDerived && MirrorBranchOps.IsMirrorSideContext(ctx))
                        ? MirrorConjugate(h, ctx, meshContexts)
                        : h;
                    anyAdded = true;
                }

                if (!anyAdded)
                    break;
            }

            return worldMatrices;
        }

        /// <summary>静的版の S·H·S。ApplyMirrorConjugate と同じ規則。</summary>
        private static Matrix4x4 MirrorConjugate(
            Matrix4x4 h, MeshContext ctx, List<MeshContext> meshContexts)
        {
            int   axis = ctx.MirrorAxis;
            float dist = ctx.MirrorDistance;

            int src = ctx.BakedMirrorSourceIndex;
            if (src >= 0 && src < meshContexts.Count && meshContexts[src] != null)
            {
                axis = meshContexts[src].MirrorAxis;
                dist = meshContexts[src].MirrorDistance;
            }

            Matrix4x4 s = MirrorBranchOps.MirrorMatrix(axis, dist);
            return s * h * s;
        }

        /// <summary>
        /// MeshContextリストのBindPoseを一括計算（静的メソッド・インポート時用）
        /// CalculateWorldMatrices + BindPose = inverse を一括実行
        /// </summary>
        public static void ComputeBindPosesFromList(List<MeshContext> meshContexts)
        {
            var worldMatrices = CalculateWorldMatrices(meshContexts);
            foreach (var kv in worldMatrices)
            {
                meshContexts[kv.Key].BindPose = kv.Value.inverse;
            }
        }

        /// <summary>
        /// HierarchyParentIndexに基づいてトポロジカルソート
        /// 親が先に来るようにインデックスを並べ替える
        /// </summary>
        public List<int> TopologicalSortByHierarchy()
        {
            int count = MeshContextList.Count;
            var result = new List<int>(count);
            var visited = new bool[count];
            var inProgress = new bool[count];

            for (int i = 0; i < count; i++)
            {
                if (!visited[i])
                {
                    TopologicalSortVisit(i, visited, inProgress, result);
                }
            }

            return result;
        }

        private void TopologicalSortVisit(int index, bool[] visited, bool[] inProgress, List<int> result)
        {
            if (index < 0 || index >= MeshContextList.Count)
                return;

            if (inProgress[index])
            {
                // 循環参照を検出（警告を出して無視）
                Debug.LogWarning($"[ModelContext] Circular hierarchy detected at index {index}");
                return;
            }

            if (visited[index])
                return;

            inProgress[index] = true;

            // 親を先に処理
            var ctx = MeshContextList[index];
            if (ctx != null)
            {
                int parentIndex = ctx.HierarchyParentIndex;
                if (parentIndex >= 0 && parentIndex < MeshContextList.Count && parentIndex != index)
                {
                    TopologicalSortVisit(parentIndex, visited, inProgress, result);
                }
            }

            inProgress[index] = false;
            visited[index] = true;
            result.Add(index);
        }

        /// <summary>
        /// 指定インデックスのMeshContextのワールド行列のみを再計算
        /// 親の行列は既に計算済みである前提
        /// </summary>
        public void ComputeWorldMatrix(int index)
        {
            if (index < 0 || index >= MeshContextList.Count)
                return;

            var ctx = MeshContextList[index];
            if (ctx == null) return;

            Matrix4x4 localMatrix = ctx.LocalMatrix;
            int parentIndex = ctx.HierarchyParentIndex;

            if (parentIndex >= 0 && parentIndex < MeshContextList.Count)
            {
                var parent = MeshContextList[parentIndex];
                ctx.WorldMatrix = parent.WorldMatrix * localMatrix;
            }
            else
            {
                ctx.WorldMatrix = localMatrix;
            }

            ctx.WorldMatrixInverse = ctx.WorldMatrix.inverse;
        }
    }
}
