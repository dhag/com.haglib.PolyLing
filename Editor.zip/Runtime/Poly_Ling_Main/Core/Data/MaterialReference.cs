// Assets/Editor/Poly_Ling/Materials/MaterialReference.cs
// マテリアル参照とパラメータデータを統合管理
// アセットパス + パラメータデータ + ランタイムキャッシュ

using System;
using UnityEngine;
using Poly_Ling.EditorBridge;
using Poly_Ling.MaterialBridge;
using Poly_Ling.Data;

namespace Poly_Ling.Materials
{
    /// <summary>
    /// マテリアル参照
    /// - アセットがあればパスで参照
    /// - なければパラメータデータから生成
    /// </summary>
    [Serializable]
    public class MaterialReference
    {
        // ================================================================
        // 永続データ（シリアライズ対象）
        // ================================================================
        
        /// <summary>マテリアルアセットのパス（あれば）</summary>
        public string AssetPath;
        
        /// <summary>パラメータデータ（常に保持）</summary>
        public MaterialData Data;

        // ================================================================
        // ランタイムキャッシュ（シリアライズ対象外）
        // ================================================================
        
        [NonSerialized]
        private Material _cachedMaterial;
        
        [NonSerialized]
        private bool _cacheValid;

        // ================================================================
        // プロパティ
        // ================================================================
        
        /// <summary>
        /// マテリアルインスタンスを取得
        /// アセットがあれば読み込み、なければDataから生成
        /// </summary>
        public Material Material
        {
            get => GetOrCreateMaterial();
            set => SetMaterial(value);
        }
        
        /// <summary>アセットパスが設定されているか</summary>
        public bool HasAssetPath => !string.IsNullOrEmpty(AssetPath);
        
        /// <summary>有効なマテリアルを持っているか</summary>
        public bool IsValid => Data != null || HasAssetPath;
        
        /// <summary>マテリアル名</summary>
        public string Name
        {
            get => Data?.Name ?? "Unknown";
            set { if (Data != null) Data.Name = value; }
        }

        // ================================================================
        // コンストラクタ
        // ================================================================
        
        public MaterialReference()
        {
            Data = new MaterialData();
        }
        
        public MaterialReference(MaterialData data)
        {
            Data = data ?? new MaterialData();
        }
        
        public MaterialReference(Material material)
        {
            SetMaterial(material);
        }
        
        public MaterialReference(string assetPath)
        {
            AssetPath = assetPath;
            Data = new MaterialData();
            
            // アセットからデータを抽出
            if (HasAssetPath)
            {
                var mat = PLEditorBridge.I.LoadAssetAtPath<Material>(AssetPath);
                if (mat != null)
                {
                    Data = MaterialDataConverter.FromMaterial(mat);
                    _cachedMaterial = mat;
                    _cacheValid = true;
                }
            }
        }

        // ================================================================
        // マテリアル取得/設定
        // ================================================================
        
        /// <summary>
        /// マテリアルを取得または生成
        /// </summary>
        private Material GetOrCreateMaterial()
        {
            // キャッシュが有効ならそれを返す
            if (_cacheValid && _cachedMaterial != null)
                return _cachedMaterial;
            
            // アセットパスがあればロード
            if (HasAssetPath)
            {
                _cachedMaterial = PLEditorBridge.I.LoadAssetAtPath<Material>(AssetPath);
                if (_cachedMaterial != null)
                {
                    _cacheValid = true;
                    return _cachedMaterial;
                }
                // ロード失敗 → パスをクリア
                Debug.LogWarning($"[MaterialReference] Failed to load material: {AssetPath}");
                AssetPath = null;
            }
            
            // Dataから生成
            if (Data != null)
            {
                _cachedMaterial = MaterialDataConverter.ToMaterial(Data);
                _cacheValid = true;
                return _cachedMaterial;
            }
            
            return null;
        }
        
        /// <summary>
        /// マテリアルを設定
        /// </summary>
        private void SetMaterial(Material material)
        {
            if (material == null)
            {
                AssetPath = null;
                Data = new MaterialData();
                _cachedMaterial = null;
                _cacheValid = false;
                return;
            }
            
            // アセットパスを取得
            string path = PLEditorBridge.I.GetAssetPath(material);
            if (!string.IsNullOrEmpty(path))
            {
                AssetPath = path;
            }
            else
            {
                AssetPath = null;
            }
            
            // パラメータを抽出
            Data = MaterialDataConverter.FromMaterial(material);
            
            // キャッシュを更新
            _cachedMaterial = material;
            _cacheValid = true;
        }

        // ================================================================
        // キャッシュ管理
        // ================================================================
        
        /// <summary>キャッシュを無効化（再読み込み/再生成させる）</summary>
        public void InvalidateCache()
        {
            _cachedMaterial = null;
            _cacheValid = false;
        }
        
        /// <summary>Dataからキャッシュを再生成</summary>
        public void RefreshFromData()
        {
            if (Data != null)
            {
                _cachedMaterial = MaterialDataConverter.ToMaterial(Data);
                _cacheValid = true;
            }
        }
        
        /// <summary>現在のマテリアルからDataを更新</summary>
        public void RefreshData()
        {
            if (_cachedMaterial != null)
            {
                Data = MaterialDataConverter.FromMaterial(_cachedMaterial);
            }
        }

        // ================================================================
        // アセット保存
        // ================================================================
        
        /// <summary>
        /// マテリアルをアセットとして保存
        /// </summary>
        /// <param name="savePath">保存先パス（Assets/...）</param>
        /// <returns>成功したらtrue</returns>
        public bool SaveAsAsset(string savePath)
        {
            if (string.IsNullOrEmpty(savePath))
                return false;
            
            try
            {
                // マテリアルを取得または生成
                var mat = GetOrCreateMaterial();
                if (mat == null)
                    return false;

                // 保存先に既存 .mat があれば、その中身を現在のマテリアルで上書きする
                // （GUID/参照を保持したまま内容更新＝再エクスポートで別物化しない）。
                // 上書き=EditorUtility.CopySerialized 相当は Editor依存なので PLEditorBridge 経由。
                var existingAtTarget = PLEditorBridge.I.LoadAssetAtPath<Material>(savePath);
                if (existingAtTarget != null && !ReferenceEquals(existingAtTarget, mat))
                {
                    PLEditorBridge.I.CopySerialized(mat, existingAtTarget);
                    mat = existingAtTarget;
                }
                else
                {
                    // 保存先が空：新規作成、または別アセットからの複製保存。
                    // 複製はランタイムAPI(new Material)なので PLMaterialBridge 経由で行う。
                    // 直後のアセット保存(AssetDatabase)は Editor依存なので PLEditorBridge 経由。
                    // 複製と保存でブリッジを意図的に分けている（理由は IMaterialBridge のコメント参照、
                    // IEditorBridge へ統合し直さないこと）。
                    if (HasAssetPath && AssetPath != savePath)
                    {
                        mat = PLMaterialBridge.I.Clone(mat);
                    }

                    string existingPath = PLEditorBridge.I.GetAssetPath(mat);
                    if (string.IsNullOrEmpty(existingPath))
                    {
                        PLEditorBridge.I.CreateAsset(mat, savePath);
                    }
                    else if (existingPath != savePath)
                    {
                        // 別パスにコピー（複製=ランタイム→PLMaterialBridge、保存=Editor依存→PLEditorBridge）
                        var newMat = PLMaterialBridge.I.Clone(mat);
                        PLEditorBridge.I.CreateAsset(newMat, savePath);
                        mat = newMat;
                    }
                }
                
                PLEditorBridge.I.SaveAssets();
                
                // パスを更新
                AssetPath = savePath;
                _cachedMaterial = mat;
                _cacheValid = true;
                
                Debug.Log($"[MaterialReference] Saved: {savePath}");
                return true;
            }
            catch (Exception e)
            {
                Debug.LogError($"[MaterialReference] Save failed: {e.Message}");
                return false;
            }
        }

        // ================================================================
        // ユーティリティ
        // ================================================================
        
        /// <summary>ディープコピーを作成</summary>
        public MaterialReference Clone()
        {
            return new MaterialReference
            {
                AssetPath = this.AssetPath,
                Data = this.Data?.Clone()
            };
        }
        
        public override string ToString()
        {
            if (HasAssetPath)
                return $"[Asset] {Name} ({AssetPath})";
            return $"[OnMemory] {Name}";
        }
    }
}
