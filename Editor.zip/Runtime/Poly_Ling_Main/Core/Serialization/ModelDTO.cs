// Assets/Editor/Poly_Ling/Serialization/ModelDTO.cs
// モデルファイル (.mfmodel) のシリアライズ用データ構造
// Phase7: マルチマテリアル対応版
// Phase8: 選択状態シリアライズ対応（Edge/Face/Line/Mode）
// Phase9: 選択セット対応
// Phase Morph: モーフ基準データ対応
// Phase BonePose: BonePoseData対応

using System;
using System.Collections.Generic;
using UnityEngine;
using Poly_Ling.Selection;
using Poly_Ling.Data;
using Poly_Ling.Context;

namespace Poly_Ling.Serialization
{
    // ================================================================
    // モデルファイル全体
    // ================================================================

    /// <summary>
    /// モデルファイルのルートデータ
    /// </summary>
    [Serializable]
    public class ModelDTO
    {
        /// <summary>モデル名</summary>
        public string name;

        /// <summary>メッシュコンテキストリスト</summary>
        public List<MeshDTO> meshDTOList = new List<MeshDTO>();

        /// <summary>WorkPlane設定</summary>
        public WorkPlaneDTO workPlane;

        /// <summary>エディタ状態</summary>
        public EditorStateDTO editorStateDTO;

        // ================================================================
        // マテリアル（Phase 1: モデル単位に集約）
        // ================================================================

        /// <summary>[廃止] マテリアルリスト（アセットパス）- 読み込み時に警告を出力</summary>
        [System.Obsolete("materialReferencesを使用してください")]
        public List<string> materials = new List<string>();

        /// <summary>現在選択中のマテリアルインデックス</summary>
        public int currentMaterialIndex = 0;

        /// <summary>[廃止] デフォルトマテリアルリスト（アセットパス）- 読み込み時に警告を出力</summary>
        [System.Obsolete("defaultMaterialReferencesを使用してください")]
        public List<string> defaultMaterials = new List<string>();

        /// <summary>デフォルトマテリアルインデックス</summary>
        public int defaultCurrentMaterialIndex = 0;

        /// <summary>自動デフォルトマテリアル設定</summary>
        public bool autoSetDefaultMaterials = true;
        
        // ================================================================
        // マテリアル（新形式：パラメータデータ込み）
        // ================================================================
        
        /// <summary>マテリアル参照リスト（パス＋パラメータデータ）</summary>
        public List<MaterialReferenceDTO> materialReferences = new List<MaterialReferenceDTO>();
        
        /// <summary>デフォルトマテリアル参照リスト</summary>
        public List<MaterialReferenceDTO> defaultMaterialReferences = new List<MaterialReferenceDTO>();

        // ================================================================
        // Humanoidボーンマッピング
        // ================================================================
        //   ※#5b: モデルレベルの humanoidBoneMapping（Dict）は撤去。
        //     Humanoid 割当は per-bone（MeshDTO.humanBodyBone）を正とし、
        //     読込後 HumanoidMappingResolver.RebuildMappingFromPerBone で Dict を再構築する。

        // ================================================================
        // モーフエクスプレッション
        // ================================================================

        /// <summary>
        /// モーフエクスプレッション一覧
        /// 複数メッシュのモーフをグループ化
        /// </summary>
        public List<MorphExpressionDTO> morphExpressions = new List<MorphExpressionDTO>();

        // ================================================================
        // メッシュ選択セット（名前ベース）
        // ================================================================

        /// <summary>メッシュ選択セット</summary>
        public List<MeshSelectionSetDTO> meshSelectionSets = new List<MeshSelectionSetDTO>();

        // ================================================================
        // MirrorPair（ミラーペア情報）
        // ================================================================

        /// <summary>ミラーペア情報（Real↔Mirror のメッシュインデックスペア）</summary>
        public List<MirrorPairDTO> mirrorPairs = new List<MirrorPairDTO>();

        // ================================================================
        // スプリングボーン・コライダーグループ（モデルレベル：名前のみ）
        // ================================================================

        /// <summary>スプリングボーン・コライダーグループ名リスト（index＝並び順）。</summary>
        public List<string> springBoneColliderGroupNames = new List<string>();

        // ================================================================
        // TPoseバックアップ（Tポーズ変換前の姿勢。CSV/JSON 対称：規約4）
        // ================================================================

        /// <summary>Tポーズ変換前バックアップ（null=バックアップ無し）。</summary>
        public TPoseBackupDTO tPoseBackup;

        // === ファクトリメソッド ===

        public static ModelDTO Create(string modelName)
        {
            return new ModelDTO
            {
                name = modelName
            };
        }
    }

    // ================================================================
    // TPoseバックアップ DTO（純POCO・Unity型非依存）
    //   規約: MeshObject.cs「ボーン付帯データ格納規約」に準拠。
    //   参照は MeshContext index（TPoseBackup 実体が index キーのため）。
    //   行列は 16 要素 row-major、Vector3 は [x,y,z]、頂点列は flat xyz。
    // ================================================================

    [Serializable]
    public class TPoseBackupDTO
    {
        /// <summary>ボーン別ローカル回転（Euler）。</summary>
        public List<TPoseBoneRotDTO> boneRotations = new List<TPoseBoneRotDTO>();

        /// <summary>ボーン別 WorldMatrix。</summary>
        public List<TPoseMatrixDTO> worldMatrices = new List<TPoseMatrixDTO>();

        /// <summary>ボーン別 BindPose。</summary>
        public List<TPoseMatrixDTO> bindPoses = new List<TPoseMatrixDTO>();

        /// <summary>メッシュ別 頂点座標バックアップ。</summary>
        public List<TPoseVtxPosDTO> vertexPositions = new List<TPoseVtxPosDTO>();
    }

    /// <summary>ボーン回転バックアップ1件（index＝MeshContext index、rot=[x,y,z]）。</summary>
    [Serializable]
    public class TPoseBoneRotDTO
    {
        public int index;
        public float[] rot;
    }

    /// <summary>行列バックアップ1件（index＝MeshContext index、m=16 row-major）。</summary>
    [Serializable]
    public class TPoseMatrixDTO
    {
        public int index;
        public float[] m;
    }

    /// <summary>頂点座標バックアップ1件（index＝MeshContext index、p=flat xyz）。</summary>
    [Serializable]
    public class TPoseVtxPosDTO
    {
        public int index;
        public float[] p;
    }

    // ================================================================
    // メッシュコンテキスト
    // ================================================================

    /// <summary>
    /// 個別メッシュコンテキストのデータ
    /// </summary>
    [Serializable]
    public class MeshDTO
    {
        /// <summary>メッシュ名</summary>
        public string name;

        /// <summary>エクスポート時のトランスフォーム設定</summary>
        public BoneTransformDTO exportSettingsDTO;

        /// <summary>頂点データ</summary>
        public List<VertexDTO> vertices = new List<VertexDTO>();

        /// <summary>面データ</summary>
        public List<FaceDTO> faces = new List<FaceDTO>();

        /// <summary>選択中の頂点インデックス</summary>
        public List<int> selectedVertices = new List<int>();

        // ================================================================
        // 拡張選択状態（Phase 8追加）
        // ================================================================

        /// <summary>選択中のエッジ [[v1,v2], [v1,v2], ...]</summary>
        public List<int[]> selectedEdges = new List<int[]>();

        /// <summary>選択中の面インデックス</summary>
        public List<int> selectedFaces = new List<int>();

        /// <summary>選択中の線分インデックス（2頂点Face）</summary>
        public List<int> selectedLines = new List<int>();

        /// <summary>選択モード ("Vertex", "Edge", "Face", "Line", or combined flags)</summary>
        public string selectMode = "Vertex";

        // ================================================================
        // 選択セット（永続的な名前付き選択）
        // ================================================================

        /// <summary>保存された選択セット</summary>
        public List<SelectionSetDTO> selectionSets = new List<SelectionSetDTO>();

        // ================================================================
        // マテリアル [廃止セクション]
        // マテリアルはModelDTO.materialReferencesで一元管理されます
        // ================================================================

        /// <summary>[廃止] マテリアルリスト - ModelDTO.materialReferencesを使用してください</summary>
        [System.Obsolete("ModelDTO.materialReferencesを使用してください")]
        public List<string> materialPathList = new List<string>();

        /// <summary>[廃止] 現在選択中のマテリアルインデックス</summary>
        //[System.Obsolete("ModelDTO.currentMaterialIndexを使用してください")]
        //public int currentMaterialIndex = 0;

        // ================================================================
        // 階層情報
        // ================================================================

        /// <summary>メッシュの種類 ("Mesh", "Bone", "Helper", "Group", "Morph")</summary>
        public string type = "Mesh";

        /// <summary>親メッシュのインデックス（-1=ルート）</summary>
        public int parentIndex = -1;

        /// <summary>階層深度（MQO互換、0=ルート）</summary>
        public int depth = 0;

        /// <summary>ゲームオブジェクト階層の親（将来用）</summary>
        public int hierarchyParentIndex = -1;

        /// <summary>可視状態</summary>
        public bool isVisible = true;

        /// <summary>編集禁止（ロック）</summary>
        public bool isLocked = false;

        /// <summary>折りたたみ状態（MQO互換）</summary>
        public bool isFolding = false;

        /// <summary>
        /// 頂点が三角形化済みか（PMX形式）
        /// true: 各頂点が1つのUV/法線を持ち、すべての面が三角形 (PMX互換)
        /// false: 頂点が複数のUV/法線を持つ可能性あり (MQO形式)
        /// </summary>
        public bool isTriangulated = false;

        // ================================================================
        // ミラー設定
        // ================================================================

        /// <summary>ミラータイプ (0:なし, 1:分離, 2:結合)</summary>
        public int mirrorType = 0;

        /// <summary>ミラー軸 (1:X, 2:Y, 4:Z)</summary>
        public int mirrorAxis = 1;

        /// <summary>ミラー距離</summary>
        public float mirrorDistance = 0f;

        /// <summary>ミラー側マテリアルオフセット（ミラー側マテリアルインデックス = 実体側 + オフセット）</summary>
        public int mirrorMaterialOffset = 0;

        /// <summary>
        /// ベイク元メッシュのインデックス（Type==BakedMirrorの時に使用）
        /// -1 = ベイクミラーではない
        /// </summary>
        public int bakedMirrorSourceIndex = -1;

        /// <summary>
        /// ベイクドミラーの子を持つか（ソース側で設定）
        /// true = このメッシュのベイクドミラーが存在する
        /// </summary>
        public bool hasBakedMirrorChild = false;

        // ================================================================
        // モーフ基準データ（Phase: Morph対応）
        // ================================================================

        /// <summary>
        /// モーフ基準データ（モーフ前の位置等を保持）
        /// null = モーフではない通常メッシュ
        /// </summary>
        public MorphBaseDataDTO morphBaseData;

        /// <summary>
        /// モーフ親メッシュのインデックス
        /// -1 = 未指定（名前規則ベースで検索）
        /// </summary>
        public int morphParentIndex = -1;

        /// <summary>
        /// ボーンポーズデータ（PreBindPose + Manualレイヤー）
        /// null = BonePoseData未使用
        /// </summary>
        public BonePoseDataDTO bonePoseData;

        /// <summary>
        /// エクスポートから除外するか
        /// true: モデルエクスポート時にこのメッシュを出力しない
        /// </summary>
        public bool excludeFromExport = false;

        /// <summary>
        /// アーマチャ生成時にボーンを生成しない
        /// </summary>
        public bool ignorePoseInArmature = false;

        // ================================================================
        // 永続化拡張（DTO単一真実源化）：従来CSV直書きでのみ保持していた
        // IK / BindPose / BoneModelRotation と、未保存だった 剛体 / JOINT を
        // MeshDTO に集約する。null = 当該データなし。
        // ================================================================

        /// <summary>IK情報（null=非IKボーン）。</summary>
        public IKDataDTO ikData;

        /// <summary>IKリンクの per-bone データ（null=非IKリンク）。</summary>
        public IKLinkDataDTO ikLink;

        /// <summary>Unity Humanoid 割当名（空/null=非割当）。#5b: per-bone。</summary>
        public string humanBodyBone;

        /// <summary>Humanoid マッスル可動域（null=既定使用）。#5d-1: per-bone。</summary>
        public HumanLimitDataDTO humanLimit;

        /// <summary>BindPose（4x4・行優先16値。null=未設定/単位行列）。</summary>
        public float[] bindPose;

        /// <summary>ボーンモデル回転（[x,y,z,w]。null=未設定/単位）。</summary>
        public float[] boneModelRotation;

        /// <summary>剛体データ（null=非剛体）。</summary>
        public RigidBodyDataDTO rigidBodyData;

        /// <summary>JOINTデータ（null=非JOINT）。</summary>
        public JointDataDTO jointData;

        /// <summary>スプリングボーン・コライダー（null/空=なし。1ボーンに複数可）。</summary>
        public List<SpringBoneColliderDataDTO> springBoneColliders;

        /// <summary>スプリングボーン・ジョイント（null=非揺れjoint）。</summary>
        public SpringBoneJointDataDTO springBoneJoint;

        /// <summary>スプリングボーン・チェーンルート（null=非ルート）。</summary>
        public SpringBoneChainDataDTO springBoneChainRoot;
    }

    // ================================================================
    // 頂点データ
    // ================================================================

    /// <summary>
    /// 頂点データ（効率的な配列形式）
    /// </summary>
    [Serializable]
    public class VertexDTO
    {
        /// <summary>頂点ID（モーフ追跡等に使用）</summary>
        public int id;

        /// <summary>位置 [x, y, z]</summary>
        public float[] p;

        /// <summary>UV座標リスト [[u,v], [u,v], ...]</summary>
        public List<float[]> uv;

        /// <summary>法線リスト [[x,y,z], [x,y,z], ...]</summary>
        public List<float[]> n;

        /// <summary>
        /// ボーンウェイト [i0, i1, i2, i3, w0, w1, w2, w3]
        /// null = スキニングなし
        /// </summary>
        public float[] bw;

        /// <summary>
        /// ミラー側ボーンウェイト [i0, i1, i2, i3, w0, w1, w2, w3]
        /// null = ミラーウェイトなし
        /// </summary>
        public float[] mbw;

        /// <summary>頂点フラグ (VertexFlags)</summary>
        public byte f;

        // === 変換ヘルパー ===

        public Vector3 GetPosition()
        {
            if (p == null || p.Length < 3) return Vector3.zero;
            return new Vector3(p[0], p[1], p[2]);
        }

        public void SetPosition(Vector3 pos)
        {
            p = new float[] { pos.x, pos.y, pos.z };
        }

        public List<Vector2> GetUVs()
        {
            var result = new List<Vector2>();
            if (uv != null)
            {
                foreach (var u in uv)
                {
                    if (u != null && u.Length >= 2)
                        result.Add(new Vector2(u[0], u[1]));
                }
            }
            return result;
        }

        public void SetUVs(List<Vector2> uvs)
        {
            uv = new List<float[]>();
            foreach (var u in uvs)
            {
                uv.Add(new float[] { u.x, u.y });
            }
        }

        public List<Vector3> GetNormals()
        {
            var result = new List<Vector3>();
            if (n != null)
            {
                foreach (var normal in n)
                {
                    if (normal != null && normal.Length >= 3)
                        result.Add(new Vector3(normal[0], normal[1], normal[2]));
                }
            }
            return result;
        }

        public void SetNormals(List<Vector3> normals)
        {
            n = new List<float[]>();
            foreach (var normal in normals)
            {
                n.Add(new float[] { normal.x, normal.y, normal.z });
            }
        }

        public BoneWeight? GetBoneWeight()
        {
            if (bw == null || bw.Length < 8)
                return null;

            return new BoneWeight
            {
                boneIndex0 = (int)bw[0],
                boneIndex1 = (int)bw[1],
                boneIndex2 = (int)bw[2],
                boneIndex3 = (int)bw[3],
                weight0 = bw[4],
                weight1 = bw[5],
                weight2 = bw[6],
                weight3 = bw[7]
            };
        }

        public void SetBoneWeight(BoneWeight? boneWeight)
        {
            if (!boneWeight.HasValue)
            {
                bw = null;
                return;
            }

            var b = boneWeight.Value;
            bw = new float[]
            {
                b.boneIndex0, b.boneIndex1, b.boneIndex2, b.boneIndex3,
                b.weight0, b.weight1, b.weight2, b.weight3
            };
        }

        public BoneWeight? GetMirrorBoneWeight()
        {
            if (mbw == null || mbw.Length < 8)
                return null;

            return new BoneWeight
            {
                boneIndex0 = (int)mbw[0],
                boneIndex1 = (int)mbw[1],
                boneIndex2 = (int)mbw[2],
                boneIndex3 = (int)mbw[3],
                weight0 = mbw[4],
                weight1 = mbw[5],
                weight2 = mbw[6],
                weight3 = mbw[7]
            };
        }

        public void SetMirrorBoneWeight(BoneWeight? boneWeight)
        {
            if (!boneWeight.HasValue)
            {
                mbw = null;
                return;
            }

            var b = boneWeight.Value;
            mbw = new float[]
            {
                b.boneIndex0, b.boneIndex1, b.boneIndex2, b.boneIndex3,
                b.weight0, b.weight1, b.weight2, b.weight3
            };
        }
    }

    // ================================================================
    // 面データ
    // ================================================================

    /// <summary>
    /// 面データ
    /// </summary>
    [Serializable]
    public class FaceDTO
    {
        /// <summary>面ID（モーフ追跡等に使用）</summary>
        public int id;

        /// <summary>頂点インデックスリスト</summary>
        public List<int> v;

        /// <summary>UVサブインデックスリスト</summary>
        public List<int> uvi;

        /// <summary>法線サブインデックスリスト</summary>
        public List<int> ni;

        /// <summary>マテリアルインデックス（省略時は0）</summary>
        public int? mi;

        /// <summary>面フラグ (FaceFlags)</summary>
        public byte f;
    }

    // ================================================================
    // エクスポート設定
    // ================================================================

    /// <summary>
    /// エクスポート時のトランスフォーム設定
    /// </summary>
    [Serializable]
    public class BoneTransformDTO
    {
        /// <summary>ローカルトランスフォームを使用するか</summary>
        public bool useLocalTransform;

        /// <summary>SkinnedMeshRendererとしてエクスポートするか</summary>
        public bool exportAsSkinned;

        /// <summary>位置 [x, y, z]</summary>
        public float[] position;

        /// <summary>回転（オイラー角） [x, y, z]</summary>
        public float[] rotation;

        /// <summary>スケール [x, y, z]</summary>
        public float[] scale;

        // === 変換ヘルパー ===

        public Vector3 GetPosition()
        {
            if (position == null || position.Length < 3) return Vector3.zero;
            return new Vector3(position[0], position[1], position[2]);
        }

        public void SetPosition(Vector3 pos)
        {
            position = new float[] { pos.x, pos.y, pos.z };
        }

        public Vector3 GetRotation()
        {
            if (rotation == null || rotation.Length < 3) return Vector3.zero;
            return new Vector3(rotation[0], rotation[1], rotation[2]);
        }

        public void SetRotation(Vector3 rot)
        {
            rotation = new float[] { rot.x, rot.y, rot.z };
        }

        public Vector3 GetScale()
        {
            if (scale == null || scale.Length < 3) return Vector3.one;
            return new Vector3(scale[0], scale[1], scale[2]);
        }

        public void SetScale(Vector3 s)
        {
            scale = new float[] { s.x, s.y, s.z };
        }

        public static BoneTransformDTO CreateDefault()
        {
            return new BoneTransformDTO
            {
                useLocalTransform = false,
                exportAsSkinned = false,
                position = new float[] { 0, 0, 0 },
                rotation = new float[] { 0, 0, 0 },
                scale = new float[] { 1, 1, 1 }
            };
        }
    }

    // ================================================================
    // WorkPlane設定
    // ================================================================

    /// <summary>
    /// WorkPlane設定データ
    /// </summary>
    [Serializable]
    public class WorkPlaneDTO
    {
        /// <summary>モード ("CameraParallel", "WorldXY", "WorldXZ", "WorldYZ", "Custom")</summary>
        public string mode;

        /// <summary>原点 [x, y, z]</summary>
        public float[] origin;

        /// <summary>U軸 [x, y, z]</summary>
        public float[] axisU;

        /// <summary>V軸 [x, y, z]</summary>
        public float[] axisV;

        /// <summary>ロック状態</summary>
        public bool isLocked;

        /// <summary>軸ロック</summary>
        public bool lockOrientation;

        /// <summary>選択時の原点自動更新</summary>
        public bool autoUpdateOriginOnSelection;

        public static WorkPlaneDTO CreateDefault()
        {
            return new WorkPlaneDTO
            {
                mode = "CameraParallel",
                origin = new float[] { 0, 0, 0 },
                axisU = new float[] { 1, 0, 0 },
                axisV = new float[] { 0, 1, 0 },
                isLocked = false,
                lockOrientation = false,
                autoUpdateOriginOnSelection = true
            };
        }
    }

    // ================================================================
    // エディタ状態
    // ================================================================

    /// <summary>
    /// エディタ状態データ
    /// v2.0: 選択メッシュ/選択ボーン/選択頂点モーフに分離
    /// </summary>
    [Serializable]
    public class EditorStateDTO
    {
        /// <summary>カメラ回転X</summary>
        public float rotationX;

        /// <summary>カメラ回転Y</summary>
        public float rotationY;

        /// <summary>カメラ距離</summary>
        public float cameraDistance;

        /// <summary>カメラターゲット [x, y, z]</summary>
        public float[] cameraTarget;

        /// <summary>ワイヤーフレーム表示</summary>
        public bool showWireframe;

        /// <summary>頂点表示</summary>
        public bool showVertices;

        /// <summary>頂点編集モード</summary>
        public bool vertexEditMode;

        /// <summary>現在のツール名</summary>
        public string currentToolName;

        /// <summary>選択中のメッシュインデックス（Mesh, BakedMirror タイプ）</summary>
        public int selectedMeshIndex;

        /// <summary>選択中のボーンインデックス（Bone タイプ）</summary>
        public int selectedBoneIndex = -1;

        /// <summary>選択中の頂点モーフインデックス（Morph タイプ）</summary>
        public int selectedVertexMorphIndex = -1;

        //ナイフツールの固有設定
        /// <summary>ナイフツールのモード</summary>
        public string knifeMode;

        /// <summary>ナイフツールのEdgeSelect</summary>
        public bool knifeEdgeSelect;

        /// <summary>ナイフツールのChainMode</summary>
        public bool knifeChainMode;

        /// <summary>PMX→Unity座標比率（デフォルト0.1、旧0.085）</summary>
        public float pmxUnityRatio = 0.1f;// 0.085f;

        /// <summary>PMX Z軸反転（デフォルトfalse）</summary>
        public bool pmxFlipZ = false;

        /// <summary>MQO Z軸反転（デフォルトtrue）</summary>
        public bool mqoFlipZ = true;

        /// <summary>MQO→Unity座標比率（デフォルト0.01）</summary>
        public float mqoUnityRatio = 0.01f;

        /// <summary>ボーン表示</summary>
        public bool showBones = true;

        /// <summary>非選択ボーンも表示</summary>
        public bool showUnselectedBones = false;

        /// <summary>ボーン形状をY軸方向に表示</summary>
        public bool boneDisplayAlongY = false;

        public static EditorStateDTO CreateDefault()
        {
            return new EditorStateDTO
            {
                rotationX = 20f,
                rotationY = 0f,
                cameraDistance = 2f,
                cameraTarget = new float[] { 0, 0, 0 },
                showWireframe = true,
                showVertices = true,
                vertexEditMode = true,
                currentToolName = "Select",
                selectedMeshIndex = -1,
                selectedBoneIndex = -1,
                selectedVertexMorphIndex = -1,
                //ナイフツールの固有設定
                knifeMode = "Cut",
                knifeEdgeSelect = false,
                knifeChainMode = false,
                // 座標系設定
                pmxUnityRatio = 0.1f,// 0.085f,
                pmxFlipZ = false,
                mqoFlipZ = true,
                mqoUnityRatio = 0.01f
            };
        }
    }

    // ================================================================
    // マテリアル参照データ
    // ================================================================

    /// <summary>
    /// マテリアル参照のシリアライズ用データ
    /// アセットパス＋パラメータデータを保持
    /// </summary>
    [Serializable]
    public class MaterialReferenceDTO
    {
        /// <summary>マテリアルアセットのパス（あれば）</summary>
        public string assetPath;
        
        /// <summary>パラメータデータ</summary>
        public MaterialDataDTO data;
        
        public static MaterialReferenceDTO Create(string path = null)
        {
            return new MaterialReferenceDTO
            {
                assetPath = path,
                data = new MaterialDataDTO()
            };
        }
    }

    /// <summary>
    /// マテリアルパラメータのシリアライズ用データ
    /// </summary>
    [Serializable]
    public class MaterialDataDTO
    {
        // 基本情報
        public string name = "New Material";
        public string shaderType = "URPLit";
        
        // ベースカラー
        public float[] baseColor = new float[] { 1f, 1f, 1f, 1f };
        public string baseMapPath;
        
        // ソースパス（インポート元のパス、エクスポート時に使用）
        public string sourceTexturePath;
        public string sourceAlphaMapPath;
        public string sourceBumpMapPath;
        
        // PBRパラメータ
        public float metallic = 0f;
        public float smoothness = 0.5f;
        public string metallicMapPath;
        public string normalMapPath;
        public float normalScale = 1f;
        public string occlusionMapPath;
        public float occlusionStrength = 1f;
        
        // エミッション
        public bool emissionEnabled = false;
        public float[] emissionColor = new float[] { 0f, 0f, 0f, 1f };
        public string emissionMapPath;
        
        // レンダリング設定
        public int surface = 0;        // SurfaceType
        public int blendMode = 0;      // BlendModeType
        public int cullMode = 2;       // CullModeType.Back（表面のみ表示）
        public bool alphaClipEnabled = false;
        public float alphaCutoff = 0.5f;
    }

    // ================================================================
    // モーフ基準データ（Phase: Morph対応）
    // ================================================================

    /// <summary>
    /// モーフ基準データのシリアライズ用構造
    /// メッシュ頂点（モーフ後）と対になる基準位置（モーフ前）を保持
    /// </summary>
    [Serializable]
    public class MorphBaseDataDTO
    {
        /// <summary>モーフ名</summary>
        public string morphName = "";

        /// <summary>モーフパネル（PMX: 0=眉, 1=目, 2=口, 3=その他）</summary>
        public int panel = 3;

        /// <summary>作成日時（ISO 8601形式）</summary>
        public string createdAt;

        /// <summary>
        /// 基準位置（モーフ前の頂点位置）
        /// 各頂点の [x, y, z] を連続配列として格納
        /// 例: [x0,y0,z0, x1,y1,z1, x2,y2,z2, ...]
        /// </summary>
        public float[] basePositions;

        /// <summary>
        /// 基準法線（オプション）
        /// 各頂点の [x, y, z] を連続配列として格納
        /// null = 法線データなし
        /// </summary>
        public float[] baseNormals;

        /// <summary>
        /// 基準UV（オプション）
        /// 各頂点の [u, v] を連続配列として格納
        /// null = UVデータなし
        /// </summary>
        public float[] baseUVs;

        // ================================================================
        // 変換ヘルパー
        // ================================================================

        /// <summary>頂点数を取得</summary>
        public int GetVertexCount()
        {
            if (basePositions == null) return 0;
            return basePositions.Length / 3;
        }

        /// <summary>指定頂点の基準位置を取得</summary>
        public Vector3 GetBasePosition(int index)
        {
            if (basePositions == null) return Vector3.zero;
            int i = index * 3;
            if (i + 2 >= basePositions.Length) return Vector3.zero;
            return new Vector3(basePositions[i], basePositions[i + 1], basePositions[i + 2]);
        }

        /// <summary>基準位置配列を取得</summary>
        public Vector3[] GetBasePositions()
        {
            if (basePositions == null) return null;
            int count = GetVertexCount();
            var result = new Vector3[count];
            for (int i = 0; i < count; i++)
            {
                int idx = i * 3;
                result[i] = new Vector3(basePositions[idx], basePositions[idx + 1], basePositions[idx + 2]);
            }
            return result;
        }

        /// <summary>基準位置を設定</summary>
        public void SetBasePositions(Vector3[] positions)
        {
            if (positions == null || positions.Length == 0)
            {
                basePositions = null;
                return;
            }
            basePositions = new float[positions.Length * 3];
            for (int i = 0; i < positions.Length; i++)
            {
                int idx = i * 3;
                basePositions[idx] = positions[i].x;
                basePositions[idx + 1] = positions[i].y;
                basePositions[idx + 2] = positions[i].z;
            }
        }

        /// <summary>基準法線配列を取得</summary>
        public Vector3[] GetBaseNormals()
        {
            if (baseNormals == null) return null;
            int count = baseNormals.Length / 3;
            var result = new Vector3[count];
            for (int i = 0; i < count; i++)
            {
                int idx = i * 3;
                result[i] = new Vector3(baseNormals[idx], baseNormals[idx + 1], baseNormals[idx + 2]);
            }
            return result;
        }

        /// <summary>基準法線を設定</summary>
        public void SetBaseNormals(Vector3[] normals)
        {
            if (normals == null || normals.Length == 0)
            {
                baseNormals = null;
                return;
            }
            baseNormals = new float[normals.Length * 3];
            for (int i = 0; i < normals.Length; i++)
            {
                int idx = i * 3;
                baseNormals[idx] = normals[i].x;
                baseNormals[idx + 1] = normals[i].y;
                baseNormals[idx + 2] = normals[i].z;
            }
        }

        /// <summary>基準UV配列を取得</summary>
        public Vector2[] GetBaseUVs()
        {
            if (baseUVs == null) return null;
            int count = baseUVs.Length / 2;
            var result = new Vector2[count];
            for (int i = 0; i < count; i++)
            {
                int idx = i * 2;
                result[i] = new Vector2(baseUVs[idx], baseUVs[idx + 1]);
            }
            return result;
        }

        /// <summary>基準UVを設定</summary>
        public void SetBaseUVs(Vector2[] uvs)
        {
            if (uvs == null || uvs.Length == 0)
            {
                baseUVs = null;
                return;
            }
            baseUVs = new float[uvs.Length * 2];
            for (int i = 0; i < uvs.Length; i++)
            {
                int idx = i * 2;
                baseUVs[idx] = uvs[i].x;
                baseUVs[idx + 1] = uvs[i].y;
            }
        }

        // ================================================================
        // ファクトリメソッド
        // ================================================================

        /// <summary>デフォルト作成</summary>
        public static MorphBaseDataDTO Create(string morphName = "")
        {
            return new MorphBaseDataDTO
            {
                morphName = morphName,
                panel = 3,
                createdAt = DateTime.Now.ToString("o")
            };
        }
    }

    // ================================================================
    // ミラーペアデータ
    // ================================================================

    /// <summary>
    /// ミラーペア情報のシリアライズ用構造
    /// Real側とMirror側のメッシュインデックスペアを保持
    /// </summary>
    [Serializable]
    public class MirrorPairDTO
    {
        /// <summary>Real側メッシュインデックス（MeshContextList内）</summary>
        public int realIndex;

        /// <summary>Mirror側メッシュインデックス（MeshContextList内）</summary>
        public int mirrorIndex;

        /// <summary>ミラー軸（0=X, 1=Y, 2=Z）</summary>
        public int axis = 0;
    }

    // ================================================================
    // MeshMetaDTO（Phase 1: メタデータのみ、ジオメトリなし）
    // Remote分割送信のヘッダフェーズで使用。
    // MeshDTOからvertices/facesを除いた全フィールドを保持する。
    // ================================================================

    /// <summary>
    /// メッシュメタデータのみのDTO（ジオメトリを含まない）
    /// Remote通信のヘッダフェーズで使用
    /// </summary>
    [Serializable]
    public class MeshMetaDTO
    {
        public string name;
        public string type = "Mesh";
        public bool   isVisible  = true;
        public bool   isLocked   = false;
        public bool   isFolding  = false;
        public int    depth      = 0;
        public int    parentIndex = -1;
        public int    hierarchyParentIndex = -1;
        public int    mirrorType = 0;
        public int    mirrorAxis = 1;
        public float  mirrorDistance = 0f;
        public int    mirrorMaterialOffset = 0;
        public int    bakedMirrorSourceIndex = -1;
        public bool   hasBakedMirrorChild = false;
        public int    morphParentIndex = -1;
        public bool   excludeFromExport = false;
        public bool   ignorePoseInArmature = false;
        public MorphBaseDataDTO  morphBaseData;
        public BoneTransformDTO  exportSettingsDTO;
        public BonePoseDataDTO   bonePoseData;
        public List<SelectionSetDTO> selectionSets = new List<SelectionSetDTO>();
    }

    // ================================================================
    // MeshGeoDTO（Phase 1: ジオメトリのみ）
    // Remote分割送信のメッシュフェーズで使用。
    // ================================================================

    /// <summary>
    /// メッシュジオメトリのみのDTO（メタデータを含まない）
    /// Remote通信のメッシュフェーズで使用
    /// </summary>
    [Serializable]
    public class MeshGeoDTO
    {
        /// <summary>対応するメッシュのインデックス（ModelContext.MeshContextList内）</summary>
        public int meshIndex;
        public bool isTriangulated = false;
        public List<VertexDTO> vertices = new List<VertexDTO>();
        public List<FaceDTO>   faces    = new List<FaceDTO>();
    }

    // ================================================================
    // IK / 剛体 / JOINT 用DTO（フィールド型・[Serializable]）
    //   既存POCO（Poly_Ling.Data の IKData/RigidBodyData/JointData）は
    //   プロパティ主体のため、JsonUtility互換のフィールド型DTOを別途用意する。
    //   POCO⇔DTO の変換は ModelSerializer の Save/Load ヘルパで行う。
    // ================================================================

    /// <summary>
    /// IKリンクの per-bone データDTO（各リンクボーンに付帯）。
    /// 非null ⇔ そのボーンはIKリンク。所属チェーン・順序は保持しない
    /// （IKルートの effectorBoneName ＋ ボーン階層から IKChainResolver で導出）。
    /// </summary>
    [Serializable]
    public class IKLinkDataDTO
    {
        public bool hasLimit;
        public float[] limitMin; // [x,y,z]（ラジアン）
        public float[] limitMax; // [x,y,z]（ラジアン）
    }

    /// <summary>IKデータDTO（IKルート）。ターゲットは effectorBoneName（name主）。</summary>
    [Serializable]
    public class IKDataDTO
    {
        public bool isIK = true;
        public string effectorBoneName = ""; // エフェクタ（先端）ボーン名・name主
        public int loopCount = 0;
        public float limitAngle = 0f;        // ラジアン
    }

    /// <summary>
    /// Humanoid マッスル可動域DTO（per-bone・null=既定使用）。
    /// min/max/center は [x,y,z]（ラジアン）。3マッスル軸に対応。
    /// </summary>
    [Serializable]
    public class HumanLimitDataDTO
    {
        public float[] min;    // [x,y,z]（ラジアン）
        public float[] max;    // [x,y,z]
        public float[] center; // [x,y,z]
        public float axisLength = 0f;
        public bool useDefaultValues = true;
    }

    /// <summary>剛体データDTO。</summary>
    [Serializable]
    public class RigidBodyDataDTO
    {
        public string nameEnglish = "";
        public string relatedBoneName = "";
        public int boneIndex = -1;
        public int group = 0;
        public int collisionMask = 0;       // ushort を int で保持
        public int shape = 0;               // RigidBodyShape
        public float[] size;                // [x,y,z]
        public float[] position;            // [x,y,z]（working空間）
        public float[] rotation;            // [x,y,z]（working空間・ラジアン）
        public float mass = 1f;
        public float linearDamping = 0f;
        public float angularDamping = 0f;
        public float restitution = 0f;
        public float friction = 0f;
        public int physicsMode = 0;         // RigidBodyPhysicsMode
    }

    /// <summary>JOINTデータDTO。</summary>
    [Serializable]
    public class JointDataDTO
    {
        public string nameEnglish = "";
        public int jointType = 0;
        public string bodyAName = "";
        public string bodyBName = "";
        public int rigidBodyIndexA = -1;
        public int rigidBodyIndexB = -1;
        public float[] position;            // [x,y,z]（working空間）
        public float[] rotation;            // [x,y,z]（working空間・ラジアン）
        public float[] translationMin;      // [x,y,z]（raw）
        public float[] translationMax;      // [x,y,z]（raw）
        public float[] rotationMin;         // [x,y,z]（raw・ラジアン）
        public float[] rotationMax;         // [x,y,z]（raw・ラジアン）
        public float[] springTranslation;   // [x,y,z]（raw）
        public float[] springRotation;      // [x,y,z]（raw）
    }

    // ================================================================
    // スプリングボーン用DTO（VRM SpringBone。フィールド型・[Serializable]）
    //   POCO（Poly_Ling.Data の SpringBoneColliderData/SpringBoneJointData/
    //   SpringBoneChainData）はプロパティ主体のため、JsonUtility互換の
    //   フィールド型DTOを別途用意する。POCO⇔DTO 変換は ModelSerializer が行う。
    // ================================================================

    /// <summary>スプリングボーン・コライダーDTO。</summary>
    [Serializable]
    public class SpringBoneColliderDataDTO
    {
        public int shape = 0;                       // SpringBoneColliderShape
        public float[] offset;                      // [x,y,z]（付帯ボーンのローカル）
        public float radius = 0.05f;
        public float[] tail;                        // [x,y,z]（カプセル終点）
        public float[] normal;                      // [x,y,z]（平面法線）
        public List<int> groupIndices = new List<int>();  // 所属group index（複数可）
    }

    /// <summary>スプリングボーン・ジョイントDTO。</summary>
    [Serializable]
    public class SpringBoneJointDataDTO
    {
        public float hitRadius = 0.02f;
        public float stiffnessForce = 1.0f;
        public float gravityPower = 0f;
        public float[] gravityDir;                  // [x,y,z]
        public float dragForce = 0.4f;
    }

    /// <summary>スプリングボーン・チェーンルートDTO。</summary>
    [Serializable]
    public class SpringBoneChainDataDTO
    {
        public string name = "";
        public List<int> colliderGroupIndices = new List<int>();  // 衝突group index
        public string centerBoneName = "";          // name主（空=World）
    }
}
