// Tools/AddFaceTool.cs
// 面追加ツール（2点=Line、3点=Triangle、4点=Quad）
// マルチマテリアル対応 + Line描画対応

using System.Collections.Generic;
using UnityEngine;
using Poly_Ling.Data;
using Poly_Ling.Ops;
using Poly_Ling.UndoSystem;
using static Poly_Ling.Gizmo.GLGizmoDrawer;
using Poly_Ling.Localization;

namespace Poly_Ling.Tools
{
    /// <summary>
    /// 面の追加モード
    /// </summary>
    public enum AddFaceMode
    {
        Line = 2,       // 2点（補助線）
        Triangle = 3,   // 3点（三角形）
        Quad = 4        // 4点（四角形）
    }

    /// <summary>
    /// 点の情報（既存頂点 or 新規作成点）
    /// </summary>
    public struct PointInfo
    {
        public bool IsExistingVertex;
        public int ExistingVertexIndex;
        public Vector3 Position;

        public static PointInfo FromExisting(int vertexIndex, Vector3 position)
        {
            return new PointInfo
            {
                IsExistingVertex = true,
                ExistingVertexIndex = vertexIndex,
                Position = position
            };
        }

        public static PointInfo FromNew(Vector3 position)
        {
            return new PointInfo
            {
                IsExistingVertex = false,
                ExistingVertexIndex = -1,
                Position = position
            };
        }
    }

    /// <summary>
    /// 面追加ツール
    /// </summary>
    public partial class AddFaceTool : IEditTool
    {
        public string Name => "Add Face";
        public string DisplayName => "Add Face";
        //public ToolCategory Category => ToolCategory.Topology;  
        /// <summary>
        /// ローカライズされた表示名を取得
        /// </summary>
        public string GetLocalizedDisplayName() => L.Get("Tool_Add Face");

        // ================================================================
        // 設定（IToolSettings対応）
        // ================================================================

        private AddFaceSettings _settings = new AddFaceSettings();
        public IToolSettings Settings => _settings;

        // 設定へのショートカットプロパティ
        private AddFaceMode Mode
        {
            get => _settings.Mode;
            set => _settings.Mode = value;
        }

        private float DefaultDistance
        {
            get => _settings.DefaultDistance;
            set => _settings.DefaultDistance = value;
        }

        private bool ContinuousLine
        {
            get => _settings.ContinuousLine;
            set => _settings.ContinuousLine = value;
        }

        // ================================================================
        // Player ビュー用公開 API
        // ================================================================
        public AddFaceMode ModePublic    { get => Mode; set { Mode = value; } }
        public bool ContinuousLinePublic { get => ContinuousLine; set => ContinuousLine = value; }
        public int  PlacedPointCount     => _points.Count;
        public int  RequiredPointsPublic => RequiredPoints;
        public void ClearPointsPublic()  { _points.Clear(); _lastLinePoint = null; }

        // ================================================================
        // Player オーバーレイ描画用プレビューデータ
        // ================================================================

        /// <summary>Player の UIToolkit オーバーレイが使うプレビューデータ</summary>
        public struct AddFacePreviewData
        {
            /// <summary>配置済み点（Position, IsExistingVertex）</summary>
            public PointInfo[] PlacedPoints;
            /// <summary>プレビュー点が有効か</summary>
            public bool PreviewValid;
            /// <summary>プレビュー点ワールド座標</summary>
            public Vector3 PreviewPoint;
            /// <summary>プレビューが既存頂点にスナップしているか</summary>
            public bool PreviewSnapped;
            /// <summary>連続線分モードの開始点（nullなら不使用）</summary>
            public PointInfo? ContinuousLineStart;
        }

        public AddFacePreviewData GetPreviewData()
        {
            PointInfo? contStart = null;
            if (Mode == AddFaceMode.Line && ContinuousLine && _points.Count == 0 && _lastLinePoint.HasValue)
                contStart = _lastLinePoint;
            return new AddFacePreviewData
            {
                PlacedPoints       = _points.ToArray(),
                PreviewValid       = _previewValid,
                PreviewPoint       = _previewPoint,
                PreviewSnapped     = _previewHitVertex >= 0,
                ContinuousLineStart = contStart,
            };
        }

        /// <summary>配置済み点のラベルリストを返す（SubPanel 表示用）</summary>
        public System.Collections.Generic.List<string> GetPointLabels()
        {
            var labels = new System.Collections.Generic.List<string>();
            for (int i = 0; i < _points.Count; i++)
            {
                var p = _points[i];
                labels.Add(p.IsExistingVertex
                    ? $"  [{i + 1}] 既存頂点 #{p.ExistingVertexIndex}"
                    : $"  [{i + 1}] 新規点");
            }
            return labels;
        }

        // === 状態 ===
        private List<PointInfo> _points = new List<PointInfo>();
        private PointInfo? _lastLinePoint = null;  // 連続線分の最後の点
        private Vector3 _previewPoint;          // 現在のマウス位置での候補点
        private bool _previewValid = false;
        private int _previewHitVertex = -1;     // プレビュー時に既存頂点にヒットしている場合

        // === モード名 ===
        private static readonly string[] ModeNames = { "Line (2)", "Triangle (3)", "Quad (4)" };
        private static readonly AddFaceMode[] ModeValues = { AddFaceMode.Line, AddFaceMode.Triangle, AddFaceMode.Quad };

        public int RequiredPoints => (int)Mode;

        // === IEditTool実装 ===

        public bool OnMouseDown(ToolContext ctx, Vector2 mousePos)
        {
            // 右クリックは点を1つ戻す
            if (ctx.CurrentButton == 1)
            {
                if (_points.Count > 0)
                {
                    _points.RemoveAt(_points.Count - 1);
                    ctx.Repaint?.Invoke();
                }
                else if (_lastLinePoint.HasValue)
                {
                    // 連続線分モードの開始点もクリア
                    _lastLinePoint = null;
                    ctx.Repaint?.Invoke();
                }
                return true;
            }

            // 左クリックのみ処理
            if (ctx.CurrentButton != 0)
                return false;

            // 点を追加
            PointInfo point = GetPointAtScreenPos(ctx, mousePos);

            // デバッグログ
            if (point.IsExistingVertex)
            {
                Debug.Log($"[AddFaceTool] Point added: Existing vertex V{point.ExistingVertexIndex} at {point.Position}");
            }
            else
            {
                Debug.Log($"[AddFaceTool] Point added: NEW vertex at {point.Position}");
            }

            // 連続線分モードの場合
            if (Mode == AddFaceMode.Line && ContinuousLine && _lastLinePoint.HasValue)
            {
                // 前回の最後の点と今回の点で線分を作成
                _points.Clear();
                _points.Add(_lastLinePoint.Value);
                _points.Add(point);
                var createdIndices = CreateFace(ctx);

                // 作成された頂点インデックスで_lastLinePointを更新
                if (createdIndices.Count >= 2)
                {
                    int lastIdx = createdIndices[1];
                    Vector3 lastPos = ctx.FirstSelectedMeshObject.Vertices[lastIdx].Position;
                    _lastLinePoint = PointInfo.FromExisting(lastIdx, lastPos);
                    Debug.Log($"[AddFaceTool] Continuous line: next start = V{lastIdx}");
                }

                _points.Clear();
                ctx.Repaint?.Invoke();
                return true;
            }

            _points.Add(point);

            // 必要な点数に達したら面を作成
            if (_points.Count >= RequiredPoints)
            {
                var createdIndices = CreateFace(ctx);

                // 連続線分モードの場合、最後の頂点インデックスを保存
                if (Mode == AddFaceMode.Line && ContinuousLine && createdIndices.Count >= 2)
                {
                    int lastIdx = createdIndices[createdIndices.Count - 1];
                    Vector3 lastPos = ctx.FirstSelectedMeshObject.Vertices[lastIdx].Position;
                    _lastLinePoint = PointInfo.FromExisting(lastIdx, lastPos);
                }

                _points.Clear();
            }

            ctx.Repaint?.Invoke();
            return true;
        }

        public bool OnMouseDrag(ToolContext ctx, Vector2 mousePos, Vector2 delta)
        {
            // プレビュー更新
            UpdatePreview(ctx, mousePos);
            ctx.Repaint?.Invoke();
            return false;  // ドラッグは他の処理に委譲
        }

        public bool OnMouseUp(ToolContext ctx, Vector2 mousePos)
        {
            return false;
        }

        /// <summary>IMGUI 削除済み。Player は UIToolkit オーバーレイを使用。UnityEditor_Handles 使用禁止。</summary>
        /// <summary>IMGUI 削除済み。Player は UIToolkit オーバーレイを使用。UnityEditor_Handles 使用禁止。</summary>
        public void DrawGizmo(ToolContext ctx) { }
    

        public void OnActivate(ToolContext ctx)
        {
            _points.Clear();
            _previewValid = false;
            _lastLinePoint = null;

            // 選択された頂点を最初の点として使用
            if (ctx.SelectedVertices != null && ctx.SelectedVertices.Count > 0 && ctx.FirstSelectedMeshObject != null)
            {
                var selectedList = new List<int>(ctx.SelectedVertices);

                // Lineモードで2頂点選択されていれば即座に線分作成
                if (Mode == AddFaceMode.Line && selectedList.Count == 2)
                {
                    foreach (int idx in selectedList)
                    {
                        if (idx >= 0 && idx < ctx.FirstSelectedMeshObject.VertexCount)
                        {
                            Vector3 pos = ctx.FirstSelectedMeshObject.Vertices[idx].Position;
                            _points.Add(PointInfo.FromExisting(idx, pos));
                        }
                    }

                    if (_points.Count == 2)
                    {
                        var createdIndices = CreateFace(ctx);

                        // 連続モードなら最後の点を保持
                        if (ContinuousLine && createdIndices.Count >= 2)
                        {
                            int lastIdx = createdIndices[1];
                            Vector3 lastPos = ctx.FirstSelectedMeshObject.Vertices[lastIdx].Position;
                            _lastLinePoint = PointInfo.FromExisting(lastIdx, lastPos);
                        }
                        _points.Clear();
                    }
                    return;
                }

                // 1頂点選択の場合、それを最初の点として使用
                if (selectedList.Count == 1)
                {
                    int selectedIdx = selectedList[0];
                    if (selectedIdx >= 0 && selectedIdx < ctx.FirstSelectedMeshObject.VertexCount)
                    {
                        Vector3 pos = ctx.FirstSelectedMeshObject.Vertices[selectedIdx].Position;
                        var startPoint = PointInfo.FromExisting(selectedIdx, pos);

                        if (Mode == AddFaceMode.Line && ContinuousLine)
                        {
                            // 連続線分モードの場合は開始点として設定
                            _lastLinePoint = startPoint;
                        }
                        else
                        {
                            // 通常モードの場合は最初の点として追加
                            _points.Add(startPoint);
                        }
                    }
                }
            }
        }

        public void OnDeactivate(ToolContext ctx)
        {
            _points.Clear();
            _previewValid = false;
            _lastLinePoint = null;
        }

        public void Reset()
        {
            _points.Clear();
            _previewValid = false;
            _previewHitVertex = -1;
            _lastLinePoint = null;
        }

        // === 内部メソッド ===

        // GPU ホバー由来の既存頂点（Player でハンドラが click/hover 毎に設定）。未ヒットは -1。
        private int _gpuHoverVertex = -1;

        /// <summary>
        /// 次回クリック／プレビューでスナップ対象にする既存頂点を GPU ホバー由来で指定する。
        /// Player のハンドラが OnMouseDown / UpdateHover 直前に呼ぶ。未ヒットは -1。
        /// </summary>
        public void SetGpuHoverVertex(int vertex) => _gpuHoverVertex = vertex;

        /// <summary>
        /// スクリーン位置から点を取得
        /// 優先順位: 1.GPU ホバー既存頂点  2.WorkPlane 交点
        /// </summary>
        private PointInfo GetPointAtScreenPos(ToolContext ctx, Vector2 screenPos)
        {
            // GPU ホバー由来の既存頂点があればスナップ。CPU ヒットテスト（FindNearestVertexAtScreen）は使用禁止。
            var mo = ctx.FirstSelectedMeshObject;
            if (mo != null && _gpuHoverVertex >= 0 && _gpuHoverVertex < mo.VertexCount)
            {
                Vector3 pos = mo.Vertices[_gpuHoverVertex].Position;
                return PointInfo.FromExisting(_gpuHoverVertex, pos);
            }

            // WorkPlane との交点
            Vector3 worldPos = GetWorldPositionFromScreen(ctx, screenPos);
            return PointInfo.FromNew(worldPos);
        }

        /// <summary>
        /// スクリーン位置から最も近い頂点を検索
        /// 【CPUヒットテスト禁止。これもバグあり使用禁止】CPU ヒットテスト（WorldToScreen 投影＋画面距離）。呼出しは全撤去済み・本体はソース保持。
        /// 深度/遮蔽/WorldMatrix 非考慮で Player では誤選択する。GPU ホバー経路を使うこと。
        /// </summary>
        private int FindNearestVertexAtScreen(ToolContext ctx, Vector2 screenPos)
        {
            if (ctx.FirstSelectedMeshObject == null) return -1;

            // ヒット半径（少し大きめに設定）
            float hitRadius = 15f;
            if (ctx.HandleRadius > 0) hitRadius = Mathf.Max(hitRadius, ctx.HandleRadius);

            int nearest = -1;
            float minDist = hitRadius;

            for (int i = 0; i < ctx.FirstSelectedMeshObject.VertexCount; i++)
            {
                Vector2 vertScreen = ctx.WorldToScreenPos(
                    ctx.FirstSelectedMeshObject.Vertices[i].Position,
                    ctx.PreviewRect,
                    ctx.CameraPosition,
                    ctx.CameraTarget);

                float dist = Vector2.Distance(screenPos, vertScreen);
                if (dist < minDist)
                {
                    minDist = dist;
                    nearest = i;
                }
            }

            return nearest;
        }

        /// <summary>
        /// スクリーン位置からワールド座標を取得
        /// </summary>
        private Vector3 GetWorldPositionFromScreen(ToolContext ctx, Vector2 screenPos)
        {
            // スクリーン座標からレイを作成
            Ray ray;
            if (ctx.ScreenPosToRay != null)
            {
                ray = ctx.ScreenPosToRay(screenPos);
            }
            else
            {
                // フォールバック（通常は使われない）
                Vector3 forward = (ctx.CameraTarget - ctx.CameraPosition).normalized;
                ray = new Ray(ctx.CameraPosition, forward);
            }

            // WorkPlaneとの交点を試みる
            if (ctx.WorkPlane != null)
            {
                if (ctx.WorkPlane.RayIntersect(ray.origin, ray.direction, out Vector3 hitPoint))
                {
                    return hitPoint;
                }
            }

            // 交差しない場合は、カメラから適当な距離の点
            return ray.origin + ray.direction * DefaultDistance * ctx.CameraDistance;
        }

        /// <summary>
        /// プレビュー点を更新
        /// </summary>
        private void UpdatePreview(ToolContext ctx, Vector2 screenPos)
        {
            if (ctx.FirstSelectedMeshObject == null || !ctx.PreviewRect.Contains(screenPos))
            {
                _previewValid = false;
                return;
            }

            // GPU ホバー由来の既存頂点があればスナップ。CPU ヒットテスト（FindNearestVertexAtScreen）は使用禁止。
            var mo = ctx.FirstSelectedMeshObject;
            if (mo != null && _gpuHoverVertex >= 0 && _gpuHoverVertex < mo.VertexCount)
            {
                _previewHitVertex = _gpuHoverVertex;
                _previewPoint     = mo.Vertices[_gpuHoverVertex].Position;
            }
            else
            {
                _previewHitVertex = -1;
                _previewPoint     = GetWorldPositionFromScreen(ctx, screenPos);
            }

            _previewValid = true;
        }

        /// <summary>
        /// 面を作成し、作成された頂点インデックスのリストを返す
        /// </summary>
        private List<int> CreateFace(ToolContext ctx)
        {
            var createdIndices = new List<int>();

            if (ctx.FirstSelectedMeshObject == null || _points.Count < 2)
                return createdIndices;

            var meshObject = ctx.FirstSelectedMeshObject;
            var newVertexIndices = new List<int>();
            var addedVertices = new List<(int Index, Vertex Vertex)>();

            // 各点について、既存頂点を使用するか新規作成
            for (int i = 0; i < _points.Count; i++)
            {
                var point = _points[i];
                if (point.IsExistingVertex)
                {
                    newVertexIndices.Add(point.ExistingVertexIndex);
                    createdIndices.Add(point.ExistingVertexIndex);
                }
                else
                {
                    // 新規頂点を作成
                    var vertex = new Vertex(point.Position);
                    vertex.UVs.Add(Vector2.zero);  // デフォルトUV
                    vertex.Normals.Add(Vector3.up);  // 仮の法線（後で計算）

                    int newIndex = meshObject.Vertices.Count;
                    meshObject.Vertices.Add(vertex);
                    newVertexIndices.Add(newIndex);
                    addedVertices.Add((newIndex, vertex));
                    createdIndices.Add(newIndex);

                    // _pointsの情報も更新（次回使用時のため）
                    _points[i] = PointInfo.FromExisting(newIndex, point.Position);
                }
            }

            // 面を作成
            Face newFace = null;
            switch (Mode)
            {
                case AddFaceMode.Line:
                    // 2点の補助線を作成（2頂点のFace）
                    if (newVertexIndices.Count >= 2)
                    {
                        newFace = new Face();
                        newFace.VertexIndices.Add(newVertexIndices[0]);
                        newFace.VertexIndices.Add(newVertexIndices[1]);
                        newFace.UVIndices.Add(0);
                        newFace.UVIndices.Add(0);
                        newFace.NormalIndices.Add(0);
                        newFace.NormalIndices.Add(0);
                        newFace.MaterialIndex = ctx.CurrentMaterialIndex;
                    }
                    break;

                case AddFaceMode.Triangle:
                    if (newVertexIndices.Count >= 3)
                    {
                        newFace = new Face(
                            newVertexIndices[0],
                            newVertexIndices[1],
                            newVertexIndices[2],
                            ctx.CurrentMaterialIndex);
                    }
                    break;

                case AddFaceMode.Quad:
                    if (newVertexIndices.Count >= 4)
                    {
                        newFace = new Face(
                            newVertexIndices[0],
                            newVertexIndices[1],
                            newVertexIndices[2],
                            newVertexIndices[3],
                            ctx.CurrentMaterialIndex);
                    }
                    break;
            }

            if (newFace != null)
            {
                // 3頂点以上の場合は法線を計算
                if (newFace.VertexCount >= 3)
                {
                    Vector3 faceNormal = CalculateFaceNormal(meshObject, newFace);
                    foreach (int vi in newFace.VertexIndices)
                    {
                        var vertex = meshObject.Vertices[vi];
                        if (vertex.Normals.Count == 0)
                        {
                            vertex.Normals.Add(faceNormal);
                        }
                        else
                        {
                            vertex.Normals[0] = faceNormal;
                        }
                    }
                }

                int faceIndex = meshObject.Faces.Count;
                meshObject.Faces.Add(newFace);

                Debug.Log($"[AddFaceTool] Created {Mode}: VertexCount={newFace.VertexCount}, MaterialIndex={newFace.MaterialIndex}");

                // メッシュを更新
                ctx.SyncMesh?.Invoke();

                // Undo記録
                if (ctx.UndoController != null)
                {
                    ctx.UndoController.RecordAddFaceOperation(newFace, faceIndex, addedVertices);
                }
            }

            ctx.Repaint?.Invoke();

            return createdIndices;
        }

        /// <summary>
        /// 面の法線を計算
        /// </summary>
        private Vector3 CalculateFaceNormal(MeshObject meshObject, Face face)
        {
            if (face.VertexCount < 3)
                return Vector3.up;

            Vector3 p0 = meshObject.Vertices[face.VertexIndices[0]].Position;
            Vector3 p1 = meshObject.Vertices[face.VertexIndices[1]].Position;
            Vector3 p2 = meshObject.Vertices[face.VertexIndices[2]].Position;

            return NormalHelper.CalculateFaceNormal(p0, p1, p2);
        }

        // === 公開メソッド ===

        /// <summary>
        /// 現在の点をクリア
        /// </summary>
        public void ClearPoints()
        {
            _points.Clear();
            _previewValid = false;
        }

        /// <summary>
        /// 点の数
        /// </summary>
        public int PointCount => _points.Count;
    }
}