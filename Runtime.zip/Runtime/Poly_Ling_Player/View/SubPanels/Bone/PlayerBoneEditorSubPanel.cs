// PlayerBoneEditorSubPanel.cs
// ボーン・描画メッシュ統合 TRS エディタ（旧 BoneEditorSubPanel + ObjectMoveTRSPanel の統合）
// SubPanelScope でボーンのみ / 描画メッシュのみ / 両方 を切り替え可能。
// Runtime/Poly_Ling_Player/View/ に配置

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;
using Poly_Ling.Data;
using Poly_Ling.Context;
using Poly_Ling.UndoSystem;
using Poly_Ling.Commands;
using Poly_Ling.EditorBridge;
using Poly_Ling.View;
using Poly_Ling.Diagnostics;

namespace Poly_Ling.Player
{
    public class PlayerBoneEditorSubPanel
    {
        // ================================================================
        // スコープ
        // ================================================================

        private enum SubPanelScope { BonesOnly, MeshesOnly, Both }
        private SubPanelScope _scope = SubPanelScope.BonesOnly;

        // ================================================================
        // コールバック
        // ================================================================

        public Func<ModelContext>        GetModel;
        public Func<MeshUndoController>  GetUndoController;
        public Action                    OnRepaint;
        public Action<Vector3>           OnFocusCamera;
        public Func<int>                 GetModelIndex;

        /// <summary>
        /// ObjectMoveTool の共有設定インスタンスを返すコールバック。
        /// 設定: MoveWithChildren / PickBones / PickMeshesNoSkin / PickMeshesSkinned。
        /// サブパネルのチェックボックスとこの設定を双方向で同期する。
        /// </summary>
        public Func<Poly_Ling.Tools.ObjectMoveSettings> GetObjectMoveSettings;

        /// <summary>
        /// 「拡大縮小をベイク」実行要求。戻り値は結果メッセージ
        /// （適用件数とスキップ理由）で、そのままパネル内に表示する。
        /// </summary>
        public Func<string> RequestBakeObjectScale;

        // PanelContext 経由でコマンドを送信
        private PanelContext _panelContext;

        public void SetContext(PanelContext ctx) => _panelContext = ctx;

        private void SendCommand(PanelCommand cmd) => _panelContext?.SendCommand(cmd);

        // ================================================================
        // UI 要素
        // ================================================================

        // スコープタブ
        private Button _tabBones, _tabMeshes;
        private VisualElement _moveOptionsSection;      // ボーン専用: スキンモード A/B/C
        private VisualElement _commonMoveSection;      // 両タブ共通: 子を一緒に移動
        private VisualElement _meshMoveOptionsSection; // メッシュ専用: 原点だけ移動

        // 共通
        private Label         _warningLabel;
        private Label         _selectionCountLabel;

        // ── 対象選択（スコープ追従・全タブ共通）────────────────────
        //   3D 上でピックしにくい対象をリストから選ぶための入口。
        //   選択は 3D ピックやメッシュリストと同じ SelectMeshCommand 経由で行う。
        private VisualElement _targetSection;
        private DropdownField _boneDropdown;             // 対象選択ドロップダウン
        private bool          _suppressBoneDropdown;
        private readonly List<int>          _targetChoiceMasters    = new List<int>();
        private readonly List<MeshCategory> _targetChoiceCategories = new List<MeshCategory>();

        // ── ボーン専用 ──────────────────────────────────────────────
        private VisualElement _boneSection;

        private Label         _boneNameLabel;
        private IntegerField  _masterIndexField;
        private Label         _boneIndexLabel;
        private DropdownField _parentBoneDropdown;
        private List<int>     _parentChoiceMasters = new List<int>();
        private bool          _suppressBoneEdit;
        private Label         _worldPosLabel;

        private Toggle        _bonePoseActiveToggle;
        private Button        _btnInitPose;
        private Button        _btnResetLayers;
        private Button        _btnBakePose;
        private Button        _btnFreezePose;
        private VisualElement _bonePoseSection;

        private Button        _btnReset;
        private Button        _btnFocus;

        // ── 共通 TRS ────────────────────────────────────────────────
        private FloatField _posX, _posY, _posZ;
        private FloatField _rotX, _rotY, _rotZ;
        private Slider     _rotSliderX, _rotSliderY, _rotSliderZ;
        private FloatField _sclX, _sclY, _sclZ;
        private VisualElement _rotSection, _sclSection;
        private bool       _suppressTRS;

        // IgnorePose（描画メッシュ含む場合）
        private Toggle        _ignorePoseToggle;
        private VisualElement _ignorePoseRow;

        // ミラー分岐ルート（オブジェクト姿勢タブ専用）
        private Toggle        _mirrorBranchToggle;

        // 原点CSV（オブジェクト姿勢タブ専用）
        private Toggle        _originIncludeRotToggle;

        // 姿勢くさび（オブジェクト姿勢タブ専用）
        private FloatField    _wedgeLengthField;

        // ── ObjectMoveSettings 連動チェックボックス ───────────────
        // BoneInputHandler 廃止に伴い、ObjectMoveTool のピック対象を
        // ここから操作する。GetObjectMoveSettings() 経由で同一インスタンスを共有。
        private Toggle        _toggleMoveWithChildren;
        private Toggle        _toggleOriginOnly;
        private Toggle        _toggleModeA;
        private Toggle        _toggleModeB;
        private Toggle        _toggleModeC;
        private bool          _suppressMoveSettings;

        private Label _statusLabel;
        private Label _bakeScaleMsgLabel;

        // ================================================================
        // Build
        // ================================================================

        public void Build(VisualElement parent)
        {
            var root = new VisualElement();
            root.style.paddingLeft = root.style.paddingRight =
            root.style.paddingTop  = root.style.paddingBottom = 4;
            parent.Add(root);

            // ── スコープタブ ─────────────────────────────────────────
            var tabRow = new VisualElement();
            tabRow.style.flexDirection = FlexDirection.Row;
            tabRow.style.marginBottom  = 6;
            _tabBones  = MakeScopeTab("ボーン",               () => SetScope(SubPanelScope.BonesOnly));
            _tabMeshes = MakeScopeTab("オブジェクト姿勢",       () => SetScope(SubPanelScope.MeshesOnly));
            _tabBones.style.flexGrow = _tabMeshes.style.flexGrow = 1;
            tabRow.Add(_tabBones); tabRow.Add(_tabMeshes);
            root.Add(tabRow);
            UpdateTabHighlight();

            // ── ピック対象・挙動オプション ───────────────────────────
            // ObjectMoveTool の ObjectMoveSettings と同期するチェックボックス 4 個。
            // BoneInputHandler 廃止後、ボーンエディタ表示中のピック対象を
            // このサブパネルから操作する。
            _moveOptionsSection = new VisualElement();
            _moveOptionsSection.style.marginBottom = 6;

            _toggleMoveWithChildren  = new Toggle("子を一緒に移動") { value = true };
            _toggleOriginOnly        = new Toggle("原点だけ移動") { value = false };
            _toggleModeA             = new Toggle("ボーンだけ動かす（スキン固定）") { value = true };
            _toggleModeB             = new Toggle("スキンごと動かして確定（焼き込み）") { value = false };
            _toggleModeC             = new Toggle("ポーズ（一時）") { value = false };
            _toggleMoveWithChildren.style.color  = new StyleColor(Color.white);
            _toggleOriginOnly.style.color        = new StyleColor(Color.white);
            _toggleModeA.style.color             = new StyleColor(Color.white);
            _toggleModeB.style.color             = new StyleColor(Color.white);
            _toggleModeC.style.color             = new StyleColor(Color.white);

            _toggleMoveWithChildren.RegisterValueChangedCallback(e =>
            {
                if (_suppressMoveSettings) return;
                var s = GetObjectMoveSettings?.Invoke();
                if (s != null) s.MoveWithChildren = e.newValue;
            });
            _toggleOriginOnly.RegisterValueChangedCallback(e =>
            {
                if (_suppressMoveSettings) return;
                var s = GetObjectMoveSettings?.Invoke();
                if (s != null) s.OriginOnly = e.newValue;
                ApplyOriginOnlyVisibility();
            });
            _toggleModeA.RegisterValueChangedCallback(e =>
            {
                if (_suppressMoveSettings) return;
                if (!e.newValue) { _toggleModeA.SetValueWithoutNotify(true); return; }
                var s = GetObjectMoveSettings?.Invoke();
                if (s != null) s.MoveMode = Poly_Ling.Tools.BoneMoveMode.BoneOnlyRebind;
                _toggleModeB.SetValueWithoutNotify(false);
                _toggleModeC.SetValueWithoutNotify(false);
                Refresh();
            });
            _toggleModeB.RegisterValueChangedCallback(e =>
            {
                if (_suppressMoveSettings) return;
                if (!e.newValue) { _toggleModeB.SetValueWithoutNotify(true); return; }
                var s = GetObjectMoveSettings?.Invoke();
                if (s != null) s.MoveMode = Poly_Ling.Tools.BoneMoveMode.SkinBakeRebind;
                _toggleModeA.SetValueWithoutNotify(false);
                _toggleModeC.SetValueWithoutNotify(false);
                Refresh();
            });
            _toggleModeC.RegisterValueChangedCallback(e =>
            {
                if (_suppressMoveSettings) return;
                if (!e.newValue) { _toggleModeC.SetValueWithoutNotify(true); return; }
                var s = GetObjectMoveSettings?.Invoke();
                if (s != null) s.MoveMode = Poly_Ling.Tools.BoneMoveMode.PoseLayer;
                _toggleModeA.SetValueWithoutNotify(false);
                _toggleModeB.SetValueWithoutNotify(false);
                Refresh();
            });

            // 子を一緒に移動: ボーン/メッシュ両方に適用 → 共通（両タブで表示）
            _commonMoveSection = new VisualElement();
            _commonMoveSection.style.marginBottom = 6;
            _commonMoveSection.Add(_toggleMoveWithChildren);
            root.Add(_commonMoveSection);

            // 原点だけ移動: MeshFilter 対象 → 「オブジェクト姿勢」タブ専用
            _meshMoveOptionsSection = new VisualElement();
            _meshMoveOptionsSection.style.marginBottom = 6;
            _meshMoveOptionsSection.Add(_toggleOriginOnly);
            root.Add(_meshMoveOptionsSection);

            // スキンモード A/B/C: 「ボーン」タブ専用
            _moveOptionsSection.Add(MakeSecLabel("移動モード"));
            _moveOptionsSection.Add(_toggleModeA);
            _moveOptionsSection.Add(_toggleModeB);
            _moveOptionsSection.Add(_toggleModeC);
            root.Add(_moveOptionsSection);

            // ── 警告・選択カウント ───────────────────────────────────
            _warningLabel = new Label();
            _warningLabel.style.display      = DisplayStyle.None;
            _warningLabel.style.color        = new StyleColor(new Color(1f, 0.5f, 0.2f));
            _warningLabel.style.marginBottom = 4;
            _warningLabel.style.whiteSpace   = WhiteSpace.Normal;
            root.Add(_warningLabel);

            _selectionCountLabel = new Label();
            _selectionCountLabel.style.color        = new StyleColor(Color.white);
            _selectionCountLabel.style.marginBottom = 4;
            _selectionCountLabel.style.fontSize     = 10;
            root.Add(_selectionCountLabel);

            // ── 対象選択（全タブ共通）───────────────────────────────
            _targetSection = new VisualElement();

            var dropLabel = new Label("対象選択:");
            dropLabel.style.color    = new StyleColor(Color.white);
            dropLabel.style.fontSize = 10;
            _targetSection.Add(dropLabel);

            _boneDropdown = new DropdownField();
            _boneDropdown.style.marginBottom = 4;
            _boneDropdown.RegisterValueChangedCallback(_ => OnTargetDropdownChanged());
            _targetSection.Add(_boneDropdown);
            root.Add(_targetSection);

            // ── ボーン専用セクション ─────────────────────────────────
            _boneSection = new VisualElement();

            // リセット / フォーカス
            var btnRow = new VisualElement();
            btnRow.style.flexDirection = FlexDirection.Row;
            btnRow.style.marginBottom  = 4;
            _btnReset = new Button(OnResetPose) { text = "ポーズリセット" };
            _btnReset.style.flexGrow    = 1;
            _btnReset.style.marginRight = 4;
            _btnReset.style.height      = 22;
            _btnFocus = new Button(OnFocusBone) { text = "フォーカス" };
            _btnFocus.style.flexGrow = 1;
            _btnFocus.style.height   = 22;
            btnRow.Add(_btnFocus);
            _boneSection.Add(btnRow);

            // ボーンポーズ
            _bonePoseSection = new VisualElement();
            _bonePoseSection.Add(MakeSep());
            _bonePoseSection.Add(MakeSecLabel("ボーンポーズ"));
            _bonePoseSection.Add(_btnReset);

            _bonePoseActiveToggle = new Toggle("ポーズ有効") { value = false };
            _bonePoseActiveToggle.style.marginBottom = 4;
            _bonePoseActiveToggle.RegisterValueChangedCallback(e =>
            {
                var model = GetModel?.Invoke();
                if (model == null || !model.HasBoneSelection) return;
                SendCommand(new SetBonePoseActiveCommand(
                    GetModelIndex?.Invoke() ?? 0, model.SelectedBoneIndices.ToArray(), e.newValue));
            });
            _bonePoseSection.Add(_bonePoseActiveToggle);

            var poseRow = new VisualElement();
            poseRow.style.flexDirection = FlexDirection.Row;
            poseRow.style.marginBottom  = 4;
            _btnInitPose    = MakeSmallBtn("初期化");
            _btnResetLayers = MakeSmallBtn("レイヤークリア");
            _btnBakePose    = MakeSmallBtn("BindPoseへベイク");
            _btnInitPose.style.flexGrow     = 1; _btnInitPose.style.marginRight    = 2;
            _btnResetLayers.style.flexGrow  = 1; _btnResetLayers.style.marginRight = 2;
            _btnBakePose.style.flexGrow     = 1;
            _btnInitPose.clicked += () =>
            {
                var model = GetModel?.Invoke();
                if (model == null || !model.HasBoneSelection) return;
                SendCommand(new InitBonePoseCommand(GetModelIndex?.Invoke() ?? 0,
                    model.SelectedBoneIndices.ToArray()));
            };
            _btnResetLayers.clicked += () =>
            {
                var model = GetModel?.Invoke();
                if (model == null || !model.HasBoneSelection) return;
                SendCommand(new ResetBonePoseLayersCommand(GetModelIndex?.Invoke() ?? 0,
                    model.SelectedBoneIndices.ToArray()));
            };
            _btnBakePose.clicked += () =>
            {
                var model = GetModel?.Invoke();
                if (model == null || !model.HasBoneSelection) return;
                SendCommand(new BakePoseToBindPoseCommand(GetModelIndex?.Invoke() ?? 0,
                    model.SelectedBoneIndices.ToArray()));
            };
            poseRow.Add(_btnInitPose); poseRow.Add(_btnResetLayers); poseRow.Add(_btnBakePose);
            _bonePoseSection.Add(poseRow);

            _btnFreezePose = new Button(() =>
            {
                var model = GetModel?.Invoke();
                if (model == null) return;
                SendCommand(new FreezeCurrentPoseCommand(GetModelIndex?.Invoke() ?? 0));
            }) { text = "この姿勢で確定（焼き込み）" };
            _btnFreezePose.style.height    = 22;
            _btnFreezePose.style.marginTop = 4;
            _bonePoseSection.Add(_btnFreezePose);

            _boneSection.Add(_bonePoseSection);

            // ボーン詳細情報
            _boneSection.Add(MakeSep());
            AddRow(_boneSection, "ボーン名",    out _boneNameLabel);
            AddIntRow(_boneSection, "マスターIdx", out _masterIndexField, OnMasterIndexChanged);
            AddRow(_boneSection, "ボーンIdx",   out _boneIndexLabel);
            AddDropdownRow(_boneSection, "親ボーン", out _parentBoneDropdown, OnParentBoneChanged);
            _boneSection.Add(MakeSecLabel("ワールド座標"));
            AddRow(_boneSection, "位置",        out _worldPosLabel);

            root.Add(_boneSection);

            // ── TRS ─────────────────────────────────────────────────
            root.Add(MakeSep());
            root.Add(MakeSecLabel("位置"));
            AddXYZFields(root, "pos", out _posX, out _posY, out _posZ);
            RegTF(_posX, SetBoneTransformValueCommand.Field.PositionX);
            RegTF(_posY, SetBoneTransformValueCommand.Field.PositionY);
            RegTF(_posZ, SetBoneTransformValueCommand.Field.PositionZ);

            _rotSection = new VisualElement();
            _rotSection.Add(MakeSecLabel("回転 (°)"));
            AddXYZFields(_rotSection, "rot", out _rotX, out _rotY, out _rotZ);
            RegTF(_rotX, SetBoneTransformValueCommand.Field.RotationX);
            RegTF(_rotY, SetBoneTransformValueCommand.Field.RotationY);
            RegTF(_rotZ, SetBoneTransformValueCommand.Field.RotationZ);
            _rotSliderX = MakeRotSlider(); _rotSection.Add(_rotSliderX);
            _rotSliderY = MakeRotSlider(); _rotSection.Add(_rotSliderY);
            _rotSliderZ = MakeRotSlider(); _rotSection.Add(_rotSliderZ);
            RegRotSlider(_rotSliderX, _rotX, SetBoneTransformValueCommand.Field.RotationX);
            RegRotSlider(_rotSliderY, _rotY, SetBoneTransformValueCommand.Field.RotationY);
            RegRotSlider(_rotSliderZ, _rotZ, SetBoneTransformValueCommand.Field.RotationZ);
            root.Add(_rotSection);

            _sclSection = new VisualElement();
            _sclSection.Add(MakeSecLabel("スケール"));
            AddXYZFields(_sclSection, "scl", out _sclX, out _sclY, out _sclZ);
            RegTF(_sclX, SetBoneTransformValueCommand.Field.ScaleX);
            RegTF(_sclY, SetBoneTransformValueCommand.Field.ScaleY);
            RegTF(_sclZ, SetBoneTransformValueCommand.Field.ScaleZ);

            // ローカル拡大縮小を頂点位置へ畳み込み、スケールを (1,1,1) に戻す。
            // _sclSection に入れているため「原点だけ移動」時は一緒に隠れる。
            var bakeScaleBtn = new Button(() =>
            {
                string msg = RequestBakeObjectScale?.Invoke() ?? "";
                if (_bakeScaleMsgLabel != null) _bakeScaleMsgLabel.text = msg;
                OnRepaint?.Invoke();
            })
            { text = "拡大縮小をベイク" };
            bakeScaleBtn.style.marginTop = 4;
            bakeScaleBtn.tooltip =
                "選択中メッシュのローカル拡大縮小を頂点位置へ畳み込み、スケールを 1,1,1 に戻す" +
                "（子を持つメッシュ・スキンドメッシュは対象外）";
            _sclSection.Add(bakeScaleBtn);

            _bakeScaleMsgLabel = new Label();
            _bakeScaleMsgLabel.style.fontSize  = 10;
            _bakeScaleMsgLabel.style.color     = new StyleColor(new Color(1f, 0.75f, 0.4f));
            _bakeScaleMsgLabel.style.whiteSpace = WhiteSpace.Normal;
            _bakeScaleMsgLabel.style.marginTop = 2;
            _sclSection.Add(_bakeScaleMsgLabel);

            root.Add(_sclSection);

            // IgnorePose
            _ignorePoseRow = new VisualElement();
            _ignorePoseRow.Add(MakeSep());
            _ignorePoseToggle = new Toggle("姿勢無視(アーマチャ)");
            _ignorePoseToggle.style.color = new StyleColor(Color.white);
            _ignorePoseToggle.RegisterValueChangedCallback(e =>
            {
                if (_suppressTRS) return;
                var indices = GetTargetIndices();
                if (indices.Length > 0)
                    SendCommand(new SetIgnorePoseCommand(GetModelIndex?.Invoke() ?? 0, indices, e.newValue));
            });
            _ignorePoseRow.Add(_ignorePoseToggle);

            _mirrorBranchToggle = new Toggle("ミラー分岐ルート");
            _mirrorBranchToggle.style.color = new StyleColor(Color.white);
            _mirrorBranchToggle.tooltip =
                "エクスポート時、この配下を実体側とミラー側の2本の枝に分割する（非スキンド専用）";
            _mirrorBranchToggle.RegisterValueChangedCallback(e =>
            {
                if (_suppressTRS) return;
                var indices = GetTargetIndices();
                if (indices.Length > 0)
                    SendCommand(new SetMirrorBranchRootCommand(
                        GetModelIndex?.Invoke() ?? 0, indices, e.newValue));
            });
            _ignorePoseRow.Add(_mirrorBranchToggle);

            // 原点の途中経過を CSV で退避・復元する（オブジェクト姿勢タブ専用）
            var originIoRow = new VisualElement();
            originIoRow.style.flexDirection = FlexDirection.Row;
            originIoRow.style.marginTop     = 2;

            var originExportBtn = new Button(ExportObjectOriginsCsv) { text = "原点CSV書出" };
            var originImportBtn = new Button(ImportObjectOriginsCsv) { text = "原点CSV読込" };
            originExportBtn.style.flexGrow = 1;
            originImportBtn.style.flexGrow = 1;
            originExportBtn.tooltip = "全メッシュの原点(位置)を CSV に書き出す（回転は下のチェックで任意）";
            originImportBtn.tooltip = "CSV の原点(位置)を名前一致で適用する（原点だけ移動・子は動かさない）\n" +
                                      "CSV に載っていないオブジェクトと、モデルに無い名前はどちらも無視する";

            originIoRow.Add(originExportBtn);
            originIoRow.Add(originImportBtn);

            // 回転列（rotX,rotY,rotZ）を書出・読込の対象にするか。
            // 位置だけの旧 CSV も読めるよう、行ごとに列があるかを見て判断する。
            _originIncludeRotToggle = new Toggle("回転(°)も対象") { value = false };
            _originIncludeRotToggle.style.color = new StyleColor(Color.white);
            _originIncludeRotToggle.tooltip =
                "書出: rotX,rotY,rotZ 列を足す / 読込: 回転列がある行だけ回転も適用する" +
                "（列が無い行・オフのときは位置だけ）";

            _ignorePoseRow.Add(_originIncludeRotToggle);
            _ignorePoseRow.Add(originIoRow);

            // ── 姿勢くさび（オブジェクト姿勢タブ専用）────────────────
            // オブジェクト姿勢を、モデル内の表示用オブジェクトとして出し入れする。
            _ignorePoseRow.Add(MakeSecLabel("姿勢くさび"));

            _wedgeLengthField = new FloatField("長さ")
            {
                value = Poly_Ling.Tools.ObjectPose.ObjectPoseWedgeGenerator.DefaultWedgeLength
            };
            _wedgeLengthField.tooltip =
                "くさびの全長。実際の大きさは、これに各オブジェクトの拡大率平均を掛けたものになる";
            _wedgeLengthField.style.marginBottom = 2;
            _ignorePoseRow.Add(_wedgeLengthField);

            var wedgeIoRow = new VisualElement();
            wedgeIoRow.style.flexDirection = FlexDirection.Row;

            var wedgeGenBtn = new Button(GenerateObjectPoseWedges) { text = "姿勢くさび生成" };
            var wedgeGetBtn = new Button(ImportObjectPoseWedges)   { text = "姿勢くさび取込" };
            wedgeGenBtn.style.flexGrow = 1;
            wedgeGetBtn.style.flexGrow = 1;
            wedgeGenBtn.tooltip =
                "全メッシュオブジェクトの姿勢を、新しい空オブジェクトの配下にくさびとして生成する\n" +
                "名前は「元メッシュ名_bone」。階層はメッシュのまま・グローバル原点・" +
                "位置0回転なしのものは空のオブジェクト";
            wedgeGetBtn.tooltip =
                "くさびのコンテナを選んで実行すると、名前（_bone を外したもの）一致で" +
                "メッシュオブジェクトの姿勢に戻す\n未選択なら生成時の名前で自動検出・見た目は保つ";

            wedgeIoRow.Add(wedgeGenBtn);
            wedgeIoRow.Add(wedgeGetBtn);
            _ignorePoseRow.Add(wedgeIoRow);

            root.Add(_ignorePoseRow);

            _statusLabel = new Label();
            _statusLabel.style.fontSize  = 10;
            _statusLabel.style.color     = new StyleColor(Color.white);
            _statusLabel.style.marginTop = 6;
            root.Add(_statusLabel);
        }

        // ================================================================
        // スコープ切り替え
        // ================================================================

        /// <summary>外部の入口ボタンから「ボーン」タブを開く。</summary>
        public void ShowBonesTab()      => SetScope(SubPanelScope.BonesOnly);
        /// <summary>外部の入口ボタンから「オブジェクト姿勢」タブを開く。</summary>
        public void ShowObjectPoseTab() => SetScope(SubPanelScope.MeshesOnly);

        private void SetScope(SubPanelScope scope)
        {
            _scope = scope;
            UpdateTabHighlight();
            Refresh();
        }

        private void UpdateTabHighlight()
        {
            void Style(Button b, bool active)
            {
                if (b == null) return;
                b.style.backgroundColor = new StyleColor(
                    active ? new Color(0.25f, 0.45f, 0.7f) : new Color(0.2f, 0.2f, 0.2f));
                b.style.color = new StyleColor(Color.white);
            }
            Style(_tabBones,  _scope == SubPanelScope.BonesOnly);
            Style(_tabMeshes, _scope == SubPanelScope.MeshesOnly);
        }

        // ================================================================
        // 対象インデックス取得（MirrorSide 除外）
        // ================================================================

        private int[] GetTargetIndices()
        {
            var model = GetModel?.Invoke();
            if (model == null) return Array.Empty<int>();

            IEnumerable<int> raw;
            switch (_scope)
            {
                case SubPanelScope.BonesOnly:
                    raw = model.SelectedBoneIndices;
                    break;
                case SubPanelScope.MeshesOnly:
                    raw = model.SelectedDrawableMeshIndices;
                    break;
                default:
                    raw = model.SelectedBoneIndices
                        .Concat(model.SelectedDrawableMeshIndices
                            .Where(i => !model.SelectedBoneIndices.Contains(i)));
                    break;
            }

            return raw.Where(i =>
            {
                var mc = model.GetMeshContext(i);
                return mc != null && mc.Type != MeshType.MirrorSide;
            }).ToArray();
        }

        // ================================================================
        // Refresh
        // ================================================================

        public void Refresh()
        {
            if (_warningLabel == null) return;

            // ObjectMoveSettings -> チェックボックス同期
            // 他経路 (Editor 拡張 UI 等) で値が変わっている可能性があるので
            // Refresh のたびに読み直す。_suppressMoveSettings で循環更新を防止。
            var moveSettings = GetObjectMoveSettings?.Invoke();
            if (moveSettings != null)
            {
                _suppressMoveSettings = true;
                try
                {
                    _toggleMoveWithChildren?.SetValueWithoutNotify(moveSettings.MoveWithChildren);
                    _toggleOriginOnly?.SetValueWithoutNotify(moveSettings.OriginOnly);
                    _toggleModeA?.SetValueWithoutNotify(moveSettings.MoveMode == Poly_Ling.Tools.BoneMoveMode.BoneOnlyRebind);
                    _toggleModeB?.SetValueWithoutNotify(moveSettings.MoveMode == Poly_Ling.Tools.BoneMoveMode.SkinBakeRebind);
                    _toggleModeC?.SetValueWithoutNotify(moveSettings.MoveMode == Poly_Ling.Tools.BoneMoveMode.PoseLayer);
                }
                finally { _suppressMoveSettings = false; }
            }

            // スコープからピックフィルタを駆動（チェックボックス廃止に伴い一本化）
            if (moveSettings != null)
            {
                bool boneScope = _scope == SubPanelScope.BonesOnly;
                moveSettings.PickBones         = boneScope;
                moveSettings.PickMeshesNoSkin  = !boneScope;
                moveSettings.PickMeshesSkinned = false;
            }

            var model = GetModel?.Invoke();

            bool showBoneSection = _scope != SubPanelScope.MeshesOnly;
            bool showIgnorePose  = _scope != SubPanelScope.BonesOnly;

            if (_boneSection    != null) _boneSection.style.display    = showBoneSection ? DisplayStyle.Flex : DisplayStyle.None;
            if (_ignorePoseRow  != null) _ignorePoseRow.style.display  = showIgnorePose  ? DisplayStyle.Flex : DisplayStyle.None;

            // 「ボーンポーズ」セクションはモードC（ポーズ一時）専用。A/Bでは常に非表示（モデル有無に依存しない）。
            bool poseModeC = (GetObjectMoveSettings?.Invoke())?.MoveMode == Poly_Ling.Tools.BoneMoveMode.PoseLayer;
            if (_bonePoseSection != null)
                _bonePoseSection.style.display = poseModeC ? DisplayStyle.Flex : DisplayStyle.None;

            // ボーン専用の移動オプション（子を一緒に移動・A/B/Cモード）はメッシュスコープでは非表示
            if (_moveOptionsSection != null)
                _moveOptionsSection.style.display = (_scope == SubPanelScope.MeshesOnly) ? DisplayStyle.None : DisplayStyle.Flex;
            // 「原点だけ移動」はメッシュ(オブジェクト姿勢)スコープ専用
            if (_meshMoveOptionsSection != null)
                _meshMoveOptionsSection.style.display = (_scope == SubPanelScope.MeshesOnly) ? DisplayStyle.Flex : DisplayStyle.None;

            if (model == null)
            {
                SetWarning("モデルがありません");
                SetTRSEnabled(false);
                return;
            }

            RefreshTargetDropdown(model);

            if (showBoneSection)
                RefreshBoneSection(model);

            var indices = GetTargetIndices();

            if (indices.Length == 0)
            {
                SetWarning("");
                _selectionCountLabel.text = ScopeEmptyMessage();
                SetTRSEnabled(false);
                _statusLabel.text = StatusText(model);
                return;
            }

            SetWarning("");
            _selectionCountLabel.text = $"{indices.Length} 項目選択中";
            SetTRSEnabled(true);
            ApplyOriginOnlyVisibility();

            // TRS 同期
            _suppressTRS = true;
            var mc0 = model.GetMeshContext(indices[0]);
            var bt0 = mc0?.BoneTransform;
            var mvs = GetObjectMoveSettings?.Invoke();
            bool poseMode = mvs != null && mvs.MoveMode == Poly_Ling.Tools.BoneMoveMode.PoseLayer;
            if (poseMode)
            {
                // モードC: ポーズ層 "Manual" の差分を表示（0＝ポーズ無し）
                var layer = mc0?.BonePoseData?.GetLayer("Manual");
                Vector3 pRot = layer != null ? NormEuler180(layer.DeltaRotation.eulerAngles) : Vector3.zero;
                Vector3 pPos = layer != null ? layer.DeltaPosition : Vector3.zero;
                SF(_posX, pPos.x); SF(_posY, pPos.y); SF(_posZ, pPos.z);
                SF(_rotX, pRot.x); SF(_rotY, pRot.y); SF(_rotZ, pRot.z);
                SS(_rotSliderX, pRot.x); SS(_rotSliderY, pRot.y); SS(_rotSliderZ, pRot.z);
                SF(_sclX, bt0?.Scale.x ?? 1f); SF(_sclY, bt0?.Scale.y ?? 1f); SF(_sclZ, bt0?.Scale.z ?? 1f);
            }
            else if (bt0 != null)
            {
                SF(_posX, bt0.Position.x); SF(_posY, bt0.Position.y); SF(_posZ, bt0.Position.z);
                SF(_rotX, bt0.Rotation.x); SF(_rotY, bt0.Rotation.y); SF(_rotZ, bt0.Rotation.z);
                SS(_rotSliderX, bt0.Rotation.x); SS(_rotSliderY, bt0.Rotation.y); SS(_rotSliderZ, bt0.Rotation.z);
                SF(_sclX, bt0.Scale.x);    SF(_sclY, bt0.Scale.y);    SF(_sclZ, bt0.Scale.z);
            }
            else
            {
                SF(_posX,0); SF(_posY,0); SF(_posZ,0);
                SF(_rotX,0); SF(_rotY,0); SF(_rotZ,0);
                SS(_rotSliderX,0); SS(_rotSliderY,0); SS(_rotSliderZ,0);
                SF(_sclX,1); SF(_sclY,1); SF(_sclZ,1);
            }

            if (_ignorePoseToggle != null && showIgnorePose)
                _ignorePoseToggle.SetValueWithoutNotify(
                    model.GetMeshContext(indices[0])?.IgnorePoseInArmature ?? false);

            if (_mirrorBranchToggle != null && showIgnorePose)
                _mirrorBranchToggle.SetValueWithoutNotify(
                    model.GetMeshContext(indices[0])?.IsMirrorBranchRoot ?? false);

            _suppressTRS = false;
            _statusLabel.text = StatusText(model);
        }

        private void RefreshBoneSection(ModelContext model)
        {
            bool hasBone = model.HasBoneSelection;
            _btnReset?.SetEnabled(hasBone);
            _btnFocus?.SetEnabled(hasBone);

            if (!hasBone)
            {
                if (_boneNameLabel != null) _boneNameLabel.text = "";
                return;
            }

            int first = model.SelectedBoneIndices[0];
            var ctx   = model.GetMeshContext(first);

            if (_bonePoseActiveToggle != null)
                _bonePoseActiveToggle.SetValueWithoutNotify(ctx?.BonePoseData?.IsActive ?? false);

            if (_boneNameLabel    != null) _boneNameLabel.text    = ctx?.Name ?? "(no name)";
            _suppressBoneEdit = true;
            if (_masterIndexField != null) _masterIndexField.SetValueWithoutNotify(first);
            int boneIdx = model.TypedIndices?.MasterToBoneIndex(first) ?? -1;
            if (_boneIndexLabel   != null) _boneIndexLabel.text   = boneIdx >= 0 ? boneIdx.ToString() : "-";
            RefreshParentDropdown(model, first);
            _suppressBoneEdit = false;
            if (_worldPosLabel != null && ctx != null)
            {
                var wm = ctx.WorldMatrix;
                _worldPosLabel.text = $"({wm.m03:F4}, {wm.m13:F4}, {wm.m23:F4})";
            }
        }

        // ================================================================
        // ボーン並べ替え / 親変更（既存 ReorderMeshesCommand を発行）
        // ================================================================

        /// <summary>親ボーン Dropdown の選択肢と現在値を更新する。</summary>
        private void RefreshParentDropdown(ModelContext model, int targetMaster)
        {
            if (_parentBoneDropdown == null) return;

            _parentChoiceMasters.Clear();
            var choices = new List<string> { "(なし)" };
            _parentChoiceMasters.Add(-1);

            foreach (var e in model.Bones)
            {
                int m = e.MasterIndex;
                if (m == targetMaster) continue;                    // 自身は親にできない
                if (IsDescendant(model, targetMaster, m)) continue; // 子孫は親にできない（循環防止）
                var c = model.GetMeshContext(m);
                choices.Add($"{c?.Name ?? "-"} [{m}]");
                _parentChoiceMasters.Add(m);
            }

            _parentBoneDropdown.choices = choices;

            int curParent = model.GetMeshContext(targetMaster)?.HierarchyParentIndex ?? -1;
            int sel = _parentChoiceMasters.IndexOf(curParent);
            if (sel < 0) sel = 0;
            _parentBoneDropdown.SetValueWithoutNotify(choices[sel]);
        }

        // ================================================================
        // オブジェクト原点の CSV 入出力
        // ================================================================

        private const string OriginCsvHeader = "#PolyLing_ObjectOrigin,version,1.0";

        // 列見出し。回転列は後ろに足すだけなので、位置だけの旧 CSV もそのまま読める。
        private const string OriginCsvColumns    = "name,posX,posY,posZ";
        private const string OriginCsvColumnsRot = "name,posX,posY,posZ,rotX,rotY,rotZ";

        /// <summary>回転(°)も書き出し・読み込みの対象にするか。</summary>
        private bool IncludeRotationInCsv => _originIncludeRotToggle?.value ?? false;

        /// <summary>全メッシュの原点(位置)を CSV へ書き出す。</summary>
        private void ExportObjectOriginsCsv()
        {
            var model = GetModel?.Invoke();
            if (model == null) return;

            string path = PLEditorBridge.I.SaveFilePanel(
                "原点CSVの書き出し", "", SanitizeFileName(model.Name) + "_origin", "csv");
            if (string.IsNullOrEmpty(path)) return;

            bool withRot = IncludeRotationInCsv;

            // 姿勢くさびは表示用の生成物で、原点は常に単位。本体の原点一覧に混ぜない。
            var wedgeIndices = Poly_Ling.Tools.ObjectPose.ObjectPoseWedgeReader
                .CollectWedgeIndices(model);

            var sb = new System.Text.StringBuilder();
            sb.AppendLine(OriginCsvHeader);
            sb.AppendLine(withRot ? OriginCsvColumnsRot : OriginCsvColumns);

            int count = 0;
            int skippedWedge = 0;
            int skippedMirror = 0;
            for (int i = 0; i < model.MeshContextCount; i++)
            {
                var mc = model.GetMeshContext(i);
                if (mc == null || mc.Type == MeshType.Bone) continue;
                // ミラー側は実体側と BoneTransform を共有する前提（H_M = H_R）。
                // 別の原点を持てないので書き出さない。読み込み側も同じ扱い。
                if (mc.Type == MeshType.MirrorSide || mc.Type == MeshType.BakedMirror)
                { skippedMirror++; continue; }
                if (wedgeIndices.Contains(i)) { skippedWedge++; continue; }
                if (string.IsNullOrEmpty(mc.Name)) continue;

                bool useLocal = mc.BoneTransform != null && mc.BoneTransform.UseLocalTransform;
                Vector3 p = useLocal ? mc.BoneTransform.Position : Vector3.zero;
                Vector3 r = useLocal ? mc.BoneTransform.Rotation : Vector3.zero;

                sb.Append(EscapeCsvField(mc.Name));
                sb.Append($",{p.x:R},{p.y:R},{p.z:R}");
                if (withRot) sb.Append($",{r.x:R},{r.y:R},{r.z:R}");
                sb.AppendLine();
                count++;
            }

            try
            {
                System.IO.File.WriteAllText(path, sb.ToString(), new System.Text.UTF8Encoding(true));
                Debug.Log($"[ObjectOrigin] 原点を書き出し: {count} 件 → {path}" +
                          $"（除外: ミラー {skippedMirror} 件 / 姿勢くさび {skippedWedge} 件）");
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[ObjectOrigin] 書き出しに失敗: {e.Message}");
            }
        }

        /// <summary>CSV から原点(位置)を読み込み、名前一致で適用する。</summary>
        private void ImportObjectOriginsCsv()
        {
            var model = GetModel?.Invoke();
            if (model == null) return;

            string path = PLEditorBridge.I.OpenFilePanel("原点CSVの読み込み", "", "csv");
            if (string.IsNullOrEmpty(path)) return;

            string[] lines;
            try
            {
                lines = System.IO.File.ReadAllLines(path);
            }
            catch (System.Exception e)
            {
                Debug.LogError($"[ObjectOrigin] 読み込みに失敗: {e.Message}");
                return;
            }

            bool withRot = IncludeRotationInCsv;

            var names     = new List<string>();
            var positions = new List<Vector3>();
            var rotations = new List<Vector3?>();
            int rotRows   = 0;

            foreach (string raw in lines)
            {
                string line = raw?.Trim('\uFEFF', ' ', '\t');
                if (string.IsNullOrEmpty(line)) continue;
                if (line.StartsWith("#")) continue;
                if (line.StartsWith("name,")) continue;   // 見出し行

                var cols = SplitCsvLine(line);
                if (cols.Count < 4) continue;

                if (!float.TryParse(cols[1], out float x)) continue;
                if (!float.TryParse(cols[2], out float y)) continue;
                if (!float.TryParse(cols[3], out float z)) continue;

                // 回転列は任意。無い行・読めない行は「回転の指定なし」として位置だけ適用する。
                Vector3? rot = null;
                if (withRot && cols.Count >= 7 &&
                    float.TryParse(cols[4], out float rx) &&
                    float.TryParse(cols[5], out float ry) &&
                    float.TryParse(cols[6], out float rz))
                {
                    rot = new Vector3(rx, ry, rz);
                    rotRows++;
                }

                names.Add(cols[0]);
                positions.Add(new Vector3(x, y, z));
                rotations.Add(rot);
            }

            if (names.Count == 0)
            {
                Debug.LogWarning("[ObjectOrigin] 有効な行がありません: " + path);
                return;
            }

            Debug.Log($"[ObjectOrigin] CSV を読み込み: {names.Count} 行" +
                      (withRot ? $"（うち回転あり {rotRows} 行）" : "（回転は対象外）"));

            SendCommand(new ApplyObjectOriginsCommand(
                GetModelIndex?.Invoke() ?? 0, names.ToArray(), positions.ToArray(),
                withRot ? rotations.ToArray() : null));

            OnRepaint?.Invoke();
        }

        // ================================================================
        // 姿勢くさびの生成・取り込み
        // ================================================================

        /// <summary>メッシュオブジェクトの姿勢をくさびオブジェクト列として生成する。</summary>
        private void GenerateObjectPoseWedges()
        {
            float length = _wedgeLengthField?.value
                ?? Poly_Ling.Tools.ObjectPose.ObjectPoseWedgeGenerator.DefaultWedgeLength;
            if (length <= 0f)
                length = Poly_Ling.Tools.ObjectPose.ObjectPoseWedgeGenerator.DefaultWedgeLength;

            SendCommand(new GenerateObjectPoseWedgesCommand(
                GetModelIndex?.Invoke() ?? 0, length,
                Poly_Ling.Tools.ObjectPose.ObjectPoseWedgeGenerator.DefaultContainerName));

            OnRepaint?.Invoke();
        }

        /// <summary>
        /// くさびオブジェクト列を姿勢として取り込む。
        /// 描画メッシュを1つだけ選んでいればそれをコンテナとみなし、
        /// そうでなければ生成時の既定名で自動検出させる。
        /// </summary>
        private void ImportObjectPoseWedges()
        {
            var model = GetModel?.Invoke();

            // 1つだけ選ばれていれば候補として渡す。的外れならディスパッチ側が
            // 名前・中身での自動検出に切り替えるので、ここでは絞り込まない。
            int container = -1;
            if (model != null && model.SelectedDrawableMeshIndices.Count == 1)
                container = model.SelectedDrawableMeshIndices[0];

            SendCommand(new ApplyObjectPoseWedgesCommand(
                GetModelIndex?.Invoke() ?? 0, container,
                Poly_Ling.Tools.ObjectPose.ObjectPoseWedgeGenerator.DefaultContainerName));

            OnRepaint?.Invoke();
        }

        private static string EscapeCsvField(string s)
        {
            if (string.IsNullOrEmpty(s)) return "";
            if (s.IndexOf(',') < 0 && s.IndexOf('"') < 0) return s;
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        }

        private static List<string> SplitCsvLine(string line)
        {
            var result = new List<string>();
            var sb     = new System.Text.StringBuilder();
            bool inQuote = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (inQuote)
                {
                    if (c == '"')
                    {
                        if (i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; }
                        else inQuote = false;
                    }
                    else sb.Append(c);
                }
                else if (c == '"') inQuote = true;
                else if (c == ',') { result.Add(sb.ToString()); sb.Clear(); }
                else sb.Append(c);
            }

            result.Add(sb.ToString());
            return result;
        }

        private static string SanitizeFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "model";
            foreach (char c in System.IO.Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        // ================================================================
        // 対象選択ドロップダウン
        // ================================================================

        /// <summary>
        /// 現在のタブに応じて選択候補を作り直し、先頭選択に合わせて表示を同期する。
        ///   ボーンタブ  : ボーン
        ///   メッシュタブ: 描画メッシュ（MirrorSide 除外）
        ///   両方タブ    : ボーン → メッシュ の順で連結
        /// 複数選択中は「(複数選択: n)」を先頭に置き、選ばれるまでコマンドを送らない。
        /// </summary>
        private void RefreshTargetDropdown(ModelContext model)
        {
            if (_boneDropdown == null) return;

            _suppressBoneDropdown = true;
            try
            {
                _targetChoiceMasters.Clear();
                _targetChoiceCategories.Clear();
                var choices = new List<string>();

                bool bothScope = _scope == SubPanelScope.Both;

                if (_scope != SubPanelScope.MeshesOnly)
                {
                    var bones = model.Bones;
                    if (bones != null)
                    {
                        foreach (var e in bones)
                        {
                            choices.Add(bothScope ? $"B: {e.Name}" : e.Name);
                            _targetChoiceMasters.Add(e.MasterIndex);
                            _targetChoiceCategories.Add(MeshCategory.Bone);
                        }
                    }
                }

                if (_scope != SubPanelScope.BonesOnly)
                {
                    var drawables = model.DrawableMeshes;
                    if (drawables != null)
                    {
                        foreach (var e in drawables)
                        {
                            if (e.Context == null || e.Context.Type == MeshType.MirrorSide) continue;
                            choices.Add(bothScope ? $"M: {e.Name}" : e.Name);
                            _targetChoiceMasters.Add(e.MasterIndex);
                            _targetChoiceCategories.Add(MeshCategory.Drawable);
                        }
                    }
                }

                // 現在の選択（GetTargetIndices と同じ集合）に合わせて表示位置を決める
                var selected = GetTargetIndices();

                if (selected.Length > 1)
                {
                    // 複数選択中はコマンドを送らせない。先頭にプレースホルダを置く。
                    choices.Insert(0, $"(複数選択: {selected.Length})");
                    _targetChoiceMasters.Insert(0, -1);
                    _targetChoiceCategories.Insert(0, MeshCategory.Bone);

                    _boneDropdown.choices = choices;
                    _boneDropdown.index   = 0;
                    return;
                }

                _boneDropdown.choices = choices;

                int dropIdx = -1;
                if (selected.Length == 1)
                    dropIdx = _targetChoiceMasters.IndexOf(selected[0]);

                _boneDropdown.index = dropIdx;
            }
            finally
            {
                _suppressBoneDropdown = false;
            }
        }

        /// <summary>ドロップダウンで対象が選ばれた時。3D ピックと同じ選択コマンドを送る。</summary>
        private void OnTargetDropdownChanged()
        {
            if (_suppressBoneDropdown) return;

            int idx = _boneDropdown?.index ?? -1;
            if (idx < 0 || idx >= _targetChoiceMasters.Count) return;

            int master = _targetChoiceMasters[idx];
            if (master < 0) return;   // 「(複数選択: n)」プレースホルダ

            SendCommand(new SelectMeshCommand(
                GetModelIndex?.Invoke() ?? 0,
                _targetChoiceCategories[idx],
                new[] { master }));

            OnRepaint?.Invoke();
        }

        private void OnMasterIndexChanged(ChangeEvent<int> evt)
        {
            if (_suppressBoneEdit) return;
            var model = GetModel?.Invoke();
            if (model == null || !model.HasBoneSelection) return;
            MoveBone(model, model.SelectedBoneIndices[0], newMaster: evt.newValue, newParentMaster: null);
        }

        private void OnParentBoneChanged(ChangeEvent<string> evt)
        {
            if (_suppressBoneEdit) return;
            var model = GetModel?.Invoke();
            if (model == null || !model.HasBoneSelection) return;
            int idx = _parentBoneDropdown.index;
            if (idx < 0 || idx >= _parentChoiceMasters.Count) return;
            MoveBone(model, model.SelectedBoneIndices[0], newMaster: null, newParentMaster: _parentChoiceMasters[idx]);
        }

        /// <summary>nodeMaster が ancestorMaster の子孫かどうか（HierarchyParentIndex を上に辿る）。</summary>
        private static bool IsDescendant(ModelContext model, int ancestorMaster, int nodeMaster)
        {
            int cur = model.GetMeshContext(nodeMaster)?.HierarchyParentIndex ?? -1;
            int guard = 0;
            while (cur >= 0 && guard++ < 4096)
            {
                if (cur == ancestorMaster) return true;
                cur = model.GetMeshContext(cur)?.HierarchyParentIndex ?? -1;
            }
            return false;
        }

        /// <summary>
        /// 対象ボーン（＋子孫サブツリー）を移動して ReorderMeshesCommand を発行する。
        /// newMaster 指定時: 親を維持しつつ親の範囲内でマスターIdx位置へ（親は超えない）。
        /// newParentMaster 指定時: 新親の子末尾へ。各パネル反映は Dispatch 側の通知に委ねる。
        /// </summary>
        private void MoveBone(ModelContext model, int target, int? newMaster, int? newParentMaster)
        {
            // 現在のボーン順（master index）と depth / parent
            var order = new List<int>();
            foreach (var e in model.Bones) order.Add(e.MasterIndex);
            int n = order.Count;
            if (n == 0) return;

            var depth  = new Dictionary<int, int>(n);
            var parent = new Dictionary<int, int>(n);
            foreach (var m in order)
            {
                var c = model.GetMeshContext(m);
                depth[m]  = c?.Depth ?? 0;
                parent[m] = c?.HierarchyParentIndex ?? -1;
            }

            int tPos = order.IndexOf(target);
            if (tPos < 0) return;
            int tDepth = depth[target];

            // 対象サブツリー範囲: tPos から subEnd の手前まで（tDepth より深い連続範囲）
            int subEnd = tPos + 1;
            while (subEnd < n && depth[order[subEnd]] > tDepth) subEnd++;
            var subtree = order.GetRange(tPos, subEnd - tPos);

            // 対象サブツリーを除いた残り
            var rest = new List<int>(order);
            rest.RemoveRange(tPos, subEnd - tPos);

            int appliedParent = parent[target];
            int appliedDepth  = tDepth;
            int insertPos;

            if (newParentMaster.HasValue)
            {
                int np = newParentMaster.Value;
                if (np == target || IsDescendant(model, target, np)) { Refresh(); return; }
                appliedParent = np;
                appliedDepth  = np >= 0
                    ? ((depth.TryGetValue(np, out var dp) ? dp : (model.GetMeshContext(np)?.Depth ?? 0)) + 1)
                    : 0;

                if (np < 0)
                {
                    insertPos = rest.Count;
                }
                else
                {
                    int npPos = rest.IndexOf(np);
                    if (npPos < 0) { Refresh(); return; }
                    int e = npPos + 1;
                    int npDepth = depth[np];
                    while (e < rest.Count && depth[rest[e]] > npDepth) e++;
                    insertPos = e;
                }
            }
            else
            {
                // マスターIdx変更: 親（維持）の範囲内にクランプ（親は超えない）
                int p = parent[target];
                int lo, hi;
                if (p < 0) { lo = 0; hi = rest.Count; }
                else
                {
                    int pPos = rest.IndexOf(p);
                    if (pPos < 0) { Refresh(); return; }
                    lo = pPos + 1;
                    int e = pPos + 1;
                    int pDepth = depth[p];
                    while (e < rest.Count && depth[rest[e]] > pDepth) e++;
                    hi = e;
                }
                // newMaster を rest 上の挿入位置に変換（newMaster 未満の master 数）
                int want = 0;
                foreach (var m in rest) { if (m < newMaster.Value) want++; else break; }
                insertPos = Mathf.Clamp(want, lo, hi);
            }

            int depthDelta = appliedDepth - tDepth;

            var newOrder = new List<int>(rest);
            newOrder.InsertRange(insertPos, subtree);

            var entries = new ReorderMeshesCommand.ReorderEntry[newOrder.Count];
            for (int i = 0; i < newOrder.Count; i++)
            {
                int m   = newOrder[i];
                int d   = depth[m];
                int par = parent[m];
                if (m == target)
                {
                    d   = appliedDepth;
                    par = appliedParent;
                }
                else if (subtree.Contains(m))
                {
                    d = depth[m] + depthDelta;   // 子孫は相対深さ維持、親は不変
                }
                entries[i] = new ReorderMeshesCommand.ReorderEntry
                {
                    MasterIndex          = m,
                    NewDepth             = d,
                    NewParentMasterIndex = par,
                };
            }

            int modelIndex = GetModelIndex?.Invoke() ?? 0;
            SendCommand(new ReorderMeshesCommand(modelIndex, MeshCategory.Bone, entries));
        }

        // ================================================================
        // ボタンアクション
        // ================================================================

        private void OnResetPose()
        {
            var model = GetModel?.Invoke();
            if (model == null || !model.HasBoneSelection) return;

            var indices = new List<int>(model.SelectedBoneIndices);
            var beforeSnapshots = new Dictionary<int, BonePoseDataSnapshot>();
            var contexts = new List<(int idx, MeshContext ctx)>();

            foreach (var idx in indices)
            {
                var ctx = model.GetMeshContext(idx);
                if (ctx == null) continue;
                if (ctx.BonePoseData == null) { ctx.BonePoseData = new BonePoseData(); ctx.BonePoseData.IsActive = true; }
                beforeSnapshots[idx] = ctx.BonePoseData.CreateSnapshot();
                contexts.Add((idx, ctx));
            }
            if (contexts.Count == 0) return;

            foreach (var (_, ctx) in contexts) { ctx.BonePoseData.ClearAllLayers(); ctx.BonePoseData.SetDirty(); }

            var undo = GetUndoController?.Invoke();
            if (undo != null)
            {
                var record = new MultiBonePoseChangeRecord();
                foreach (var (idx, ctx) in contexts)
                    record.Entries.Add(new MultiBonePoseChangeRecord.Entry
                    {
                        MasterIndex = idx,
                        OldSnapshot = beforeSnapshots.TryGetValue(idx, out var b) ? b : (BonePoseDataSnapshot?)null,
                        NewSnapshot = ctx.BonePoseData.CreateSnapshot(),
                    });
                {
                    string __dbgDesc = "ボーンポーズリセット";
                    PLDiag.UndoRecord("MeshList", __dbgDesc, record);
                    undo.MeshListStack.Record(record, __dbgDesc);
                }
                undo.FocusMeshList();
            }

            model.OnListChanged?.Invoke();
            OnRepaint?.Invoke();
            Refresh();
        }

        private void OnFocusBone()
        {
            var model = GetModel?.Invoke();
            if (model == null || !model.HasBoneSelection) return;
            var ctx = model.GetMeshContext(model.SelectedBoneIndices[0]);
            if (ctx == null) return;
            var wm = ctx.WorldMatrix;
            OnFocusCamera?.Invoke(new Vector3(wm.m03, wm.m13, wm.m23));
        }

        // ================================================================
        // TRS ヘルパー
        // ================================================================

        private void RegTF(FloatField f, SetBoneTransformValueCommand.Field field)
        {
            f.RegisterValueChangedCallback(e =>
            {
                if (_suppressTRS) return;
                var indices = GetTargetIndices();
                if (indices.Length == 0) return;
                int modelIdx = GetModelIndex?.Invoke() ?? 0;
                SendCommand(new BeginBoneTransformSliderDragCommand(modelIdx, indices)
                {
                    Mode       = GetObjectMoveSettings?.Invoke()?.MoveMode ?? Poly_Ling.Tools.BoneMoveMode.BoneOnlyRebind,
                    OriginOnly = IsOriginOnlyActive(),
                });
                SendCommand(new SetBoneTransformValueCommand(modelIdx, indices, field, e.newValue));
                SendCommand(new EndBoneTransformSliderDragCommand(modelIdx, "TRS変更"));
                OnRepaint?.Invoke();
            });
        }

        private bool _trsDragOpen;

        private void OpenTrsDrag()
        {
            if (_trsDragOpen) return;
            var indices = GetTargetIndices();
            if (indices.Length == 0) return;
            SendCommand(new BeginBoneTransformSliderDragCommand(GetModelIndex?.Invoke() ?? 0, indices)
            {
                Mode       = GetObjectMoveSettings?.Invoke()?.MoveMode ?? Poly_Ling.Tools.BoneMoveMode.BoneOnlyRebind,
                OriginOnly = IsOriginOnlyActive(),
            });
            _trsDragOpen = true;
        }

        private void CloseTrsDrag(string desc)
        {
            if (!_trsDragOpen) return;
            _trsDragOpen = false;
            SendCommand(new EndBoneTransformSliderDragCommand(GetModelIndex?.Invoke() ?? 0, desc));
        }

        private static Vector3 NormEuler180(Vector3 e)
            => new Vector3(NormAngle180(e.x), NormAngle180(e.y), NormAngle180(e.z));

        private static float NormAngle180(float a)
        {
            a %= 360f;
            if (a > 180f) a -= 360f;
            else if (a < -180f) a += 360f;
            return a;
        }

        private void RegRotSlider(Slider s, FloatField f, SetBoneTransformValueCommand.Field field)
        {
            // UIToolkit の Slider は内部ドラッガーが bubble 段階の PointerDown を消費するため、
            // capture 段階(TrickleDown)で拾う。さらに値変更時にも遅延オープンして確実に Begin を送る。
            s.RegisterCallback<PointerDownEvent>(_ => OpenTrsDrag(), TrickleDown.TrickleDown);
            s.RegisterCallback<PointerUpEvent>(_ => CloseTrsDrag("回転変更"), TrickleDown.TrickleDown);
            s.RegisterCallback<PointerCaptureOutEvent>(_ => CloseTrsDrag("回転変更"));
            s.RegisterValueChangedCallback(e =>
            {
                if (_suppressTRS) return;
                var indices = GetTargetIndices();
                if (indices.Length == 0) return;
                OpenTrsDrag();
                SendCommand(new SetBoneTransformValueCommand(GetModelIndex?.Invoke() ?? 0, indices, field, e.newValue));
                if (f != null) { _suppressTRS = true; SF(f, e.newValue); _suppressTRS = false; }
                OnRepaint?.Invoke();
            });
        }

        // ================================================================
        // UI ヘルパー
        // ================================================================

        /// <summary>
        /// 「原点だけ移動」が実際に効いている状態か。
        /// 「オブジェクト姿勢」スコープ限定（ボーンタブでは常に false）。
        /// </summary>
        private bool IsOriginOnlyActive()
            => (_scope == SubPanelScope.MeshesOnly)
               && (GetObjectMoveSettings?.Invoke()?.OriginOnly ?? false);

        /// <summary>
        /// OriginOnly(原点だけ移動)時はスケール区画を隠す。
        /// 回転は自頂点の再ローカル化で補償されるため表示する。
        /// スケールは補償経路が無いため引き続き隠す。
        /// </summary>
        private void ApplyOriginOnlyVisibility()
        {
            bool originOnly = IsOriginOnlyActive();
            if (_rotSection != null) _rotSection.style.display = DisplayStyle.Flex;
            if (_sclSection != null)
                _sclSection.style.display = originOnly ? DisplayStyle.None : DisplayStyle.Flex;
        }

        private void SetTRSEnabled(bool enabled)
        {
            _posX?.SetEnabled(enabled); _posY?.SetEnabled(enabled); _posZ?.SetEnabled(enabled);
            _rotX?.SetEnabled(enabled); _rotY?.SetEnabled(enabled); _rotZ?.SetEnabled(enabled);
            _rotSliderX?.SetEnabled(enabled); _rotSliderY?.SetEnabled(enabled); _rotSliderZ?.SetEnabled(enabled);
            _sclX?.SetEnabled(enabled); _sclY?.SetEnabled(enabled); _sclZ?.SetEnabled(enabled);
            _ignorePoseToggle?.SetEnabled(enabled);
        }

        private void SetWarning(string text)
        {
            if (_warningLabel == null) return;
            _warningLabel.text          = text;
            _warningLabel.style.display = string.IsNullOrEmpty(text) ? DisplayStyle.None : DisplayStyle.Flex;
        }

        private string ScopeEmptyMessage() => _scope switch
        {
            SubPanelScope.BonesOnly  => "未選択 — ボーンを選択してください",
            SubPanelScope.MeshesOnly => "未選択 — 描画メッシュを選択してください",
            _                        => "未選択 — オブジェクトを選択してください",
        };

        private string StatusText(ModelContext model) => _scope switch
        {
            SubPanelScope.BonesOnly  => $"Bones: {model.BoneCount}  Selected: {model.SelectedBoneIndices.Count}",
            SubPanelScope.MeshesOnly => $"Meshes: {model.DrawableCount}  Selected: {model.SelectedDrawableMeshIndices.Count}",
            _                        => $"Bones: {model.BoneCount}  Meshes: {model.DrawableCount}",
        };

        private static void AddXYZFields(VisualElement parent, string prefix,
            out FloatField fx, out FloatField fy, out FloatField fz)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.marginBottom  = 2;
            fx = MakeFloatField(prefix + "-x", "X"); row.Add(fx);
            fy = MakeFloatField(prefix + "-y", "Y"); row.Add(fy);
            fz = MakeFloatField(prefix + "-z", "Z"); row.Add(fz);
            parent.Add(row);
        }

        private static FloatField MakeFloatField(string name, string label)
        {
            var f = new FloatField(label) { name = name };
            f.style.flexGrow    = 1;
            f.style.marginRight = 2;
            f.style.color       = new StyleColor(Color.black);
            return f;
        }

        private static Slider MakeRotSlider()
        {
            var s = new Slider(-180f, 180f);
            s.style.marginBottom = 2;
            return s;
        }

        private static void SF(FloatField f, float v)
        { if (f != null) f.SetValueWithoutNotify((float)Math.Round(v, 4)); }

        private static void SS(Slider s, float v)
        { if (s != null) s.SetValueWithoutNotify(Mathf.Clamp(v, -180f, 180f)); }

        private static Button MakeScopeTab(string text, Action onClick)
        {
            var b = new Button(onClick) { text = text };
            b.style.height        = 22;
            b.style.fontSize      = 10;
            b.style.paddingTop    = 0;
            b.style.paddingBottom = 0;
            b.style.marginRight   = 1;
            return b;
        }

        private static Button MakeSmallBtn(string text)
        {
            var b = new Button { text = text };
            b.style.fontSize      = 9;
            b.style.height        = 20;
            b.style.paddingTop    = 0;
            b.style.paddingBottom = 0;
            b.style.marginBottom  = 2;
            return b;
        }

        private static void AddRow(VisualElement parent, string labelText, out Label valueLabel)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.marginBottom  = 2;
            var key = new Label(labelText + ": ");
            key.style.width    = 76;
            key.style.color    = new StyleColor(Color.white);
            key.style.fontSize = 10;
            var val = new Label();
            val.style.color    = new StyleColor(Color.white);
            val.style.flexGrow = 1;
            val.style.fontSize = 10;
            row.Add(key); row.Add(val);
            parent.Add(row);
            valueLabel = val;
        }

        private void AddIntRow(VisualElement parent, string labelText, out IntegerField field,
                               EventCallback<ChangeEvent<int>> onChange)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.marginBottom  = 2;
            var key = new Label(labelText + ": ");
            key.style.width    = 76;
            key.style.color    = new StyleColor(Color.white);
            key.style.fontSize = 10;
            var f = new IntegerField();
            f.style.flexGrow = 1;
            f.style.fontSize = 10;
            f.RegisterValueChangedCallback(onChange);
            row.Add(key); row.Add(f);
            parent.Add(row);
            field = f;
        }

        private void AddDropdownRow(VisualElement parent, string labelText, out DropdownField field,
                                    EventCallback<ChangeEvent<string>> onChange)
        {
            var row = new VisualElement();
            row.style.flexDirection = FlexDirection.Row;
            row.style.marginBottom  = 2;
            var key = new Label(labelText + ": ");
            key.style.width    = 76;
            key.style.color    = new StyleColor(Color.white);
            key.style.fontSize = 10;
            var d = new DropdownField();
            d.style.flexGrow = 1;
            d.style.fontSize = 10;
            d.RegisterValueChangedCallback(onChange);
            row.Add(key); row.Add(d);
            parent.Add(row);
            field = d;
        }

        private static Label MakeSecLabel(string text)
        {
            var l = new Label(text);
            l.style.color        = new StyleColor(new Color(0.65f, 0.8f, 1f));
            l.style.fontSize     = 10;
            l.style.marginTop    = 4;
            l.style.marginBottom = 2;
            return l;
        }

        private static VisualElement MakeSep()
        {
            var v = new VisualElement();
            v.style.height          = 1;
            v.style.marginTop       = 3;
            v.style.marginBottom    = 3;
            v.style.backgroundColor = new StyleColor(new Color(1f, 1f, 1f, 0.08f));
            return v;
        }
    }
}
