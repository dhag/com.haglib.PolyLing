Shader "Poly_Ling/Point3D_Overlay"
{
    Properties
    {
        _ScreenSpaceSize ("Screen Space Size", Float) = 8.0
        _UseScreenSpace ("Use Screen Space Size", Int) = 1
        
        // 頂点色（ShaderColorSettingsから設定）
        _ColorSelected ("Selected Fill", Color) = (1, 0.6, 0, 0.95)
        _BorderColorSelected ("Selected Border", Color) = (1, 0.6, 0, 1)
        _ColorHovered ("Hovered Fill", Color) = (1, 0, 0, 0.95)
        _BorderColorHovered ("Hovered Border", Color) = (1, 0, 0, 1)
        _ColorDefault ("Default Fill", Color) = (1, 1, 1, 0.8)
        _BorderColorDefault ("Default Border", Color) = (0.7, 0.7, 0.7, 1)
    }
    SubShader
    {
        Tags { "RenderType"="Transparent" "Queue"="Overlay+1" "RenderPipeline"="UniversalPipeline" }
        
        Pass
        {
            Tags { "LightMode" = "SRPDefaultUnlit" }
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            ZTest Always
            Offset -3, -3
            Cull Off
            
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 4.5
            
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            
            #define FLAG_MESH_SELECTED 2
            #define FLAG_HOVERED 256
            #define FLAG_HIDDEN 4096       // 1 << 12
            #define FLAG_CULLED 16384
            
            struct appdata
            {
                float4 vertex : POSITION;
                float4 color : COLOR;
                float2 uv : TEXCOORD0;
                float2 uv2 : TEXCOORD1;
            };
            
            struct v2f
            {
                float4 pos : SV_POSITION;
                float4 fillColor : TEXCOORD1;
                float4 borderColor : TEXCOORD2;
                float2 uv : TEXCOORD0;
            };
            
            float _ScreenSpaceSize;
            int _UseScreenSpace;
            
            // 色プロパティ
            float4 _ColorSelected;
            float4 _BorderColorSelected;
            float4 _ColorHovered;
            float4 _BorderColorHovered;
            float4 _ColorDefault;
            float4 _BorderColorDefault;
            
            StructuredBuffer<uint> _VertexFlagsBuffer;
            StructuredBuffer<uint> _VertexCulledBuffer;
            int _UseVertexFlagsBuffer;
            int _EnableBackfaceCulling;
            
            v2f vert(appdata v)
            {
                v2f o;
                
                if (_UseVertexFlagsBuffer > 0)
                {
                    uint idx = (uint)v.uv2.x;
                    uint flags = _VertexFlagsBuffer[idx];
                    bool isHidden = (flags & FLAG_HIDDEN) != 0;
                    bool isCulled = _VertexCulledBuffer[idx] != 0u;
                    bool isHovered = (flags & FLAG_HOVERED) != 0;
                    
                    // 非表示メッシュをスキップ
                    if (isHidden)
                    {
                        o.pos = float4(99999, 99999, 99999, 1);
                        o.fillColor = 0;
                        o.borderColor = 0;
                        o.uv = 0;
                        return o;
                    }
                    
                    // 背面カリング（有効時のみ、ホバー中は除く）
                    if (_EnableBackfaceCulling > 0 && isCulled && !isHovered)
                    {
                        o.pos = float4(99999, 99999, 99999, 1);
                        o.fillColor = 0;
                        o.borderColor = 0;
                        o.uv = 0;
                        return o;
                    }
                }
                
                // 頂点位置をクリップ空間に変換
                float4 clipPos = TransformObjectToHClip(v.vertex.xyz);
                
                // スクリーンスペースサイズを使用する場合、距離に依存しないサイズに補正
                if (_UseScreenSpace > 0)
                {
                    // クリップ空間でのオフセットを計算
                    // v.uv は quad の各頂点で (0,0), (1,0), (0,1), (1,1) など
                    // 中心からのオフセットに変換: -0.5 ~ 0.5
                    float2 offset = (v.uv - 0.5) * 2.0;
                    
                    // スクリーンピクセルサイズをクリップ空間サイズに変換
                    // clipPos.w で割ることで、距離に関係なく一定のスクリーンサイズになる
                    float2 pixelSize = _ScreenSpaceSize / _ScreenParams.xy;
                    
                    clipPos.xy += offset * pixelSize * clipPos.w;
                }
                
                o.pos = clipPos;
                
                // ShaderColorSettingsからの色を使用
                float selectState = v.color.a;
                if (selectState > 0.9)
                {
                    // 選択状態
                    o.fillColor = _ColorSelected;
                    o.borderColor = _BorderColorSelected;
                }
                else if (selectState < 0.1)
                {
                    // ホバー状態
                    o.fillColor = _ColorHovered;
                    o.borderColor = _BorderColorHovered;
                }
                else
                {
                    // 通常状態
                    o.fillColor = _ColorDefault;
                    o.borderColor = _BorderColorDefault;
                }
                
                o.uv = v.uv;
                return o;
            }
            
            float4 frag(v2f i) : SV_Target
            {
                float2 center = i.uv - 0.5;
                float2 absCenter = abs(center);
                float borderThickness = 0.15;
                bool isBorder = absCenter.x > (0.5 - borderThickness) || absCenter.y > (0.5 - borderThickness);
                return isBorder ? i.borderColor : i.fillColor;
            }
            ENDHLSL
        }
    }

    // ── Built-in SubShader（EditorWindow用）─────────────
    SubShader
    {
        Tags { "RenderType"="Transparent" "Queue"="Overlay" }
        
        Pass
        {
            Blend SrcAlpha OneMinusSrcAlpha
            ZWrite Off
            ZTest Always
            Offset -3, -3
            Cull Off
            
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 4.5
            
            #include "UnityCG.cginc"
            
            #define FLAG_MESH_SELECTED 2
            #define FLAG_HOVERED 256
            #define FLAG_HIDDEN 4096       // 1 << 12
            #define FLAG_CULLED 16384
            
            struct appdata
            {
                float4 vertex : POSITION;
                float4 color : COLOR;
                float2 uv : TEXCOORD0;
                float2 uv2 : TEXCOORD1;
            };
            
            struct v2f
            {
                float4 pos : SV_POSITION;
                float4 fillColor : COLOR0;
                float4 borderColor : COLOR1;
                float2 uv : TEXCOORD0;
            };
            
            float _ScreenSpaceSize;
            int _UseScreenSpace;
            
            // 色プロパティ
            float4 _ColorSelected;
            float4 _BorderColorSelected;
            float4 _ColorHovered;
            float4 _BorderColorHovered;
            float4 _ColorDefault;
            float4 _BorderColorDefault;
            
            StructuredBuffer<uint> _VertexFlagsBuffer;
            StructuredBuffer<uint> _VertexCulledBuffer;
            int _UseVertexFlagsBuffer;
            int _EnableBackfaceCulling;
            
            v2f vert(appdata v)
            {
                v2f o;
                
                if (_UseVertexFlagsBuffer > 0)
                {
                    uint idx = (uint)v.uv2.x;
                    uint flags = _VertexFlagsBuffer[idx];
                    bool isHidden = (flags & FLAG_HIDDEN) != 0;
                    bool isCulled = _VertexCulledBuffer[idx] != 0u;
                    bool isHovered = (flags & FLAG_HOVERED) != 0;
                    
                    // 非表示メッシュをスキップ
                    if (isHidden)
                    {
                        o.pos = float4(99999, 99999, 99999, 1);
                        o.fillColor = 0;
                        o.borderColor = 0;
                        o.uv = 0;
                        return o;
                    }
                    
                    // 背面カリング（有効時のみ、ホバー中は除く）
                    if (_EnableBackfaceCulling > 0 && isCulled && !isHovered)
                    {
                        o.pos = float4(99999, 99999, 99999, 1);
                        o.fillColor = 0;
                        o.borderColor = 0;
                        o.uv = 0;
                        return o;
                    }
                }
                
                // 頂点位置をクリップ空間に変換
                float4 clipPos = UnityObjectToClipPos(v.vertex);
                
                // スクリーンスペースサイズを使用する場合、距離に依存しないサイズに補正
                if (_UseScreenSpace > 0)
                {
                    // クリップ空間でのオフセットを計算
                    // v.uv は quad の各頂点で (0,0), (1,0), (0,1), (1,1) など
                    // 中心からのオフセットに変換: -0.5 ~ 0.5
                    float2 offset = (v.uv - 0.5) * 2.0;
                    
                    // スクリーンピクセルサイズをクリップ空間サイズに変換
                    // clipPos.w で割ることで、距離に関係なく一定のスクリーンサイズになる
                    float2 pixelSize = _ScreenSpaceSize / _ScreenParams.xy;
                    
                    clipPos.xy += offset * pixelSize * clipPos.w;
                }
                
                o.pos = clipPos;
                
                // ShaderColorSettingsからの色を使用
                float selectState = v.color.a;
                if (selectState > 0.9)
                {
                    // 選択状態
                    o.fillColor = _ColorSelected;
                    o.borderColor = _BorderColorSelected;
                }
                else if (selectState < 0.1)
                {
                    // ホバー状態
                    o.fillColor = _ColorHovered;
                    o.borderColor = _BorderColorHovered;
                }
                else
                {
                    // 通常状態
                    o.fillColor = _ColorDefault;
                    o.borderColor = _BorderColorDefault;
                }
                
                o.uv = v.uv;
                return o;
            }
            
            float4 frag(v2f i) : SV_Target
            {
                float2 center = i.uv - 0.5;
                float2 absCenter = abs(center);
                float borderThickness = 0.15;
                bool isBorder = absCenter.x > (0.5 - borderThickness) || absCenter.y > (0.5 - borderThickness);
                return isBorder ? i.borderColor : i.fillColor;
            }
            ENDCG
        }
    }
    FallBack Off
}
