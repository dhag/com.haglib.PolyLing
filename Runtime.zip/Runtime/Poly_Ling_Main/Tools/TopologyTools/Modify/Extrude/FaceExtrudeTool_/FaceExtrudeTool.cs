// Assets/Editor/Poly_Ling/Tools/Topology/FaceExtrudeTool.cs
// 面押し出しツール - IToolSettings対応版

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Poly_Ling.Data;
using Poly_Ling.Ops;
using Poly_Ling.Selection;
using Poly_Ling.UndoSystem;
using static Poly_Ling.Gizmo.GLGizmoDrawer;

namespace Poly_Ling.Tools
{
    /// <summary>
    /// 面押し出しツール
    /// </summary>
    public partial class FaceExtrudeTool : IEditTool
    {
        public string Name => "Push";
        public string DisplayName => "Push";
        //ublic ToolCategory Category => ToolCategory.Topology;

        // ================================================================
        // 設定（IToolSettings対応）
        // ================================================================

        private FaceExtrudeSettings _settings = new FaceExtrudeSettings();
        public IToolSettings Settings => _settings;

        // 設定へのショートカットプロパティ
        public FaceExtrudeSettings.ExtrudeType Type
        {
            get => _settings.Type;
            set => _settings.Type = value;
        }

        public float BevelScale
        {
            get => _settings.BevelScale;
            set => _settings.BevelScale = value;
        }

        public bool IndividualNormals
        {
            get => _settings.IndividualNormals;
            set => _settings.IndividualNormals = value;
        }

        public float DragSensitivity
        {
            get => _settings.DragSensitivity;
            set => _settings.DragSensitivity = value;
        }

        // ================================================================
        // 状態
        // ================================================================

        private enum ExtrudeState
        {
            Idle,
            PendingAction,
            Extruding
        }
        private ExtrudeState _state = ExtrudeState.Idle;

        // ドラッグ
        private Vector2 _mouseDownScreenPos;
        private int _hitFaceOnMouseDown = -1;
        private const float DragThreshold = 4f;

        // 押し出し
        private float _extrudeDistance;
        private Vector3 _extrudeDirection;

        // ドラッグ中の頂点位置更新用
        private struct FaceDragVertex
        {
            public int     Index;
            public Vector3 BasePos;
            public Vector3 Normal;
            public Vector3 FaceCenter;
        }
        private List<FaceDragVertex> _faceDragVertices = new List<FaceDragVertex>();

        // ホバー
        private int _hoverFace = -1;

        // 押し出し対象
        private List<FaceExtrudeInfo> _targetFaces = new List<FaceExtrudeInfo>();

        // Undo
        private MeshObjectSnapshot _snapshotBefore;

        private struct FaceExtrudeInfo
        {
            public int FaceIndex;
            public List<int> VertexIndices;
            public Vector3 Normal;
            public Vector3 Center;
        }

        // ================================================================
        // IEditTool 実装
        // ================================================================

        public bool OnMouseDown(ToolContext ctx, Vector2 mousePos)
        {
            if (ctx.CurrentButton != 0)
                return false;

            if (_state != ExtrudeState.Idle)
                return false;

            if (ctx.ActiveMeshObject == null || ctx.SelectionState == null)
                return false;

            _mouseDownScreenPos = mousePos;

            // _hitFaceOnMouseDown はハンドラーが PrepareHit() でセット

            if (_hitFaceOnMouseDown >= 0)
            {
                _state = ExtrudeState.PendingAction;
                // マウスダウン時にスナップショット取得
                if (ctx.UndoController != null)
                    _snapshotBefore = MeshObjectSnapshot.Capture(ctx.ActiveMeshContext, ctx.UndoController.MeshUndoContext, ctx.SelectionState);
                return false;
            }

            return false;
        }

        public bool OnMouseDrag(ToolContext ctx, Vector2 mousePos, Vector2 delta)
        {
            switch (_state)
            {
                case ExtrudeState.PendingAction:
                    float dragDistance = Vector2.Distance(mousePos, _mouseDownScreenPos);
                    if (dragDistance > DragThreshold)
                    {
                        if (_hitFaceOnMouseDown >= 0)
                        {
                            StartExtrude(ctx);
                        }
                        else
                        {
                            _state = ExtrudeState.Idle;
                            return false;
                        }
                    }
                    ctx.Repaint?.Invoke();
                    return true;

                case ExtrudeState.Extruding:
                    UpdateExtrude(ctx, mousePos);
                    ctx.Repaint?.Invoke();
                    return true;
            }

            return false;
        }

        public bool OnMouseUp(ToolContext ctx, Vector2 mousePos)
        {
            bool handled = false;

            switch (_state)
            {
                case ExtrudeState.Extruding:
                    EndExtrude(ctx);
                    handled = true;
                    break;

                case ExtrudeState.PendingAction:
                    handled = false;
                    break;
            }

            Reset();
            ctx.Repaint?.Invoke();
            return handled;
        }

        /// <summary>IMGUI 削除済み。Player は UIToolkit オーバーレイを使用。UnityEditor_Handles 使用禁止。</summary>
        /// <summary>IMGUI 削除済み。Player は UIToolkit オーバーレイを使用。UnityEditor_Handles 使用禁止。</summary>
        public void DrawGizmo(ToolContext ctx) { }

        public void OnActivate(ToolContext ctx)
        {
            if (ctx.SelectionState != null)
            {
                ctx.SelectionState.Mode |= MeshSelectMode.Face;
            }
        }

        public void OnDeactivate(ToolContext ctx)
        {
            if (_state == ExtrudeState.Extruding)
                ctx.ExitTransformDragging?.Invoke();
            Reset();
        }

        public void Reset()
        {
            _state = ExtrudeState.Idle;
            _hitFaceOnMouseDown = -1;
            _faceDragVertices.Clear();
            _targetFaces.Clear();
            _snapshotBefore = null;
            _extrudeDistance = 0f;
            _extrudeDirection = Vector3.zero;
        }

        public void OnSelectionChanged(ToolContext ctx)
        {
        }

        // ── UIToolkit hover support ───────────────────────────────────────
        /// <summary>現在ホバー中の面インデックス（-1=なし、UIToolkit オーバーレイ用）</summary>
        public int HoverFace => _hoverFace;

        /// <summary>ハンドラーが GPU ホバー結果からセット。FindFaceAtPosition（CPU・カリング無視）使用禁止。</summary>
        public void SetHoverFace(int faceIdx)
        {
            _hoverFace = (_state == ExtrudeState.Idle || _state == ExtrudeState.PendingAction) ? faceIdx : -1;
        }

        /// <summary>OnLeftDragBegin でハンドラーが GPU ホバー結果から事前にセット。</summary>
        public void PrepareHit(int faceIdx) { _hitFaceOnMouseDown = faceIdx; }

        // ================================================================
        // 押し出し処理
        // ================================================================

        private void StartExtrude(ToolContext ctx)
        {
            if (_hitFaceOnMouseDown >= 0 && !ctx.SelectionState.Faces.Contains(_hitFaceOnMouseDown))
            {
                ctx.SelectionState.Faces.Clear();
                ctx.SelectionState.Faces.Add(_hitFaceOnMouseDown);
            }

            CollectTargetFaces(ctx);

            if (_targetFaces.Count == 0)
            {
                _state = ExtrudeState.Idle;
                return;
            }

            _extrudeDirection = Vector3.zero;
            foreach (var faceInfo in _targetFaces)
                _extrudeDirection += faceInfo.Normal;
            _extrudeDirection = _extrudeDirection.magnitude > 0.001f
                ? _extrudeDirection.normalized
                : Vector3.up;

            _extrudeDistance = 0f;

            // トポロジーを即時実行し _faceDragVertices を確定させる
            ExecuteExtrude(ctx);  // 内部で ctx.SyncMesh (= NotifyTopologyChanged) を呼ぶ

            _state = ExtrudeState.Extruding;
            ctx.EnterTransformDragging?.Invoke();
        }

        /// <summary>
        /// 変換の基準にする頂点。対象面の先頭頂点を使う。
        /// スキンド頂点はボーンの SkinningMatrix で変換されるため、メッシュの
        /// WorldMatrix 系（ActiveWorldToLocalVector 等）を使うと倍率と向きが合わない。
        /// </summary>
        private int BasisVertex()
        {
            if (_targetFaces.Count == 0) return -1;
            var vs = _targetFaces[0].VertexIndices;
            return (vs != null && vs.Count > 0) ? vs[0] : -1;
        }

        private void UpdateExtrude(ToolContext ctx, Vector2 mousePos)
        {
            Vector2 totalDelta = mousePos - _mouseDownScreenPos;
            // カメラ平面（ウインドウ座標系）のワールドデルタ。頂点移動と同じ変換。
            // 押し出し量はローカル空間の長さとして使うため、ローカルへ変換してから大きさを取る。
            int basis = BasisVertex();
            Vector3 worldDelta = ScreenDeltaToWorldDelta(ctx, totalDelta);
            Vector3 localDelta = ctx.WorldToLocalVectorAt(basis, worldDelta);

            Vector2 dirScreen = WorldDirToScreenDir(ctx, _extrudeDirection);
            if (dirScreen.magnitude > 0.001f)
            {
                // 押し出し方向がビューに見えている: 「画面投影した平均法線の向き」と
                // 「マウス移動」の内積で符号を決める。totalDelta も dirScreen も同じ
                // 画面座標系(Y下)なので符号が正しく出る。world 空間 Dot だと
                // ScreenDeltaToWorldDelta の Y 系(Y上前提)とズレて上下が反転するため使わない。
                // 大きさは投影分を world スケールへ換算（大きさは符号非依存）。
                Vector2 dir    = dirScreen.normalized;
                float   signed = Vector2.Dot(totalDelta, dir);
                Vector3 proj   = ctx.WorldToLocalVectorAt(basis, ScreenDeltaToWorldDelta(ctx, dir * signed));
                _extrudeDistance = Mathf.Sign(signed) * proj.magnitude * DragSensitivity;
            }
            else
            {
                // 方向がほぼ視線方向（画面上で潰れる）: 上下ドラッグの見た目距離を係数化。
                _extrudeDistance = Mathf.Sign(-totalDelta.y) * localDelta.magnitude * DragSensitivity;
            }

            var meshObject = ctx.ActiveMeshObject;
            if (meshObject != null)
            {
                foreach (var dv in _faceDragVertices)
                {
                    if (dv.Index < 0 || dv.Index >= meshObject.VertexCount) continue;
                    Vector3 offset  = dv.Normal * _extrudeDistance;
                    Vector3 pos     = dv.BasePos + offset;
                    if (Type == FaceExtrudeSettings.ExtrudeType.Bevel)
                    {
                        Vector3 newCenter = dv.FaceCenter + offset;
                        Vector3 toCenter  = newCenter - pos;
                        pos = pos + toCenter * (1f - BevelScale);
                    }
                    meshObject.Vertices[dv.Index].Position = pos;
                }
            }
            ctx.SyncMeshPositionsOnly?.Invoke();
        }

        private Vector3 ScreenDeltaToWorldDelta(ToolContext ctx, Vector2 sd)
        {
            if (ctx.ScreenDeltaToWorldDelta != null)
                return ctx.ScreenDeltaToWorldDelta(sd, ctx.CameraPosition, ctx.CameraTarget, ctx.CameraDistance, ctx.PreviewRect);
            float s = ctx.CameraDistance * 0.001f;
            return new Vector3(sd.x * s, -sd.y * s, 0f);
        }

        /// <summary>
        /// ローカル方向を画面上の 2D 方向に変換する。
        /// 面中心は面の構成頂点の GPU ワールド座標の平均で求める（CPU で計算し直さない）。
        /// 方向は基準頂点の行列でワールド化する。
        /// </summary>
        /// <summary>
        /// 面中心のワールド座標。構成頂点の GPU ワールド座標（ctx.GetVertexWorldPosition）の平均。
        /// 取得できない頂点は基準頂点の行列でローカルから変換する。
        /// </summary>
        private static Vector3 FaceCenterWorld(ToolContext ctx, FaceExtrudeInfo info)
        {
            var mo = ctx.ActiveMeshObject;
            var vs = info.VertexIndices;
            if (mo == null || vs == null || vs.Count == 0)
                return ctx.ActiveWorldMatrix.MultiplyPoint3x4(info.Center);

            Vector3 sum = Vector3.zero;
            int n = 0;
            for (int i = 0; i < vs.Count; i++)
            {
                int vi = vs[i];
                if (vi < 0 || vi >= mo.Vertices.Count) continue;

                var w = ctx.GetVertexWorldPosition?.Invoke(vi);
                sum += w ?? ctx.ActiveVertexMatrix(vi).MultiplyPoint3x4(mo.Vertices[vi].Position);
                n++;
            }

            return n > 0 ? sum / n : ctx.ActiveWorldMatrix.MultiplyPoint3x4(info.Center);
        }

        private Vector2 WorldDirToScreenDir(ToolContext ctx, Vector3 localDir)
        {
            if (_targetFaces.Count == 0) return Vector2.up;

            int basis = BasisVertex();
            Vector3 centerWorld = FaceCenterWorld(ctx, _targetFaces[0]);
            Vector3 dirWorld    = ctx.LocalToWorldVectorAt(basis, localDir);
            Vector2 screenCenter = ctx.WorldToScreen(centerWorld);
            Vector2 screenEnd    = ctx.WorldToScreen(centerWorld + dirWorld);

            return screenEnd - screenCenter;
        }

        private void EndExtrude(ToolContext ctx)
        {
            ctx.ExitTransformDragging?.Invoke();

            if (ctx.UndoController != null && _snapshotBefore != null)
            {
                var snapshotAfter = MeshObjectSnapshot.Capture(ctx.ActiveMeshContext, ctx.UndoController.MeshUndoContext, ctx.SelectionState);
                var record = new MeshSnapshotRecord(_snapshotBefore, snapshotAfter, ctx.SelectionState);
                ctx.UndoController.FocusVertexEdit();
                {
                    string __dbgDesc = "Extrude Faces";
                    UnityEngine.Debug.Log("[UndoDbg] VertexEdit.Record desc=" + __dbgDesc + " type=" + ((record)?.GetType().Name ?? "<null>"));
                    ctx.UndoController.VertexEditStack.Record(record, __dbgDesc);
                }
            }

            _snapshotBefore = null;
        }

        private void ExecuteExtrude(ToolContext ctx)
        {
            var meshObject = ctx.ActiveMeshObject;

            Vector3 avgNormal = Vector3.zero;
            if (!IndividualNormals)
            {
                foreach (var faceInfo in _targetFaces)
                    avgNormal += faceInfo.Normal;
                avgNormal = avgNormal.magnitude > 0.001f ? avgNormal.normalized : Vector3.up;
            }

            int materialIndex = ctx.CurrentMaterialIndex;
            var newVertexIndices = new List<int>();
            var newFaceIndices = new List<int>();

            _faceDragVertices.Clear();

            foreach (var faceInfo in _targetFaces)
            {
                Vector3 normal = IndividualNormals ? faceInfo.Normal : avgNormal;
                Vector3 offset = normal * _extrudeDistance;
                Vector3 newCenter = faceInfo.Center + offset;

                var vertexMap = new Dictionary<int, int>();

                foreach (int oldVIdx in faceInfo.VertexIndices)
                {
                    if (oldVIdx < 0 || oldVIdx >= meshObject.VertexCount) continue;

                    var oldVertex = meshObject.Vertices[oldVIdx];
                    Vector3 newPos = oldVertex.Position + offset;

                    if (Type == FaceExtrudeSettings.ExtrudeType.Bevel)
                    {
                        Vector3 toCenter = newCenter - newPos;
                        newPos = newPos + toCenter * (1f - BevelScale);
                    }

                    int newIdx = meshObject.VertexCount;
                    var newVertex = new Vertex { Position = newPos };
                    newVertex.UVs.AddRange(oldVertex.UVs);
                    newVertex.Normals.AddRange(oldVertex.Normals);
                    // 複製元の BoneWeight をコピーする。設定しないと GPU 側で
                    // メッシュ自身の context 索引が使われ（UnifiedBufferManager_Build.cs:356-362）、
                    // 周囲の頂点と別の行列で変換されてこの頂点だけ離れた位置に置かれる。
                    newVertex.BoneWeight = oldVertex.BoneWeight;

                    meshObject.Vertices.Add(newVertex);
                    vertexMap[oldVIdx] = newIdx;
                    newVertexIndices.Add(newIdx);

                    _faceDragVertices.Add(new FaceDragVertex
                    {
                        Index      = newIdx,
                        BasePos    = oldVertex.Position,
                        Normal     = normal,
                        FaceCenter = faceInfo.Center,
                    });
                }

                int vertCount = faceInfo.VertexIndices.Count;
                for (int i = 0; i < vertCount; i++)
                {
                    int v0 = faceInfo.VertexIndices[i];
                    int v1 = faceInfo.VertexIndices[(i + 1) % vertCount];

                    if (!vertexMap.ContainsKey(v0) || !vertexMap.ContainsKey(v1)) continue;

                    int nv0 = vertexMap[v0];
                    int nv1 = vertexMap[v1];

                    var sideFace = new Face { MaterialIndex = materialIndex };
                    sideFace.VertexIndices.AddRange(new[] { v0, v1, nv1, nv0 });
                    sideFace.UVIndices.AddRange(new[] { v0, v1, nv1, nv0 });
                    sideFace.NormalIndices.AddRange(new[] { v0, v1, nv1, nv0 });
                    meshObject.Faces.Add(sideFace);
                }

                var originalFace = meshObject.Faces[faceInfo.FaceIndex];
                int origVertCount = originalFace.VertexIndices.Count;

                while (originalFace.UVIndices.Count < origVertCount)
                    originalFace.UVIndices.Add(originalFace.VertexIndices[originalFace.UVIndices.Count]);
                while (originalFace.NormalIndices.Count < origVertCount)
                    originalFace.NormalIndices.Add(originalFace.VertexIndices[originalFace.NormalIndices.Count]);

                for (int i = 0; i < origVertCount; i++)
                {
                    int oldIdx = originalFace.VertexIndices[i];
                    if (vertexMap.ContainsKey(oldIdx))
                    {
                        int newIdx = vertexMap[oldIdx];
                        originalFace.VertexIndices[i] = newIdx;
                        originalFace.UVIndices[i] = newIdx;
                        originalFace.NormalIndices[i] = newIdx;
                    }
                }

                newFaceIndices.Add(faceInfo.FaceIndex);
            }

            ctx.SelectionState.Faces.Clear();
            foreach (int fIdx in newFaceIndices)
                ctx.SelectionState.Faces.Add(fIdx);

            ctx.SyncMesh?.Invoke();
        }

        // ================================================================
        // ヘルパー
        // ================================================================

        private void CollectTargetFaces(ToolContext ctx)
        {
            _targetFaces.Clear();

            foreach (int faceIdx in ctx.SelectionState.Faces)
            {
                var info = CreateFaceInfo(ctx.ActiveMeshObject, faceIdx);
                if (info.HasValue)
                    _targetFaces.Add(info.Value);
            }
        }

        private FaceExtrudeInfo? CreateFaceInfo(MeshObject meshObject, int faceIdx)
        {
            if (faceIdx < 0 || faceIdx >= meshObject.FaceCount)
                return null;

            var face = meshObject.Faces[faceIdx];
            if (face.VertexCount < 3)
                return null;

            var vertIndices = new List<int>(face.VertexIndices);

            Vector3 center = Vector3.zero;
            foreach (int vIdx in vertIndices)
            {
                if (vIdx >= 0 && vIdx < meshObject.VertexCount)
                    center += meshObject.Vertices[vIdx].Position;
            }
            center /= vertIndices.Count;

            Vector3 normal = Vector3.up;
            if (vertIndices.Count >= 3)
            {
                Vector3 p0 = meshObject.Vertices[vertIndices[0]].Position;
                Vector3 p1 = meshObject.Vertices[vertIndices[1]].Position;
                Vector3 p2 = meshObject.Vertices[vertIndices[2]].Position;
                normal = NormalHelper.CalculateFaceNormal(p0, p1, p2);
            }

            return new FaceExtrudeInfo
            {
                FaceIndex = faceIdx,
                VertexIndices = vertIndices,
                Normal = normal,
                Center = center
            };
        }





    }
}
