// HumanoidBoneMapping.cs
// Unity Humanoid Avatar用のボーンマッピングデータ
// モデルごとに保持し、Avatar作成時に使用
//
// 【格納規約】格納・参照・永続化の規約は
//   MeshObject.cs「ボーン付帯データ格納規約」を正典とする。
//   ※本クラスの name→index Dict は規約3の「派生ビュー／実行時 working」。
//     canonical は per-bone（MeshObject.HumanBodyBone）。両者の同期は保存・読込の
//     境界のみ（保存時 SyncPerBoneFromMapping／読込後 RebuildMappingFromPerBone）で、
//     編集中のリアルタイム同期はしない（割当は本 Dict を UI 経由で編集する）。

using System;
using System.Collections.Generic;
using UnityEngine;
using Poly_Ling.Data;

namespace Poly_Ling.Data
{
    /// <summary>
    /// Humanoidボーンマッピング
    /// Unity Humanoid名 → ボーンインデックス（MeshContextListのインデックス）
    /// </summary>
    [Serializable]
    public class HumanoidBoneMapping
    {
        // ================================================================
        // 静的データ: Humanoidボーン定義
        // ================================================================

        /// <summary>
        /// 全Humanoidボーン名（55個）
        /// HumanBodyBones列挙体の順序に対応
        /// </summary>
        public static readonly string[] AllHumanoidBones = new string[]
        {
            // 体幹 (0-4)
            "Hips",
            "Spine",
            "Chest",
            "UpperChest",
            "Neck",
            
            // 頭 (5-8)
            "Head",
            "LeftEye",
            "RightEye",
            "Jaw",
            
            // 左腕 (9-14)
            "LeftShoulder",
            "LeftUpperArm",
            "LeftLowerArm",
            "LeftHand",
            
            // 右腕 (14-17)
            "RightShoulder",
            "RightUpperArm",
            "RightLowerArm",
            "RightHand",
            
            // 左脚 (18-22)
            "LeftUpperLeg",
            "LeftLowerLeg",
            "LeftFoot",
            "LeftToes",
            
            // 右脚 (23-27)
            "RightUpperLeg",
            "RightLowerLeg",
            "RightFoot",
            "RightToes",
            
            // 左手指 (28-42)
            "Left Thumb Proximal",
            "Left Thumb Intermediate",
            "Left Thumb Distal",
            "Left Index Proximal",
            "Left Index Intermediate",
            "Left Index Distal",
            "Left Middle Proximal",
            "Left Middle Intermediate",
            "Left Middle Distal",
            "Left Ring Proximal",
            "Left Ring Intermediate",
            "Left Ring Distal",
            "Left Little Proximal",
            "Left Little Intermediate",
            "Left Little Distal",
            
            // 右手指 (43-57)
            "Right Thumb Proximal",
            "Right Thumb Intermediate",
            "Right Thumb Distal",
            "Right Index Proximal",
            "Right Index Intermediate",
            "Right Index Distal",
            "Right Middle Proximal",
            "Right Middle Intermediate",
            "Right Middle Distal",
            "Right Ring Proximal",
            "Right Ring Intermediate",
            "Right Ring Distal",
            "Right Little Proximal",
            "Right Little Intermediate",
            "Right Little Distal"
        };

        /// <summary>
        /// 必須ボーン（これがないとHumanoid Avatarは作成できない）
        /// </summary>
        public static readonly HashSet<string> RequiredBones = new HashSet<string>
        {
            "Hips",
            "Spine",
            "Chest",
            "Neck",
            "Head",
            "LeftUpperArm",
            "LeftLowerArm",
            "LeftHand",
            "RightUpperArm",
            "RightLowerArm",
            "RightHand",
            "LeftUpperLeg",
            "LeftLowerLeg",
            "LeftFoot",
            "RightUpperLeg",
            "RightLowerLeg",
            "RightFoot"
        };

        /// <summary>
        /// PMX標準ボーン名 → Unity Humanoid名 のデフォルトマッピング
        /// 注意: PMXの「下半身」と「上半身」は兄弟関係（両方とも「センター」の子）
        /// Unity Humanoidでは Hips → Spine の親子関係が必要なため、
        /// 「センター」をHipsに、「上半身」をSpineにマッピングする
        /// 「下半身」はHumanoidには含めない（足の回転制御用ボーン）
        /// </summary>
        public static readonly Dictionary<string, string> DefaultPMXMapping = new Dictionary<string, string>
        {
            // 体幹
            // 「センター」をHipsに（「下半身」ではなく）
            // これにより「上半身」(Spine)が正しく子孫になる
            { "センター", "Hips" },
            { "グルーブ", "Hips" },      // センターがない場合の代替
            { "全ての親", "Hips" },      // 全ての親をルートとする場合
            // { "下半身", "Hips" },     // 除外: 上半身が下半身の子孫でないためエラーになる
            { "上半身", "Spine" },
            { "上半身2", "Chest" },
            { "上半身3", "UpperChest" },
            { "首", "Neck" },
            { "頭", "Head" },
            
            // 目・顎
            { "左目", "LeftEye" },
            { "右目", "RightEye" },
            { "あご", "Jaw" },
            
            // 左腕
            { "左肩", "LeftShoulder" },
            { "左腕", "LeftUpperArm" },
            { "左ひじ", "LeftLowerArm" },
            { "左手首", "LeftHand" },
            
            // 右腕
            { "右肩", "RightShoulder" },
            { "右腕", "RightUpperArm" },
            { "右ひじ", "RightLowerArm" },
            { "右手首", "RightHand" },
            
            // 左脚
            { "左足", "LeftUpperLeg" },
            { "左ひざ", "LeftLowerLeg" },
            { "左足首", "LeftFoot" },
            { "左つま先", "LeftToes" },
            
            // 右脚
            { "右足", "RightUpperLeg" },
            { "右ひざ", "RightLowerLeg" },
            { "右足首", "RightFoot" },
            { "右つま先", "RightToes" },
            
            // 左手指
            { "左親指０", "Left Thumb Proximal" },
            { "左親指１", "Left Thumb Intermediate" },
            { "左親指２", "Left Thumb Distal" },
            { "左人指１", "Left Index Proximal" },
            { "左人指２", "Left Index Intermediate" },
            { "左人指３", "Left Index Distal" },
            { "左中指１", "Left Middle Proximal" },
            { "左中指２", "Left Middle Intermediate" },
            { "左中指３", "Left Middle Distal" },
            { "左薬指１", "Left Ring Proximal" },
            { "左薬指２", "Left Ring Intermediate" },
            { "左薬指３", "Left Ring Distal" },
            { "左小指１", "Left Little Proximal" },
            { "左小指２", "Left Little Intermediate" },
            { "左小指３", "Left Little Distal" },
            
            // 右手指
            { "右親指０", "Right Thumb Proximal" },
            { "右親指１", "Right Thumb Intermediate" },
            { "右親指２", "Right Thumb Distal" },
            { "右人指１", "Right Index Proximal" },
            { "右人指２", "Right Index Intermediate" },
            { "右人指３", "Right Index Distal" },
            { "右中指１", "Right Middle Proximal" },
            { "右中指２", "Right Middle Intermediate" },
            { "右中指３", "Right Middle Distal" },
            { "右薬指１", "Right Ring Proximal" },
            { "右薬指２", "Right Ring Intermediate" },
            { "右薬指３", "Right Ring Distal" },
            { "右小指１", "Right Little Proximal" },
            { "右小指２", "Right Little Intermediate" },
            { "右小指３", "Right Little Distal" }
        };

        /// <summary>
        /// 埋め込みボーンマッピング（CSV由来）
        /// Unity Humanoid名 → エイリアスリスト（優先度順、1列目=Unity名自身を含む）
        /// UpperChestは存在しないモデルも多いためオプション扱い
        /// </summary>
        public static readonly Dictionary<string, List<string>> EmbeddedMapping = new()
        {
            // 体幹
            { "Hips", new List<string> { "Hips", "hip", "センター", "ヒップ" } },
            { "Spine", new List<string> { "Spine", "上半身", "背骨" } },
            { "Chest", new List<string> { "Chest", "上半身2", "背骨2", "胸" } },
            { "UpperChest", new List<string> { "UpperChest", "上半身3", "背骨3", "胸2" } },
            { "Neck", new List<string> { "Neck", "首" } },
            { "Head", new List<string> { "Head", "頭" } },

            // 目・顎
            { "LeftEye", new List<string> { "LeftEye", "左目" } },
            { "RightEye", new List<string> { "RightEye", "右目" } },
            { "Jaw", new List<string> { "Jaw" } },

            // 左腕
            { "LeftShoulder", new List<string> { "LeftShoulder", "左肩" } },
            { "LeftUpperArm", new List<string> { "LeftUpperArm", "左腕" } },
            { "LeftLowerArm", new List<string> { "LeftLowerArm", "左ひじ" } },
            { "LeftHand", new List<string> { "LeftHand", "左手首" } },

            // 右腕
            { "RightShoulder", new List<string> { "RightShoulder", "右肩" } },
            { "RightUpperArm", new List<string> { "RightUpperArm", "右腕" } },
            { "RightLowerArm", new List<string> { "RightLowerArm", "右ひじ" } },
            { "RightHand", new List<string> { "RightHand", "右手首" } },

            // 左脚
            { "LeftUpperLeg", new List<string> { "LeftUpperLeg", "左足" } },
            { "LeftLowerLeg", new List<string> { "LeftLowerLeg", "左ひざ" } },
            { "LeftFoot", new List<string> { "LeftFoot", "左足首" } },
            { "LeftToes", new List<string> { "LeftToes", "左つま先" } },

            // 右脚
            { "RightUpperLeg", new List<string> { "RightUpperLeg", "右足" } },
            { "RightLowerLeg", new List<string> { "RightLowerLeg", "右ひざ" } },
            { "RightFoot", new List<string> { "RightFoot", "右足首" } },
            { "RightToes", new List<string> { "RightToes", "右つま先" } },

            // 左手指
            { "Left Thumb Proximal", new List<string> { "Left Thumb Proximal", "左親指１" } },
            { "Left Thumb Intermediate", new List<string> { "Left Thumb Intermediate", "左親指２" } },
            { "Left Thumb Distal", new List<string> { "Left Thumb Distal" } },
            { "Left Index Proximal", new List<string> { "Left Index Proximal", "左人指１" } },
            { "Left Index Intermediate", new List<string> { "Left Index Intermediate", "左人指２" } },
            { "Left Index Distal", new List<string> { "Left Index Distal", "左人指３" } },
            { "Left Middle Proximal", new List<string> { "Left Middle Proximal", "左中指１" } },
            { "Left Middle Intermediate", new List<string> { "Left Middle Intermediate", "左中指２" } },
            { "Left Middle Distal", new List<string> { "Left Middle Distal", "左中指３" } },
            { "Left Ring Proximal", new List<string> { "Left Ring Proximal", "左薬指１" } },
            { "Left Ring Intermediate", new List<string> { "Left Ring Intermediate", "左薬指２" } },
            { "Left Ring Distal", new List<string> { "Left Ring Distal", "左薬指３" } },
            { "Left Little Proximal", new List<string> { "Left Little Proximal", "左小指１" } },
            { "Left Little Intermediate", new List<string> { "Left Little Intermediate", "左小指２" } },
            { "Left Little Distal", new List<string> { "Left Little Distal", "左小指３" } },

            // 右手指
            { "Right Thumb Proximal", new List<string> { "Right Thumb Proximal", "右親指１" } },
            { "Right Thumb Intermediate", new List<string> { "Right Thumb Intermediate", "右親指２" } },
            { "Right Thumb Distal", new List<string> { "Right Thumb Distal" } },
            { "Right Index Proximal", new List<string> { "Right Index Proximal", "右人指１" } },
            { "Right Index Intermediate", new List<string> { "Right Index Intermediate", "右人指２" } },
            { "Right Index Distal", new List<string> { "Right Index Distal", "右人指３" } },
            { "Right Middle Proximal", new List<string> { "Right Middle Proximal", "右中指１" } },
            { "Right Middle Intermediate", new List<string> { "Right Middle Intermediate", "右中指２" } },
            { "Right Middle Distal", new List<string> { "Right Middle Distal", "右中指３" } },
            { "Right Ring Proximal", new List<string> { "Right Ring Proximal", "右薬指１" } },
            { "Right Ring Intermediate", new List<string> { "Right Ring Intermediate", "右薬指２" } },
            { "Right Ring Distal", new List<string> { "Right Ring Distal", "右薬指３" } },
            { "Right Little Proximal", new List<string> { "Right Little Proximal", "右小指１" } },
            { "Right Little Intermediate", new List<string> { "Right Little Intermediate", "右小指２" } },
            { "Right Little Distal", new List<string> { "Right Little Distal", "右小指３" } },
        };

        // ================================================================
        // インスタンスデータ
        // ================================================================

        /// <summary>
        /// Unity Humanoid名 → ボーンインデックス（MeshContextListのインデックス）
        /// -1 = 未割り当て
        /// </summary>
        [SerializeField]
        private Dictionary<string, int> _boneIndexMap = new Dictionary<string, int>();

        // ================================================================
        // プロパティ
        // ================================================================

        /// <summary>マッピング数</summary>
        public int Count => _boneIndexMap.Count;

        /// <summary>マッピングが空か</summary>
        public bool IsEmpty => _boneIndexMap.Count == 0;

        /// <summary>内部辞書への読み取り専用アクセス</summary>
        public IReadOnlyDictionary<string, int> BoneIndexMap => _boneIndexMap;

        // ================================================================
        // 操作
        // ================================================================

        /// <summary>
        /// マッピングを設定
        /// </summary>
        /// <param name="humanoidBone">Unity Humanoidボーン名</param>
        /// <param name="boneIndex">MeshContextListのインデックス（-1で削除）</param>
        public void Set(string humanoidBone, int boneIndex)
        {
            if (string.IsNullOrEmpty(humanoidBone))
                return;

            if (boneIndex < 0)
            {
                _boneIndexMap.Remove(humanoidBone);
            }
            else
            {
                _boneIndexMap[humanoidBone] = boneIndex;
            }
        }

        /// <summary>
        /// マッピングを取得
        /// </summary>
        /// <param name="humanoidBone">Unity Humanoidボーン名</param>
        /// <returns>ボーンインデックス（未設定の場合-1）</returns>
        public int Get(string humanoidBone)
        {
            if (string.IsNullOrEmpty(humanoidBone))
                return -1;

            return _boneIndexMap.TryGetValue(humanoidBone, out int index) ? index : -1;
        }

        /// <summary>
        /// マッピングが存在するか確認
        /// </summary>
        public bool Has(string humanoidBone)
        {
            return !string.IsNullOrEmpty(humanoidBone) && _boneIndexMap.ContainsKey(humanoidBone);
        }

        /// <summary>
        /// 指定ボーンのマッピングを削除
        /// </summary>
        public void Clear(string humanoidBone)
        {
            if (!string.IsNullOrEmpty(humanoidBone))
            {
                _boneIndexMap.Remove(humanoidBone);
            }
        }

        /// <summary>
        /// 全マッピングをクリア
        /// </summary>
        public void ClearAll()
        {
            _boneIndexMap.Clear();
        }

        // ================================================================
        // 共通あいまい検索
        // ================================================================

        /// <summary>
        /// エイリアスリストを使って候補名リストからあいまい検索
        /// AvatarCreatorPanel と HumanoidBoneMapping で共通使用
        /// 優先度: 完全一致 → 候補名がエイリアスを含む → エイリアスが候補名を含む
        /// </summary>
        /// <param name="candidateNames">検索対象の名前リスト</param>
        /// <param name="aliases">エイリアスリスト（優先度順）</param>
        /// <param name="fuzzyMatch">あいまい検索を有効にするか</param>
        /// <returns>マッチした候補のインデックス（不一致時 -1）</returns>
        public static int FindBoneByAliases(IList<string> candidateNames, List<string> aliases, bool fuzzyMatch = true)
        {
            if (candidateNames == null || aliases == null)
                return -1;

            foreach (string alias in aliases)
            {
                if (string.IsNullOrEmpty(alias)) continue;

                // 完全一致（case-insensitive）
                for (int i = 0; i < candidateNames.Count; i++)
                {
                    if (string.Equals(candidateNames[i], alias, StringComparison.OrdinalIgnoreCase))
                        return i;
                }

                if (fuzzyMatch)
                {
                    // 候補名がエイリアスを含む（例: alias="右手首", candidate="右手首Cylinder" → hit）
                    // 逆方向（alias.Contains(candidate)）は誤マッチの原因になるため除外
                    // 例: alias="上半身3"がcandidate="上半身"にマッチしてしまう
                    for (int i = 0; i < candidateNames.Count; i++)
                    {
                        if (candidateNames[i] != null &&
                            candidateNames[i].IndexOf(alias, StringComparison.OrdinalIgnoreCase) >= 0)
                            return i;
                    }
                }
            }

            return -1;
        }

        // ================================================================
        // 自動マッピング
        // ================================================================

        /// <summary>
        /// ボーン名からPMXデフォルトマッピングを使用して自動設定（あいまい検索対応）
        /// </summary>
        /// <param name="boneNames">ボーン名リスト（インデックス = MeshContextListのインデックス）</param>
        /// <returns>マッピングされたボーン数</returns>
        public int AutoMapFromPMX(IList<string> boneNames)
        {
            if (boneNames == null)
                return 0;

            // DefaultPMXMappingを Unity名 → エイリアスリスト に再構成
            // 同じUnity名に複数のPMX名がマッピングされている場合をまとめる
            var unityToAliases = new Dictionary<string, List<string>>();
            foreach (var kvp in DefaultPMXMapping)
            {
                string pmxName = kvp.Key;
                string humanoidName = kvp.Value;
                if (!unityToAliases.TryGetValue(humanoidName, out var list))
                {
                    list = new List<string>();
                    unityToAliases[humanoidName] = list;
                }
                list.Add(pmxName);
            }

            int mappedCount = 0;
            var unmapped = new List<string>();

            foreach (var kvp in unityToAliases)
            {
                string humanoidName = kvp.Key;
                List<string> aliases = kvp.Value;

                // 既にマッピングがある場合はスキップ
                if (_boneIndexMap.ContainsKey(humanoidName))
                    continue;

                int foundIndex = FindBoneByAliases(boneNames, aliases);
                if (foundIndex >= 0)
                {
                    _boneIndexMap[humanoidName] = foundIndex;
                    mappedCount++;
                }
                else
                {
                    unmapped.Add($"{humanoidName} ({string.Join(", ", aliases)})");
                }
            }

            if (unmapped.Count > 0)
            {
                Debug.LogWarning($"[HumanoidBoneMapping] AutoMapFromPMX: {unmapped.Count} unmatched:\n  " +
                                 string.Join("\n  ", unmapped));
            }

            return mappedCount;
        }

        /// <summary>
        /// 埋め込みマッピングデータを使用して自動設定（あいまい検索対応）
        /// AutoMapFromPMXの後継。EmbeddedMappingを使用。
        /// </summary>
        /// <param name="boneNames">ボーン名リスト（インデックス = MeshContextListのインデックス）</param>
        /// <param name="fuzzyMatch">あいまい検索を有効にするか（デフォルトtrue）</param>
        /// <returns>マッピングされたボーン数</returns>
        public int AutoMapFromEmbeddedCSV(IList<string> boneNames, bool fuzzyMatch = true)
        {
            if (boneNames == null)
                return 0;

            int mappedCount = 0;
            var unmapped = new List<string>();

            foreach (var kvp in EmbeddedMapping)
            {
                string humanoidName = kvp.Key;
                List<string> aliases = kvp.Value;

                // 既にマッピングがある場合はスキップ
                if (_boneIndexMap.ContainsKey(humanoidName))
                    continue;

                int foundIndex = FindBoneByAliases(boneNames, aliases, fuzzyMatch);
                if (foundIndex >= 0)
                {
                    _boneIndexMap[humanoidName] = foundIndex;
                    mappedCount++;
                }
                else
                {
                    // 必須ボーンのみ警告出力
                    if (RequiredBones.Contains(humanoidName))
                        unmapped.Add($"{humanoidName} ({string.Join(", ", aliases)})");
                }
            }

            if (unmapped.Count > 0)
            {
                Debug.LogWarning($"[HumanoidBoneMapping] AutoMapFromEmbeddedCSV: {unmapped.Count} required bones unmatched:\n  " +
                                 string.Join("\n  ", unmapped));
            }

            return mappedCount;
        }

        /// <summary>
        /// CSV形式のマッピングデータを読み込み（あいまい検索対応）
        /// 形式: UnityHumanoidName,Alias1,Alias2,...
        /// AvatarCreatorPanelと同じCSV形式・検索方式
        /// </summary>
        /// <param name="csvLines">CSVの行リスト</param>
        /// <param name="boneNames">ボーン名リスト（インデックス = MeshContextListのインデックス）</param>
        /// <returns>マッピングされたボーン数</returns>
        /// <summary>Unity Humanoid のボーン名か（大小・空白を無視して照合）。</summary>
        public static bool IsHumanoidBoneName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;

            string n = name.Replace(" ", "").Replace("_", "");
            foreach (var b in AllHumanoidBones)
            {
                if (string.Equals(b.Replace(" ", "").Replace("_", ""), n,
                                  StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        public int LoadFromCSV(IList<string> csvLines, IList<string> boneNames)
        {
            if (csvLines == null || boneNames == null)
                return 0;

            int mappedCount = 0;
            bool isHeader = true;
            var unmapped = new List<string>();
            var invalidNames = new List<string>();

            foreach (var line in csvLines)
            {
                // ヘッダー行をスキップ
                if (isHeader)
                {
                    isHeader = false;
                    continue;
                }

                // コメント行をスキップ
                if (line.StartsWith("//")) continue;

                var parts = line.Split(',');
                if (parts.Length < 1) continue;

                string unityName = parts[0].Trim();
                if (string.IsNullOrEmpty(unityName)) continue;

                // 1列目は Humanoid ボーン名でなければならない。
                // ここを検証しないと、原点CSV のような「オブジェクト名の一覧」を
                // 渡したときに全行が自分自身へ完全一致して「成功」してしまい、
                // LeftUpperArm 等のキーが1つも無いマッピングが出来上がる。
                if (!IsHumanoidBoneName(unityName))
                {
                    invalidNames.Add(unityName);
                    continue;
                }

                // 1列目（Unity名）を最優先エイリアスとし、2列目以降を追加エイリアス
                var aliases = new List<string> { unityName };
                for (int i = 1; i < parts.Length; i++)
                {
                    string alias = parts[i].Trim();
                    if (!string.IsNullOrEmpty(alias))
                        aliases.Add(alias);
                }

                // あいまい検索でボーンを検索
                int foundIndex = FindBoneByAliases(boneNames, aliases);
                if (foundIndex >= 0)
                {
                    _boneIndexMap[unityName] = foundIndex;
                    mappedCount++;
                }
                else
                {
                    unmapped.Add($"{unityName} ({string.Join(", ", aliases)})");
                }
            }

            if (unmapped.Count > 0)
            {
                Debug.LogWarning($"[HumanoidBoneMapping] LoadFromCSV: {unmapped.Count} unmatched:\n  " +
                                 string.Join("\n  ", unmapped));
            }

            if (invalidNames.Count > 0)
            {
                int show = Mathf.Min(5, invalidNames.Count);
                Debug.LogWarning(
                    $"[HumanoidBoneMapping] LoadFromCSV: 1列目が Humanoid ボーン名でない行を無視: " +
                    $"{invalidNames.Count} 行 ({string.Join(", ", invalidNames.GetRange(0, show))} …)\n" +
                    "Humanoidマッピング用のCSVではない可能性があります" +
                    "（1列目は Hips / LeftUpperArm などの Unity Humanoid 名）。");
            }

            return mappedCount;
        }

        // ================================================================
        // 検証
        // ================================================================

        /// <summary>
        /// 必須ボーンが全てマッピングされているか確認
        /// </summary>
        /// <returns>不足している必須ボーン名のリスト</returns>
        public List<string> GetMissingRequiredBones()
        {
            var missing = new List<string>();

            foreach (var required in RequiredBones)
            {
                if (!_boneIndexMap.ContainsKey(required) || _boneIndexMap[required] < 0)
                {
                    missing.Add(required);
                }
            }

            return missing;
        }

        /// <summary>
        /// Humanoid Avatarを作成可能か（必須ボーンが揃っているか）
        /// </summary>
        public bool CanCreateAvatar => GetMissingRequiredBones().Count == 0;

        // ================================================================
        // T-Pose用ヘルパー
        // ================================================================

        /// <summary>
        /// 腕ボーンのインデックスを取得（TPoseConverter用）
        /// </summary>
        /// <param name="isLeft">左腕ならtrue</param>
        /// <param name="upperArmIndex">UpperArmのMeshContextインデックス</param>
        /// <param name="lowerArmIndex">LowerArmのMeshContextインデックス</param>
        /// <returns>両方見つかればtrue</returns>
        public bool GetArmBoneIndices(bool isLeft, out int upperArmIndex, out int lowerArmIndex)
        {
            string upperName = isLeft ? "LeftUpperArm" : "RightUpperArm";
            string lowerName = isLeft ? "LeftLowerArm" : "RightLowerArm";

            upperArmIndex = Get(upperName);
            lowerArmIndex = Get(lowerName);

            return upperArmIndex >= 0 && lowerArmIndex >= 0;
        }

        // ================================================================
        // UNDO用: Clone / CopyFrom
        // ================================================================

        /// <summary>
        /// 深いコピーを作成
        /// </summary>
        public HumanoidBoneMapping Clone()
        {
            var clone = new HumanoidBoneMapping();
            foreach (var kvp in _boneIndexMap)
            {
                clone._boneIndexMap[kvp.Key] = kvp.Value;
            }
            return clone;
        }

        /// <summary>
        /// 他のマッピングからデータをコピー
        /// </summary>
        public void CopyFrom(HumanoidBoneMapping other)
        {
            _boneIndexMap.Clear();
            if (other != null)
            {
                foreach (var kvp in other._boneIndexMap)
                {
                    _boneIndexMap[kvp.Key] = kvp.Value;
                }
            }
        }

        // ================================================================
        // シリアライズ用
        // ================================================================

        /// <summary>
        /// Dictionary形式で取得（シリアライズ用）
        /// </summary>
        public Dictionary<string, int> ToDictionary()
        {
            return new Dictionary<string, int>(_boneIndexMap);
        }

        /// <summary>
        /// Dictionary形式から復元（デシリアライズ用）
        /// </summary>
        public void FromDictionary(Dictionary<string, int> dict)
        {
            _boneIndexMap.Clear();
            if (dict != null)
            {
                foreach (var kvp in dict)
                {
                    _boneIndexMap[kvp.Key] = kvp.Value;
                }
            }
        }
    }
}
