// ReorderDiagLog.cs
// メッシュリストの並べ替え（D&D / ▲▼ / Indent / Outdent）1回ぶんを
// 1ファイルにまとめて書き出す診断ログ。
//
// 記録するのは3点だけ:
//   [DROP]    何を掴んで、どの行の、どの位置に落としたか
//   [ENTRIES] UI が送った並び (MasterIndex, 名前, NewDepth, NewParentMasterIndex)
//   [APPLIED] 適用後の MeshContextList (index, 名前, Depth, HierarchyParentIndex)
//
// Console は流れて追えないためファイルへ出す。
// 出力先: Application.persistentDataPath/PolyLingDiag/reorder_yyyyMMdd_HHmmss_fff.txt
//
// 確認が済んだら Enabled を false にする（または本ファイルごと削除する）。
//
// Runtime/Poly_Ling_Main/Core/Misc/ に配置

using System;
using System.IO;
using System.Text;
using UnityEngine;

namespace Poly_Ling.Diagnostics
{
    public static class ReorderDiagLog
    {
        /// <summary>診断ログの有効/無効。ここ1つで全体を切る。</summary>
        public const bool Enabled = true;

        private static StringBuilder _sb;
        private static string _sessionLabel;

        /// <summary>セッション開始。既に開いていれば捨てて開き直す。</summary>
        public static void Begin(string label)
        {
            if (!Enabled) return;
            _sb = new StringBuilder(1 << 16);
            _sessionLabel = label ?? "";
            _sb.Append("=== reorder diag: ").Append(_sessionLabel)
               .Append("  ").Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"))
               .Append(" ===\n");
        }

        /// <summary>セッションが開いていなければ開く。</summary>
        public static void EnsureBegin(string label)
        {
            if (!Enabled) return;
            if (_sb == null) Begin(label);
        }

        public static bool IsOpen => Enabled && _sb != null;

        /// <summary>セクション見出し。</summary>
        public static void Section(string name)
        {
            if (!Enabled || _sb == null) return;
            _sb.Append('\n').Append('[').Append(name).Append("]\n");
        }

        /// <summary>1行追加。</summary>
        public static void Line(string text)
        {
            if (!Enabled || _sb == null) return;
            _sb.Append(text).Append('\n');
        }

        /// <summary>セッションを閉じてファイルへ書き出す。</summary>
        public static void Flush()
        {
            if (!Enabled || _sb == null) return;
            var body = _sb.ToString();
            _sb = null;

            try
            {
                string dir = Path.Combine(Application.persistentDataPath, "PolyLingDiag");
                Directory.CreateDirectory(dir);
                string path = Path.Combine(
                    dir, "reorder_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff") + ".txt");
                File.WriteAllText(path, body, new UTF8Encoding(false));
                Debug.Log("[ReorderDiag] wrote " + path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning("[ReorderDiag] write failed: " + ex.Message);
            }
        }

        /// <summary>書き出さずに破棄する。</summary>
        public static void Abort()
        {
            if (!Enabled) return;
            _sb = null;
        }
    }
}
