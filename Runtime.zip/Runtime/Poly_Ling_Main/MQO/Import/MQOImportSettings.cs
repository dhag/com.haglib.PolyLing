// Assets/Editor/Poly_Ling/MQO/Import/MQOImportSettings.cs
// MQOインポート設定
// IToolSettings実装でUndo対応
// v1.1: ImportMode追加

using System;
using UnityEngine;
using Poly_Ling.Ops;
using Poly_Ling.Tools;
using Poly_Ling.PMX; // AlphaConflictMode

namespace Poly_Ling.MQO
{
    /// <summary>
    /// MQOインポートモード
    /// </summary>
    public enum MQOImportMode
    {
        /// <summary>新規モデルとして追加（デフォルト）</summary>
        NewModel,
        /// <summary>既存メッシュに追加（マテリアルインデックス補正あり）</summary>
        Append,
        /// <summary>既存メッシュを置換（全削除後にインポート）</summary>
        Replace
    }

    /// <summary>
    /// 法線計算モード
    /// </summary>
    public enum NormalMode
    {
        /// <summary>面法線をそのまま使用（フラットシェーディング、エディット向け）</summary>
        FaceNormal,
        /// <summary>スムージング角度で平均化（スムーズシェーディング）</summary>
        Smooth,
        /// <summary>Unity標準のRecalculateNormalsを使用</summary>
        Unity,
        /// <summary>
        /// スムージング角で法線を分割（辺を共有する隣接面のみを連結）。
        /// ハードエッジを表現できるが、その分だけUV/法線スロットが増える。
        /// 従来と同じ結果が必要な場合は Smooth を選ぶこと。
        /// </summary>
        SmoothFacet,
    }

    /// <summary>
    /// MQOインポート設定
    /// </summary>
    [Serializable]
    public class MQOImportSettings : IToolSettings
    {
        // ================================================================
        // インポートモード（v1.2: NewModelがデフォルト）
        // ================================================================

        /// <summary>インポートモード</summary>
        [Tooltip("NewModel: 新規モデルとして追加, Append: 既存メッシュに追加, Replace: 既存メッシュを全削除してからインポート")]
        public MQOImportMode ImportMode = MQOImportMode.NewModel;

        // ================================================================
        // 座標変換設定
        // ================================================================

        /// <summary>スケール（MQO→Unity）デフォルト0.01（MqoUnityRatio）</summary>
        [Tooltip("MQO座標をUnity座標に変換するスケール（デフォルト: 0.01 = MqoUnityRatio）")]
        public float Scale = 0.01f;

        /// <summary>X軸反転</summary>
        [Tooltip("X軸を反転する（MQOは右手系・正面+Z、Unityは左手系・正面+Z。X反転だけで両者が揃う）")]
        public bool FlipX = true;

        /// <summary>Z軸反転</summary>
        [Tooltip("Z軸を反転する。FlipX と併用すると正面が反転する")]
        public bool FlipZ = false;

        /// <summary>
        /// 軸反転指定。MQO は右手系で正面 +Z、Unity は左手系で正面 +Z。
        /// 正面を保ったまま手系を変えるには X のみ反転すればよい（既定）。
        /// 反転軸が奇数個なので鏡映であり、面の巻き順の扱いは従来（FlipZ 単独）と同じ。
        /// </summary>
        public AxisFlip Flip => new AxisFlip(FlipX, FlipZ);

        /// <summary>UV V座標反転</summary>
        [Tooltip("UV座標のV成分を反転する")]
        public bool FlipUV_V = true;

        // ================================================================
        // インポートオプション
        // ================================================================

        /// <summary>マテリアルをインポート</summary>
        [Tooltip("MQOマテリアルをUnityマテリアルに変換する")]
        public bool ImportMaterials = true;

        /// <summary>非表示オブジェクトをスキップ</summary>
        [Tooltip("MQOで非表示に設定されているオブジェクトをスキップする")]
        public bool SkipHiddenObjects = false;

        /// <summary>空のオブジェクトをスキップ</summary>
        [Tooltip("頂点や面を持たないオブジェクト（グループ用ダミー等）をスキップする")]
        public bool SkipEmptyObjects = false;

        /// <summary>全オブジェクトを統合</summary>
        [Tooltip("全てのオブジェクトを1つのメッシュに統合する")]
        public bool MergeObjects = false;

        /// <summary>メッシュの親子を GameObject 階層（HierarchyParentIndex）にも設定</summary>
        [Tooltip("MQOのオブジェクト階層を、Transform の親子（HierarchyParentIndex）としても設定する")]
        public bool SetMeshHierarchyParent = true;

        /// <summary>
        /// MQO の頂点を絶対座標として読み込む。
        /// メタセコイアはローカル座標（translation/rotation/scale）をピボットとして扱い、
        /// 形状は動かさない。PolyLing は world = 親のworld × ローカル で頂点を動かすため、
        /// 読み込んだ頂点をワールド行列で割り戻してローカル化する必要がある。
        /// ローカル変換が単位のオブジェクトでは何も変わらない。
        /// </summary>
        [Tooltip("MQOの頂点を絶対座標として読み込む（メタセコイアのローカル座標はピボット扱いのため）")]
        public bool ImportVerticesAsWorldSpace = true;

        /// <summary>名前からミラー分岐ルートを自動設定</summary>
        [Tooltip("接頭句「@@」かつ接尾句「ミラー分岐ルート」を持つオブジェクトに、ミラー分岐ルートフラグを付ける")]
        public bool AutoDetectMirrorBranchRoot = true;

        /// <summary>MQOファイルからボーンインデックスを読み込まない</summary>
        [Tooltip("MQO特殊面からボーンインデックス情報を読み込まない")]
        public bool SkipMqoBoneIndices = false;

        /// <summary>MQOファイルからウェイトを読み込まない</summary>
        [Tooltip("MQO特殊面からボーンウェイト情報を読み込まない")]
        public bool SkipMqoBoneWeights = false;

        // ================================================================
        // アルファ設定
        // ================================================================

        /// <summary>アルファカットオフ値 (0-1)（テクスチャアルファのしきい値）</summary>
        [Tooltip("テクスチャアルファチャンネルのカットオフしきい値")]
        [Range(0f, 1f)]
        public float AlphaCutoff = 0.5f;

        /// <summary>材質不透明度とテクスチャアルファが競合する場合の動作</summary>
        [Tooltip("Color.a < 1.0 かつテクスチャがある場合の動作")]
        public AlphaConflictMode AlphaConflict = AlphaConflictMode.PreferTransparent;

        // ================================================================
        // 詳細設定
        // ================================================================

        /// <summary>法線計算モード</summary>
        [Tooltip("FaceNormal: 面法線そのまま（フラット）, Smooth: スムージング")]
        public NormalMode NormalMode = NormalMode.Smooth;

        /// <summary>スムージング角度（度）</summary>
        [Tooltip("法線スムージングの閾値角度（NormalMode=Smoothの時のみ有効）")]
        [Range(0f, 180f)]
        public float SmoothingAngle = 60f;

        /// <summary>MQOオブジェクトの facet / shading 属性を使うか（NormalMode=SmoothFacetの時のみ有効）</summary>
        [Tooltip("ON: オブジェクト毎の facet 角と shading を使う / OFF: SmoothingAngle を全オブジェクトに適用")]
        public bool UseMqoFacet = true;

        // ================================================================
        // ボーンウェイト設定（オプション）
        // ================================================================

        /// <summary>ボーンウェイトCSVファイルパス（空の場合は適用しない）</summary>
        [Tooltip("ボーンウェイト情報を含むCSVファイル（MqoObjectName,VertexID,VertexIndex,Bone0-3,Weight0-3）")]
        public string BoneWeightCSVPath = "";

        /// <summary>ボーンウェイトCSVを使用するか</summary>
        public bool UseBoneWeightCSV => !string.IsNullOrEmpty(BoneWeightCSVPath);

        /// <summary>ボーン定義CSVファイルパス（PmxBone形式）</summary>
        [Tooltip("ボーン定義を含むCSVファイル（PmxBone形式）")]
        public string BoneCSVPath = "";

        /// <summary>ボーンCSVを使用するか</summary>
        public bool UseBoneCSV => !string.IsNullOrEmpty(BoneCSVPath);

        /// <summary>ボーンスケール（PMXボーン座標に適用、デフォルト1.0）</summary>
        [Tooltip("PMXボーン座標に適用するスケール（MQOと同じScaleを使う場合は1.0）")]
        public float BoneScale = 10.0f;//pmx由来のボーン位置をMQOスケールに合わせるためのデフォルト値

        // ================================================================
        // ミラー設定
        // ================================================================

        /// <summary>ミラーをベイク（実体化）</summary>
        [Tooltip("ミラー属性を持つメッシュのミラー側を実体メッシュとして生成する")]
        public bool BakeMirror = false;

        /// <summary>__Armature__からボーンをインポート</summary>
        [Tooltip("MQO内の__Armature__オブジェクト以下をボーン構造としてインポートする")]
        public bool ImportBonesFromArmature = true;

        /// <summary>AポーズをTポーズに変換</summary>
        [Tooltip("腕ボーンを水平に回転させてTポーズに変換する（スキニング頂点も変換）")]
        public bool ConvertToTPose = false;

        // ================================================================
        // 頂点デバッグ設定
        // ================================================================

        /// <summary>頂点デバッグログを出力</summary>
        [Tooltip("メッシュオブジェクトごとの頂点情報をコンソールに出力する")]
        public bool DebugVertexInfo = false;

        /// <summary>同一頂点・近接UV検出時に出力する件数</summary>
        [Tooltip("同一頂点で異なるUVを持つペアの出力件数（近い順）")]
        [Range(1, 100)]
        public int DebugVertexNearUVCount = 10;

        // ================================================================
        // テクスチャ読み込み用
        // ================================================================

        /// <summary>MQOファイルのベースディレクトリ（テクスチャ相対パス解決用）</summary>
        [NonSerialized]
        public string BaseDir = "";

        // ================================================================
        // ファクトリメソッド
        // ================================================================

        /// <summary>デフォルト設定を作成</summary>
        public static MQOImportSettings CreateDefault()
        {
            return new MQOImportSettings();
        }

        /// <summary>MMD互換設定を作成（1/10スケール、Z反転）</summary>
        public static MQOImportSettings CreateMMDCompatible()
        {
            return new MQOImportSettings
            {
                Scale = 0.1f,
                FlipX = true,
                FlipZ = false,
                FlipUV_V = false,
                BoneScale = 1f  // MMD互換MQOはPMXスケール、ボーンも同スケール
            };
        }

        /// <summary>
        /// 座標系設定から初期化
        /// Scale = mqoUnityRatio（MQO→Unity比率）
        /// BoneScale = pmxUnityRatio / mqoUnityRatio（PMXボーン座標→MQO座標の変換）
        /// </summary>
        public static MQOImportSettings CreateFromCoordinate(float mqoUnityRatio, bool flipZ, float pmxUnityRatio = 0.1f, bool flipX = true)
        {
            return new MQOImportSettings
            {
                Scale = mqoUnityRatio,
                FlipX = flipX,
                FlipZ = flipZ,
                FlipUV_V = true,
                BoneScale = mqoUnityRatio > 0f ? pmxUnityRatio / mqoUnityRatio : 10f  // PMXボーン座標→MQO座標の比率
            };
        }

        /// <summary>等倍設定を作成（スケール1:1）</summary>
        public static MQOImportSettings CreateNoScale()
        {
            return new MQOImportSettings
            {
                Scale = 1f,
                FlipX = true,
                FlipZ = false,
                FlipUV_V = false
            };
        }

        // ================================================================
        // IToolSettings 実装
        // ================================================================

        public IToolSettings Clone()
        {
            return new MQOImportSettings
            {
                ImportMode = this.ImportMode,
                Scale = this.Scale,
                FlipX = this.FlipX,
                FlipZ = this.FlipZ,
                FlipUV_V = this.FlipUV_V,
                ImportMaterials = this.ImportMaterials,
                SkipHiddenObjects = this.SkipHiddenObjects,
                SkipEmptyObjects = this.SkipEmptyObjects,
                MergeObjects = this.MergeObjects,
                SetMeshHierarchyParent = this.SetMeshHierarchyParent,
                ImportVerticesAsWorldSpace = this.ImportVerticesAsWorldSpace,
                AutoDetectMirrorBranchRoot = this.AutoDetectMirrorBranchRoot,
                SkipMqoBoneIndices = this.SkipMqoBoneIndices,
                SkipMqoBoneWeights = this.SkipMqoBoneWeights,
                AlphaCutoff = this.AlphaCutoff,
                AlphaConflict = this.AlphaConflict,
                NormalMode = this.NormalMode,
                SmoothingAngle = this.SmoothingAngle,
                UseMqoFacet = this.UseMqoFacet,
                BoneWeightCSVPath = this.BoneWeightCSVPath,
                BakeMirror = this.BakeMirror,
                ImportBonesFromArmature = this.ImportBonesFromArmature,
                ConvertToTPose = this.ConvertToTPose,
                DebugVertexInfo = this.DebugVertexInfo,
                DebugVertexNearUVCount = this.DebugVertexNearUVCount
            };
        }

        public bool IsDifferentFrom(IToolSettings other)
        {
            if (other is not MQOImportSettings o)
                return true;

            return ImportMode != o.ImportMode ||
                   !Mathf.Approximately(Scale, o.Scale) ||
                   FlipX != o.FlipX ||
                   FlipZ != o.FlipZ ||
                   FlipUV_V != o.FlipUV_V ||
                   ImportMaterials != o.ImportMaterials ||
                   SkipHiddenObjects != o.SkipHiddenObjects ||
                   SkipEmptyObjects != o.SkipEmptyObjects ||
                   MergeObjects != o.MergeObjects ||
                   SetMeshHierarchyParent != o.SetMeshHierarchyParent ||
                   ImportVerticesAsWorldSpace != o.ImportVerticesAsWorldSpace ||
                   AutoDetectMirrorBranchRoot != o.AutoDetectMirrorBranchRoot ||
                   SkipMqoBoneIndices != o.SkipMqoBoneIndices ||
                   SkipMqoBoneWeights != o.SkipMqoBoneWeights ||
                   !Mathf.Approximately(AlphaCutoff, o.AlphaCutoff) ||
                   AlphaConflict != o.AlphaConflict ||
                   NormalMode != o.NormalMode ||
                   !Mathf.Approximately(SmoothingAngle, o.SmoothingAngle) ||
                   UseMqoFacet != o.UseMqoFacet ||
                   BoneWeightCSVPath != o.BoneWeightCSVPath ||
                   BakeMirror != o.BakeMirror ||
                   ImportBonesFromArmature != o.ImportBonesFromArmature ||
                   ConvertToTPose != o.ConvertToTPose ||
                   DebugVertexInfo != o.DebugVertexInfo ||
                   DebugVertexNearUVCount != o.DebugVertexNearUVCount;
        }

        public void CopyFrom(IToolSettings other)
        {
            if (other is not MQOImportSettings o)
                return;

            ImportMode = o.ImportMode;
            Scale = o.Scale;
            FlipX = o.FlipX;
            FlipZ = o.FlipZ;
            FlipUV_V = o.FlipUV_V;
            ImportMaterials = o.ImportMaterials;
            SkipHiddenObjects = o.SkipHiddenObjects;
            SkipEmptyObjects = o.SkipEmptyObjects;
            MergeObjects = o.MergeObjects;
            SetMeshHierarchyParent = o.SetMeshHierarchyParent;
            ImportVerticesAsWorldSpace = o.ImportVerticesAsWorldSpace;
            AutoDetectMirrorBranchRoot = o.AutoDetectMirrorBranchRoot;
            SkipMqoBoneIndices = o.SkipMqoBoneIndices;
            SkipMqoBoneWeights = o.SkipMqoBoneWeights;
            AlphaCutoff = o.AlphaCutoff;
            AlphaConflict = o.AlphaConflict;
            NormalMode = o.NormalMode;
            SmoothingAngle = o.SmoothingAngle;
            UseMqoFacet = o.UseMqoFacet;
            BoneWeightCSVPath = o.BoneWeightCSVPath;
            BakeMirror = o.BakeMirror;
            ImportBonesFromArmature = o.ImportBonesFromArmature;
            ConvertToTPose = o.ConvertToTPose;
            DebugVertexInfo = o.DebugVertexInfo;
            DebugVertexNearUVCount = o.DebugVertexNearUVCount;
        }

        // ================================================================
        // ヘルパー
        // ================================================================

        /// <summary>デフォルトにリセット</summary>
        public void Reset()
        {
            var def = CreateDefault();
            CopyFrom(def);
        }
    }
}
