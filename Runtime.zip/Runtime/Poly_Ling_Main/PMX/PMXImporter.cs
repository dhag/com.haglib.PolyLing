// Assets/Editor/Poly_Ling/PMX/Import/PMXImporter.cs
// PMXDocument → MeshObject/MeshContext 変換
// SimpleMeshFactoryのデータ構造に変換
// 頂点共有する材質をグループ化

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Poly_Ling.Data;
using Poly_Ling.Ops;
using Poly_Ling.Context;
using Poly_Ling.Tools;
using Poly_Ling.Materials;
using Poly_Ling.Core;
using Poly_Ling.Symmetry;

namespace Poly_Ling.PMX
{
    /// <summary>
    /// PMXインポート結果
    /// </summary>
    public class PMXImportResult
    {
        /// <summary>成功したか</summary>
        public bool Success { get; set; }

        /// <summary>エラーメッセージ</summary>
        public string ErrorMessage { get; set; }

        /// <summary>インポートされたMeshContextリスト</summary>
        public List<MeshContext> MeshContexts { get; } = new List<MeshContext>();

        /// <summary>
        /// 各ボーンのPMXワールド位置（インポート時の初期位置）
        /// CCDIKSolverのSetBonePositionsに渡す用
        /// </summary>
        public Vector3[] BoneWorldPositions { get; set; }

        /// <summary>インポートされたマテリアル参照リスト（正式形式）</summary>
        public List<MaterialReference> MaterialReferences { get; } = new List<MaterialReference>();

        /// <summary>
        /// インポートされたマテリアルリスト（MaterialReferencesから導出）
        /// </summary>
        public List<Material> Materials
        {
            get
            {
                var list = new List<Material>();
                foreach (var matRef in MaterialReferences)
                {
                    list.Add(matRef?.Material);
                }
                return list;
            }
        }

        /// <summary>マテリアル数</summary>
        public int MaterialCount => MaterialReferences.Count;

        /// <summary>元のPMXドキュメント</summary>
        public PMXDocument Document { get; set; }

        /// <summary>インポートされたモーフエクスプレッション</summary>
        public List<MorphExpression> MorphExpressions { get; } = new List<MorphExpression>();

        /// <summary>検出されたミラーペア</summary>
        public List<MirrorPair> MirrorPairs { get; } = new List<MirrorPair>();

        /// <summary>材質グループ情報（モーフ変換で使用）</summary>
        public List<MaterialGroupInfo> MaterialGroupInfos { get; } = new List<MaterialGroupInfo>();

        /// <summary>インポート統計</summary>
        public PMXImportStats Stats { get; } = new PMXImportStats();

        /// <summary>
        /// 全MeshContextの面のMaterialIndexにオフセットを加算
        /// Appendモードで既存マテリアルがある場合に使用
        /// </summary>
        /// <param name="offset">加算するオフセット（既存マテリアル数）</param>
        public void ApplyMaterialIndexOffset(int offset)
        {
            if (offset <= 0) return;

            foreach (var meshContext in MeshContexts)
            {
                if (meshContext?.MeshObject == null) continue;

                foreach (var face in meshContext.MeshObject.Faces)
                {
                    if (face.MaterialIndex >= 0)
                    {
                        face.MaterialIndex += offset;
                    }
                }
            }

            Debug.Log($"[PMXImportResult] Applied material index offset: +{offset}");
        }

        /// <summary>
        /// 全MeshContextの頂点のBoneWeightインデックスにオフセットを加算
        /// Appendモードで既存MeshContextがある場合に使用
        /// </summary>
        /// <param name="offset">加算するオフセット（既存MeshContext数）</param>
        public void ApplyBoneWeightIndexOffset(int offset)
        {
            if (offset <= 0) return;

            int convertedCount = 0;
            foreach (var meshContext in MeshContexts)
            {
                if (meshContext?.MeshObject == null) continue;

                // ボーンタイプの場合はBoneWeightを持たない
                if (meshContext.Type == MeshType.Bone) continue;

                foreach (var vertex in meshContext.MeshObject.Vertices)
                {
                    if (vertex.BoneWeight.HasValue)
                    {
                        var bw = vertex.BoneWeight.Value;
                        vertex.BoneWeight = new UnityEngine.BoneWeight
                        {
                            boneIndex0 = bw.boneIndex0 + offset,
                            boneIndex1 = bw.weight1 > 0 ? bw.boneIndex1 + offset : bw.boneIndex1,
                            boneIndex2 = bw.weight2 > 0 ? bw.boneIndex2 + offset : bw.boneIndex2,
                            boneIndex3 = bw.weight3 > 0 ? bw.boneIndex3 + offset : bw.boneIndex3,
                            weight0 = bw.weight0,
                            weight1 = bw.weight1,
                            weight2 = bw.weight2,
                            weight3 = bw.weight3
                        };
                        convertedCount++;
                    }
                }
            }

            Debug.Log($"[PMXImportResult] Applied bone weight index offset: +{offset} ({convertedCount} vertices)");
        }

        /// <summary>
        /// ボーンのHierarchyParentIndexにオフセットを加算
        /// Appendモードで既存MeshContextがある場合に使用
        /// </summary>
        /// <param name="offset">加算するオフセット（既存MeshContext数）</param>
        public void ApplyBoneHierarchyOffset(int offset)
        {
            if (offset <= 0) return;

            int convertedCount = 0;
            foreach (var meshContext in MeshContexts)
            {
                if (meshContext == null) continue;

                // ボーンの親インデックスにオフセットを適用
                if (meshContext.Type == MeshType.Bone && meshContext.HierarchyParentIndex >= 0)
                {
                    meshContext.HierarchyParentIndex += offset;
                    if (meshContext.MeshObject != null)
                    {
                        meshContext.MeshObject.HierarchyParentIndex = meshContext.HierarchyParentIndex;
                    }
                    convertedCount++;
                }
            }

            Debug.Log($"[PMXImportResult] Applied bone hierarchy offset: +{offset} ({convertedCount} bones)");
        }
    }

    /// <summary>
    /// インポート統計情報
    /// </summary>
    public class PMXImportStats
    {
        public int MeshCount { get; set; }
        public int TotalVertices { get; set; }
        public int TotalFaces { get; set; }
        public int MaterialCount { get; set; }
        public int MaterialGroupCount { get; set; }
        public int BoneCount { get; set; }
        public int MorphCount { get; set; }
    }

    /// <summary>
    /// 材質グループ情報（メッシュ/モーフ分割で共有）
    /// </summary>
    public class MaterialGroupInfo
    {
        /// <summary>グループに含まれる材質名リスト</summary>
        public List<string> MaterialNames { get; set; } = new List<string>();

        /// <summary>グループが使用するPMX頂点インデックス</summary>
        public HashSet<int> UsedVertexIndices { get; set; } = new HashSet<int>();

        /// <summary>PMX頂点インデックス → ローカル頂点インデックス</summary>
        public Dictionary<int, int> PmxToLocalIndex { get; set; } = new Dictionary<int, int>();

        /// <summary>result.MeshContexts 内のインデックス</summary>
        public int MeshContextIndex { get; set; } = -1;

        /// <summary>グループ名（メッシュ名）</summary>
        public string Name { get; set; }
    }

    /// <summary>
    /// PMXインポーター
    /// </summary>
    public static class PMXImporter
    {
        // ================================================================
        // パブリックAPI
        // ================================================================

        /// <summary>
        /// ファイルからインポート
        /// </summary>
        public static PMXImportResult ImportFile(string filePath, PMXImportSettings settings = null)
        {
            var result = new PMXImportResult();
            settings = settings ?? new PMXImportSettings();

            try
            {
                // 拡張子で判定してパース
                PMXDocument document;
                string ext = Path.GetExtension(filePath).ToLower();
                if (ext == ".pmx")
                {
                    // バイナリPMX
                    document = PMXReader.Load(filePath);
                }
                else
                {
                    // CSV
                    document = PMXCSVParser.ParseFile(filePath);
                }
                result.Document = document;

                // 変換
                ConvertDocument(document, settings, result);

                result.Success = true;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
                Debug.LogError($"[PMXImporter] Failed to import: {ex.Message}\n{ex.StackTrace}");
            }

            return result;
        }

        /// <summary>
        /// 文字列からインポート
        /// </summary>
        public static PMXImportResult ImportFromString(string content, PMXImportSettings settings = null)
        {
            var result = new PMXImportResult();
            settings = settings ?? new PMXImportSettings();

            try
            {
                var document = PMXCSVParser.Parse(content);
                result.Document = document;
                ConvertDocument(document, settings, result);
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
                Debug.LogError($"[PMXImporter] Failed to import: {ex.Message}");
            }

            return result;
        }

        /// <summary>
        /// PMXDocumentからインポート
        /// </summary>
        public static PMXImportResult Import(PMXDocument document, PMXImportSettings settings = null)
        {
            var result = new PMXImportResult();
            settings = settings ?? new PMXImportSettings();
            result.Document = document;

            try
            {
                ConvertDocument(document, settings, result);
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.ErrorMessage = ex.Message;
            }

            return result;
        }

        // ================================================================
        // 変換処理
        // ================================================================

        private static void ConvertDocument(PMXDocument document, PMXImportSettings settings, PMXImportResult result)
        {
            // 統計情報
            result.Stats.TotalVertices = document.Vertices.Count;
            result.Stats.TotalFaces = document.Faces.Count;
            result.Stats.MaterialCount = document.Materials.Count;
            result.Stats.BoneCount = document.Bones.Count;
            result.Stats.MorphCount = document.Morphs.Count;

            //Debug.Log($"[PMXImporter] ImportTarget: {settings.ImportTarget}");

            // マテリアルをUnityマテリアルに変換（Mesh読み込み時のみ）
            if (settings.ShouldImportMesh && settings.ImportMaterials)
            {
                string baseDir = GetBaseDirectory(document.FilePath);
                foreach (var pmxMat in document.Materials)
                {
                    var mat = ConvertMaterial(pmxMat, document, settings);
                    var matRef = new MaterialReference(mat);

                    // ソーステクスチャパスを絶対パスで設定
                    if (!string.IsNullOrEmpty(pmxMat.TexturePath))
                        matRef.Data.SourceTexturePath = ResolveTextureFullPath(pmxMat.TexturePath, baseDir);

                    // 両面描画フラグを CullMode に反映（DrawMeshes での動的カリング制御に使用）
                    if ((pmxMat.DrawFlags & 0x01) != 0)
                        matRef.Data.CullMode = Poly_Ling.Materials.CullModeType.Off;

                    result.MaterialReferences.Add(matRef);
                }
                //Debug.Log($"[PMXImporter] Imported {result.MaterialCount} materials");
            }

            // ボーンをインポート（メッシュより先に追加）
            if (settings.ShouldImportBones && document.Bones.Count > 0)
            {
                ConvertBones(document, settings, result);
                //Debug.Log($"[PMXImporter] Imported {document.Bones.Count} bones");
            }

            // ボーン数を記録（メッシュのインデックス計算用）
            int boneContextCount = result.MeshContexts.Count;

            // メッシュをインポート
            if (settings.ShouldImportMesh && document.Faces.Count > 0)
            {
                // 材質名から面リストへのマッピング
                var materialToFaces = new Dictionary<string, List<PMXFace>>();
                foreach (var face in document.Faces)
                {
                    if (!materialToFaces.ContainsKey(face.MaterialName))
                        materialToFaces[face.MaterialName] = new List<PMXFace>();
                    materialToFaces[face.MaterialName].Add(face);
                }

                // 材質名から使用頂点インデックスへのマッピング
                var materialToVertices = new Dictionary<string, HashSet<int>>();
                foreach (var kvp in materialToFaces)
                {
                    var vertexSet = new HashSet<int>();
                    foreach (var face in kvp.Value)
                    {
                        vertexSet.Add(face.VertexIndex1);
                        vertexSet.Add(face.VertexIndex2);
                        vertexSet.Add(face.VertexIndex3);
                    }
                    materialToVertices[kvp.Key] = vertexSet;
                }

                // PMX追加仕様：ObjectNameでグループ化
                var objectGroups = PMX.PMXHelper.BuildObjectGroups(document);

                // ObjectName未設定のグループ同士で共有頂点によるマージを適用
                objectGroups = MergeGroupsBySharedVertices(document, objectGroups, materialToVertices);

                result.Stats.MaterialGroupCount = objectGroups.Count;

                //Debug.Log($"[PMXImporter] {materialToFaces.Count} materials grouped into {objectGroups.Count} meshes by ObjectName");

                // デバッグ: 各グループの内容を出力
                for (int g = 0; g < objectGroups.Count && g < 5; g++)
                {
                    var grp = objectGroups[g];
                    var matNames = string.Join(", ", grp.Materials.ConvertAll(m => m.MaterialName));
                    //Debug.Log($"[PMXImporter] ObjectGroup[{g}] '{grp.ObjectName}' contains {grp.Materials.Count} materials: [{matNames}]");
                }

                // 各ObjectGroupをMeshContextに変換
                int meshIndex = 0;
                foreach (var objectGroup in objectGroups)
                {
                    // ObjectGroupから材質名リストを取得
                    var materialNames = objectGroup.Materials.ConvertAll(m => m.MaterialName);

                    // MaterialGroupInfo を構築
                    var groupInfo = BuildMaterialGroupInfo(materialNames, materialToFaces, meshIndex);
                    groupInfo.MeshContextIndex = boneContextCount + meshIndex;

                    var meshContext = ConvertMaterialGroup(
                        document,
                        materialNames,
                        materialToFaces,
                        result.Materials,
                        settings,
                        meshIndex
                    );

                    if (meshContext != null)
                    {
                        // ObjectNameをMeshContext名に設定
                        meshContext.Name = objectGroup.ObjectName;
                        // Memo欄のIsMirrorフラグを記録
                        meshContext.IsMirrorFromMemo = objectGroup.IsBakedMirror;
                        // Memo欄のdepthを記録
                        meshContext.Depth = objectGroup.Depth;
                        groupInfo.Name = meshContext.Name;
                        result.MeshContexts.Add(meshContext);
                        result.MaterialGroupInfos.Add(groupInfo);
                        meshIndex++;
                    }
                }

                result.Stats.MeshCount = result.MeshContexts.Count - boneContextCount;

                // depthからParentIndexを計算
                if (result.Stats.MeshCount > 0)
                {
                    var meshOnly = result.MeshContexts.Skip(boneContextCount).ToList();
                    PMXHelper.CalcParentIndicesFromDepth(meshOnly, boneContextCount);
                }
            }

            // Tポーズ変換（メッシュ作成後に実行）
            if (settings.ConvertToTPose && settings.ShouldImportBones && document.Bones.Count > 0)
            {
                // ボーン名からインデックスへのマッピングを再構築
                var boneNameToIndex = new Dictionary<string, int>();
                for (int i = 0; i < document.Bones.Count; i++)
                {
                    boneNameToIndex[document.Bones[i].Name] = i;
                }

                ConvertToTPose(result.MeshContexts, document, boneNameToIndex, settings);
                //Debug.Log($"[PMXImporter] Converted to T-Pose");
            }

            // 剛体をインポート（Type=RigidBody の空MeshObject + RigidBodyData）
            // ジョイントの剛体参照解決のため、剛体コンテキストの開始indexを記録する。
            int rigidBodyContextBase = -1;
            if (settings.ShouldImportBodies && document.RigidBodies.Count > 0)
            {
                rigidBodyContextBase = result.MeshContexts.Count;
                ConvertRigidBodies(document, settings, result);
            }

            // ジョイントをインポート（Type=RigidBodyJoint の空MeshObject + JointData）
            if (settings.ShouldImportJoints && document.Joints.Count > 0)
            {
                ConvertJoints(document, settings, result, rigidBodyContextBase);
            }

            // モーフをインポート
            if (settings.ShouldImportMorphs && document.Morphs.Count > 0)
            {
                ConvertMorphs(document, settings, result);
                //Debug.Log($"[PMXImporter] Imported {result.MorphExpressions.Count} morph sets");
            }

            // PolyLingメタモーフを適用（ShouldImportMorphsに関わらず常に実行）
            ApplyPolyLingMetaMorphs(document, result);

            // フェースメタ (.plmface.csv) が存在すれば適用
            if (!string.IsNullOrEmpty(document.FilePath))
            {
                var faceMeta = PMXFaceMetaReader.Load(document.FilePath);
                if (faceMeta != null)
                    PMXFaceMetaReader.Apply(faceMeta, result.MeshContexts);
            }

            // ミラーペア検出・構築（常に実行）
            DetectAndBuildMirrorPairs(result, boneContextCount, settings);
        }

        // ================================================================
        // ミラーペア検出・構築（名前末尾+ から自動検出）
        // ================================================================

        /// <summary>
        /// ミラーメッシュを検出し、設定に応じてMirrorPairまたはBakedMirrorとして構成する。
        /// 
        /// DetectNamedMirror=false: Memo欄IsMirrorフラグのあるメッシュのみミラーとして検出
        /// DetectNamedMirror=true: Memo欄に加え、名前末尾「+」のメッシュもミラーとして検出
        /// 
        /// BakeMirror=false: MirrorPairを構築（Real↔Mirror同期）
        /// BakeMirror=true: ベイクドミラー（独立メッシュ、MeshType.BakedMirror）
        /// </summary>
        private static void DetectAndBuildMirrorPairs(PMXImportResult result, int boneContextCount, PMXImportSettings settings)
        {
            var meshContexts = result.MeshContexts;

            // メッシュ名→インデックスのマッピング（ボーン以降のメッシュのみ）
            var nameToIndex = new Dictionary<string, int>();
            for (int i = boneContextCount; i < meshContexts.Count; i++)
            {
                var ctx = meshContexts[i];
                if (ctx == null || ctx.Type != MeshType.Mesh) continue;
                if (!nameToIndex.ContainsKey(ctx.Name))
                    nameToIndex[ctx.Name] = i;
            }

            int pairCount = 0;
            int bakedCount = 0;
            for (int i = boneContextCount; i < meshContexts.Count; i++)
            {
                var ctx = meshContexts[i];
                if (ctx == null || ctx.Type != MeshType.Mesh) continue;
                if (!ctx.Name.EndsWith("+")) continue;

                // DetectNamedMirror=false: Memo欄IsMirrorのみ対象
                // DetectNamedMirror=true: Memo欄 + 名前末尾「+」も対象
                if (!settings.DetectNamedMirror && !ctx.IsMirrorFromMemo)
                    continue;

                string sourceName = ctx.Name.Substring(0, ctx.Name.Length - 1);
                if (!nameToIndex.TryGetValue(sourceName, out int sourceIndex))
                    continue;

                var realCtx = meshContexts[sourceIndex];
                var mirrorCtx = ctx;

                if (settings.BakeMirror)
                {
                    // ベイクドミラー: 独立メッシュとして扱う
                    mirrorCtx.Type = MeshType.BakedMirror;
                    mirrorCtx.BakedMirrorSourceIndex = sourceIndex;
                    realCtx.HasBakedMirrorChild = true;
                    bakedCount++;
                    //Debug.Log($"[PMXImporter] BakedMirror: '{sourceName}' → '{ctx.Name}'");
                }
                else
                {
                    // MirrorPairを構築
                    var pair = new MirrorPair
                    {
                        Real = realCtx,
                        Mirror = mirrorCtx,
                        Axis = Poly_Ling.Symmetry.SymmetryAxis.X
                    };

                    bool success = pair.Build();

                    if (success)
                    {
                        // 実体側にミラー情報を設定
                        realCtx.MirrorType = 1;    // 左右対称
                        realCtx.MirrorAxis = 1;    // X軸

                        // ミラー側: サーフェス描画のみ（頂点・辺・ヒットテスト対象外）
                        mirrorCtx.Type = MeshType.MirrorSide;

                        result.MirrorPairs.Add(pair);
                        pairCount++;
                        //Debug.Log($"[PMXImporter] MirrorPair built: '{sourceName}' ↔ '{ctx.Name}'\n{pair.BuildLog}");
                    }
                    else
                    {
                        Debug.LogWarning($"[PMXImporter] MirrorPair build failed: '{sourceName}' ↔ '{ctx.Name}'\n{pair.BuildLog}");
                    }
                }
            }

            if (pairCount > 0)
            {
                //Debug.Log($"[PMXImporter] Built {pairCount} mirror pairs");
            }
            if (bakedCount > 0)
            {
                //Debug.Log($"[PMXImporter] Created {bakedCount} baked mirrors");
            }
        }

        /// <summary>
        /// 旧メソッド（後方互換・参照用に残す）
        /// 名前末尾が+のメッシュをBakedMirrorとして設定
        /// </summary>
        [System.Obsolete("Use DetectAndBuildMirrorPairs instead")]
        public static void DetectNamedMirrors(List<MeshContext> meshContexts, int boneContextCount)
        {
            // メッシュ名→インデックスのマッピング（ボーン以降のメッシュのみ）
            var nameToIndex = new Dictionary<string, int>();
            for (int i = boneContextCount; i < meshContexts.Count; i++)
            {
                var ctx = meshContexts[i];
                if (ctx == null || ctx.Type != MeshType.Mesh) continue;
                if (!nameToIndex.ContainsKey(ctx.Name))
                    nameToIndex[ctx.Name] = i;
            }

            int mirrorCount = 0;
            for (int i = boneContextCount; i < meshContexts.Count; i++)
            {
                var ctx = meshContexts[i];
                if (ctx == null || ctx.Type != MeshType.Mesh) continue;
                if (!ctx.Name.EndsWith("+")) continue;

                string sourceName = ctx.Name.Substring(0, ctx.Name.Length - 1);
                if (nameToIndex.TryGetValue(sourceName, out int sourceIndex))
                {
                    ctx.MeshObject.Type = MeshType.BakedMirror;
                    ctx.Type = MeshType.BakedMirror;
                    ctx.BakedMirrorSourceIndex = sourceIndex;
                    meshContexts[sourceIndex].HasBakedMirrorChild = true;
                    meshContexts[sourceIndex].MirrorType = 1;  // 左右対称
                    meshContexts[sourceIndex].MirrorAxis = 1;  // X軸
                    mirrorCount++;
                    //Debug.Log($"[PMXImporter] Named mirror: '{ctx.Name}' → source '{sourceName}' (index {sourceIndex})");
                }
            }

            if (mirrorCount > 0)
            {
                //Debug.Log($"[PMXImporter] Detected {mirrorCount} named mirror meshes (+)");
            }
        }

        // ================================================================
        // ボーン変換
        // ================================================================

        /// <summary>
        /// PMXボーンをMeshContext（Type=Bone）に変換
        /// </summary>
        private static void ConvertBones(PMXDocument document, PMXImportSettings settings, PMXImportResult result)
        {
            // ボーン名からインデックスへのマッピング（親子関係解決用）
            var boneNameToIndex = new Dictionary<string, int>();
            for (int i = 0; i < document.Bones.Count; i++)
            {
                boneNameToIndex[document.Bones[i].Name] = i;
            }

            // デバッグ: 主要ボーンのインデックスを出力
            string[] checkBones = { "頭", "首", "上半身", "下半身", "左腕", "右腕" };
            foreach (var boneName in checkBones)
            {
                int idx = document.GetBoneIndex(boneName);
                //if (idx >= 0)
                    //Debug.Log($"[PMXImporter] BoneIndex: '{boneName}' = {idx}");
            }

            // ボーンのワールド位置を変換済みで保持（ローカル座標計算用）
            var boneWorldPositions = new Vector3[document.Bones.Count];
            for (int i = 0; i < document.Bones.Count; i++)
            {
                boneWorldPositions[i] = ConvertPosition(document.Bones[i].Position, settings);
            }

            // ボーンのレスト回転は恒等とする（ローカル軸を合成しない）
            // ----------------------------------------------------------------
            // ■ 経緯
            //   旧実装は CalculateBoneModelRotation で、ローカル軸フラグ(0x0800)の
            //   有無に関わらず全ボーンに「接続先への方向」から局所軸を合成していた。
            //   PMX の実データにローカル軸はほぼ入っておらず、入っていても操作ハンドルの
            //   都合によるもので実体を伴わない。合成した軸は AxisFlipOps.Basis の
            //   共役変換と組み合わさって規約が食い違い、
            //     - ローカル X が骨方向の真逆（実測 180.00 度）
            //     - Unity クリップの dof→軸 対応が成立しない
            //   といった不具合の温床になっていた。
            //
            // ■ 現在の規約
            //   ボーンの局所座標系 ＝ モデル空間。全ボーン共通。
            //   BoneTransform.Rotation も恒等になり、BonePoseData のデルタは
            //   モデル空間の量として素直に解釈できる。
            //   レスト表示は BindPose = worldMatrix.inverse で相殺されるため不変。
            //
            // ■ 捨てた情報
            //   ローカル軸フラグ(0x0800)由来の軸のみ。
            //   付与親(GrantParentIndex/GrantRate)・固定軸・IK 角度制限は別系統で、
            //   ここで捨てているわけではない（付与親と固定軸は未実装）。
            var boneModelRotations = new Quaternion[document.Bones.Count];
            for (int i = 0; i < document.Bones.Count; i++)
            {
                boneModelRotations[i] = Quaternion.identity;
            }

            // 各ボーンをMeshContextに変換
            for (int i = 0; i < document.Bones.Count; i++)
            {
                var pmxBone = document.Bones[i];
                var meshContext = ConvertBone(
                    pmxBone,
                    i,
                    boneNameToIndex,
                    boneWorldPositions,
                    boneModelRotations,
                    settings
                );
                result.MeshContexts.Add(meshContext);

                // デバッグ：親子関係と回転を確認
                bool hasLocalAxis = (pmxBone.Flags & 0x0800) != 0;
                //Debug.Log($"[PMXImporter] Bone[{i}] '{pmxBone.Name}' -> Parent='{pmxBone.ParentBoneName}' -> HierarchyParentIndex={meshContext.HierarchyParentIndex}, Flags=0x{pmxBone.Flags:X4}, HasLocalAxis={hasLocalAxis}");
            }

            //Debug.Log($"[PMXImporter] Imported {document.Bones.Count} bones");

            // CCDIKSolver用にPMXワールド位置を保存
            result.BoneWorldPositions = boneWorldPositions;
        }

        // ================================================================
        // ローカル軸の合成は廃止した
        // ----------------------------------------------------------------
        //   削除したメソッド:
        //     CalculateBoneModelRotation / CalculateDefaultLocalAxisX / CreateRotationFromAxes
        //   BoneModelRotation は恒等固定。復活させないこと。
        //   同等の重複実装が PmxBoneBuilder.cs / PmxBoneImporter.cs にもあったが、
        //   いずれも外部から未参照のためファイルごと削除した。
        // ================================================================

        // ================================================================
        // Tポーズ変換
        // ================================================================

        /// <summary>
        /// AポーズをTポーズに変換（PMXインポート時専用）
        /// GPU処理を使用してスキニング変換を適用
        /// </summary>
        private static void ConvertToTPose(
            List<MeshContext> meshContexts,
            PMXDocument document,
            Dictionary<string, int> boneNameToIndex,
            PMXImportSettings settings)
        {
            // 一時的なHumanoidBoneMappingを作成してボーン名から自動マッピング
            var tempMapping = new HumanoidBoneMapping();
            var boneNames = new List<string>();
            for (int i = 0; i < meshContexts.Count; i++)
                boneNames.Add(meshContexts[i]?.Name ?? "");
            tempMapping.AutoMapFromEmbeddedCSV(boneNames);

            TPoseConverter.ConvertToTPose(meshContexts, tempMapping);
        }

        /// <summary>
        /// AポーズをTポーズに変換（MeshContextのみ使用、PMXDocument不要）
        /// MQOImporter等から呼び出し可能
        /// </summary>
        public static void ConvertToTPoseFromMeshContexts(List<MeshContext> meshContexts)
        {
            TPoseConverter.ConvertToTPoseByBoneNames(meshContexts);
        }

        /// <summary>
        /// GPU処理を使用してスキンドメッシュの頂点座標をベイク
        /// </summary>
        public static void BakeSkinnedVertices(List<MeshContext> meshContexts)
        {
            TPoseConverter.BakeSkinnedVertices(meshContexts);
        }

        /// <summary>
        /// 全ボーンのワールド変換行列を計算
        /// </summary>
        public static Dictionary<int, Matrix4x4> CalculateWorldMatrices(List<MeshContext> meshContexts)
        {
            return ModelContext.CalculateWorldMatrices(meshContexts);
        }

        /// <summary>
        /// 単一のPMXボーンをMeshContextに変換
        /// </summary>
        private static MeshContext ConvertBone(
            PMXBone pmxBone,
            int boneIndex,
            Dictionary<string, int> boneNameToIndex,
            Vector3[] boneWorldPositions,
            Quaternion[] boneModelRotations,
            PMXImportSettings settings)
        {
            // 親ボーンインデックスを解決
            int parentIndex = -1;
            if (!string.IsNullOrEmpty(pmxBone.ParentBoneName) &&
                boneNameToIndex.TryGetValue(pmxBone.ParentBoneName, out int pIdx))
            {
                parentIndex = pIdx;
            }

            // ワールド位置を取得
            Vector3 worldPosition = boneWorldPositions[boneIndex];

            // モデル空間回転を取得
            Quaternion modelRotation = boneModelRotations[boneIndex];

            // ローカル位置・ローカル回転を計算
            // ローカル回転 = Inverse(親ワールド回転) * 自身ワールド回転
            // ローカル位置 = Inverse(親ワールド回転) * (自身ワールド位置 - 親ワールド位置)
            Vector3 localPosition;
            Quaternion localRotation;
            if (parentIndex >= 0)
            {
                Quaternion parentModelRotation = boneModelRotations[parentIndex];
                Vector3 parentWorldPos = boneWorldPositions[parentIndex];
                Quaternion invParentRot = Quaternion.Inverse(parentModelRotation);
                localPosition = invParentRot * (worldPosition - parentWorldPos);
                localRotation = invParentRot * modelRotation;
            }
            else
            {
                localPosition = worldPosition;
                localRotation = modelRotation;
            }

            // オイラー角に変換
            Vector3 localRotationEuler = localRotation.eulerAngles;

            // 空のMeshObjectを作成（ボーンは頂点/面を持たない）
            var meshObject = new MeshObject(pmxBone.Name)
            {
                Type = MeshType.Bone,
                HierarchyParentIndex = parentIndex
            };

            // BoneTransformを設定（ローカル座標・ローカル回転）
            var boneTransform = new Poly_Ling.Data.BoneTransform
            {
                Position = localPosition,
                Rotation = localRotationEuler,
                Scale = Vector3.one,
                UseLocalTransform = true,
                HasBoneTransform = true  // ★スキンドメッシュとして出力
            };
            meshObject.BoneTransform = boneTransform;

            // BindPoseを設定（ワールド位置+回転の逆行列）
            Matrix4x4 worldMatrix = Matrix4x4.TRS(worldPosition, modelRotation, Vector3.one);
            Matrix4x4 bindPose = worldMatrix.inverse;

            // MeshContext作成（★MQOと同様に全プロパティを設定）
            var meshContext = new MeshContext
            {
                MeshObject = meshObject,
                Name = pmxBone.Name,  // ★名前を設定
                Type = MeshType.Bone,
                IsVisible = true,
                BindPose = bindPose,
                BoneTransform = boneTransform,  // ★BoneTransformを設定
                BoneModelRotation = modelRotation  // ローカル軸のワールド空間回転（VMDApplierのR^-1*Q*R変換に使用）
            };

            // ★MeshContextにもHierarchyParentIndexを設定（重要！）
            meshContext.HierarchyParentIndex = parentIndex;

            // ★BonePoseDataを生成（IsActive=trueのみ。PreBindPoseはゼロのまま）
            // BonePoseDataはBoneTransformへのデルタとして設計されているため、
            // PreBindPoseに値を入れるとBoneTransformと二重適用になる。
            meshContext.BonePoseData = new Data.BonePoseData { IsActive = true };

            // IKデータを設定
            const int FLAG_IK = 0x0020;
            if ((pmxBone.Flags & FLAG_IK) != 0 && pmxBone.IKLinks != null && pmxBone.IKLinks.Count > 0)
            {
                meshContext.IsIK = true;
                // IKターゲット（エフェクタ）のインデックス解決
                if (!string.IsNullOrEmpty(pmxBone.IKTargetBoneName) &&
                    boneNameToIndex.TryGetValue(pmxBone.IKTargetBoneName, out int ikTargetIdx))
                {
                    meshContext.IKTargetIndex = ikTargetIdx;
                }
                else if (pmxBone.IKTargetIndex >= 0)
                {
                    meshContext.IKTargetIndex = pmxBone.IKTargetIndex;
                }
                meshContext.IKLoopCount = pmxBone.IKLoopCount;
                meshContext.IKLimitAngle = pmxBone.IKLimitAngle;

                meshContext.IKLinks = new List<IKLinkInfo>();
                foreach (var link in pmxBone.IKLinks)
                {
                    int linkIdx = -1;
                    if (!string.IsNullOrEmpty(link.BoneName) &&
                        boneNameToIndex.TryGetValue(link.BoneName, out int nameIdx))
                    {
                        linkIdx = nameIdx;
                    }
                    else if (link.BoneIndex >= 0)
                    {
                        linkIdx = link.BoneIndex;
                    }

                    // 角度制限の座標系変換。軸反転のみ（det(S) < 0 のとき min/max を入れ替え）。
                    // ボーンの局所軸は恒等になったため、この値はモデル空間の角度制限として
                    // 扱う。軸規約の置換は行わない。
                    Vector3 limMin = link.LimitMin;
                    Vector3 limMax = link.LimitMax;
                    AxisFlipOps.AngleLimits(settings.Flip, ref limMin, ref limMax);

                    meshContext.IKLinks.Add(new IKLinkInfo
                    {
                        BoneIndex = linkIdx,
                        HasLimit = link.HasLimit,
                        LimitMin = limMin,
                        LimitMax = limMax
                    });
                }

                //Debug.Log($"[PMXImporter] IK Bone '{pmxBone.Name}': target={meshContext.IKTargetIndex}, loops={meshContext.IKLoopCount}, links={meshContext.IKLinks.Count}");
                foreach (var lnk in meshContext.IKLinks)
                {
                    //Debug.Log($"[PMXImporter]   Link: resolvedIdx={lnk.BoneIndex} hasLimit={lnk.HasLimit} min={lnk.LimitMin} max={lnk.LimitMax}");
                }
                // PMXのIKLinkの元データも出力
                foreach (var link in pmxBone.IKLinks)
                {
                    //Debug.Log($"[PMXImporter]   RawLink: BoneIndex={link.BoneIndex} BoneName='{link.BoneName}'");
                }
            }

            return meshContext;
        }

        /// <summary>
        /// 頂点を共有する材質をグループ化
        /// Union-Findアルゴリズムを使用
        /// </summary>
        private static List<List<string>> GroupMaterialsBySharedVertices(
            Dictionary<string, HashSet<int>> materialToVertices)
        {
            var materialNames = materialToVertices.Keys.ToList();
            int n = materialNames.Count;

            // Union-Find用の親配列
            int[] parent = new int[n];
            for (int i = 0; i < n; i++)
                parent[i] = i;

            // Find関数（経路圧縮付き）
            int Find(int x)
            {
                if (parent[x] != x)
                    parent[x] = Find(parent[x]);
                return parent[x];
            }

            // Union関数
            void Union(int x, int y)
            {
                int px = Find(x);
                int py = Find(y);
                if (px != py)
                    parent[px] = py;
            }

            // 各材質の頂点インデックス範囲（min, max）を算出
            var ranges = new (int min, int max)[n];
            for (int i = 0; i < n; i++)
            {
                var verts = materialToVertices[materialNames[i]];
                int min = int.MaxValue, max = int.MinValue;
                foreach (int vIdx in verts)
                {
                    if (vIdx < min) min = vIdx;
                    if (vIdx > max) max = vIdx;
                }
                ranges[i] = (min, max);
            }

            // 頂点インデックス範囲がオーバーラップする材質をUnion
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (ranges[i].min <= ranges[j].max && ranges[j].min <= ranges[i].max)
                    {
                        Union(i, j);
                    }
                }
            }

            // グループを収集
            var groups = new Dictionary<int, List<string>>();
            for (int i = 0; i < n; i++)
            {
                int root = Find(i);
                if (!groups.ContainsKey(root))
                    groups[root] = new List<string>();
                groups[root].Add(materialNames[i]);
            }

            return groups.Values.ToList();
        }

        /// <summary>
        /// 共有頂点を持つグループをマージ（ObjectName未設定のグループのみ対象）
        /// </summary>
        private static List<ObjectGroup> MergeGroupsBySharedVertices(
            PMXDocument document,
            List<ObjectGroup> objectGroups,
            Dictionary<string, HashSet<int>> materialToVertices)
        {
            //Debug.Log($"[PMXImporter] MergeGroupsBySharedVertices: called with {objectGroups.Count} groups");

            // ObjectName未設定の非ミラーグループを特定
            var fallbackIndices = new List<int>();
            var fallbackGroups = new List<ObjectGroup>();

            for (int i = 0; i < objectGroups.Count; i++)
            {
                var group = objectGroups[i];
                if (group.IsBakedMirror)
                {
                    Debug.Log($"[PMXImporter] Skipping group '{group.ObjectName}' (IsBakedMirror)");
                    continue;
                }

                // Memo欄にObjectNameが明示的に設定されているか確認
                bool hasExplicitObjectName = group.Materials.Any(m =>
                {
                    var mat = document.Materials[m.MaterialIndex];
                    var (objName, _, _) = PMXHelper.ParseMaterialMemo(mat.Memo);
                    return !string.IsNullOrEmpty(objName);
                });

                if (!hasExplicitObjectName)
                {
                    fallbackIndices.Add(i);
                    fallbackGroups.Add(group);
                }
                else
                {
                    //Debug.Log($"[PMXImporter] Skipping group '{group.ObjectName}' (has explicit ObjectName in Memo)");
                }
            }

            // 対象グループが1以下ならマージ不要
            if (fallbackGroups.Count <= 1)
            {
               // Debug.Log($"[PMXImporter] MergeGroupsBySharedVertices: early return (fallbackGroups.Count={fallbackGroups.Count}, total objectGroups={objectGroups.Count})");
                return objectGroups;
            }

            //Debug.Log($"[PMXImporter] MergeGroupsBySharedVertices: {fallbackGroups.Count} groups without ObjectName");
            foreach (var g in fallbackGroups)
            {
                var mats = string.Join(", ", g.Materials.ConvertAll(m => m.MaterialName));
               // Debug.Log($"  Group '{g.ObjectName}' IsBakedMirror={g.IsBakedMirror}: [{mats}]");
            }

            // フォールバック材質の頂点セットを収集
            var fallbackMatToVerts = new Dictionary<string, HashSet<int>>();
            foreach (var group in fallbackGroups)
            {
                foreach (var matInfo in group.Materials)
                {
                    if (materialToVertices.TryGetValue(matInfo.MaterialName, out var verts))
                    {
                        fallbackMatToVerts[matInfo.MaterialName] = verts;
                       // Debug.Log($"[PMXImporter] Material '{matInfo.MaterialName}': {verts.Count} vertices");
                    }
                    else
                    {
                       // Debug.LogWarning($"[PMXImporter] Material '{matInfo.MaterialName}' not found in materialToVertices!");
                    }
                }
            }

            // Union-Findで共有頂点を持つ材質をグループ化
            var mergedMaterialGroups = GroupMaterialsBySharedVertices(fallbackMatToVerts);

            //Debug.Log($"[PMXImporter] Union-Find result: {mergedMaterialGroups.Count} groups");
            foreach (var mg in mergedMaterialGroups)
            {
                //Debug.Log($"  Merged group: [{string.Join(", ", mg)}]");
            }

            // マージが発生したか確認
            if (!mergedMaterialGroups.Any(g => g.Count > 1))
                return objectGroups;

            // 強い警告を出力
            foreach (var mergedGroup in mergedMaterialGroups)
            {
                if (mergedGroup.Count > 1)
                {
                    Debug.LogWarning(
                        $"[PMXImporter] ⚠⚠⚠ 共有頂点により材質がマージされました ⚠⚠⚠\n" +
                        $"  材質: [{string.Join(", ", mergedGroup)}]\n" +
                        $"  これらの材質は頂点を共有しているため、1つのMeshContextに格納されます。\n" +
                        $"  意図しない場合は、PMXエディタで材質Memo欄にObjectNameを設定してください。");
                }
            }

            // 材質名→マージグループインデックスのマッピング
            var matToMergedIdx = new Dictionary<string, int>();
            for (int gi = 0; gi < mergedMaterialGroups.Count; gi++)
            {
                foreach (var matName in mergedMaterialGroups[gi])
                {
                    matToMergedIdx[matName] = gi;
                }
            }

            // マージされたObjectGroupを生成
            var newMergedGroups = new ObjectGroup[mergedMaterialGroups.Count];
            for (int gi = 0; gi < mergedMaterialGroups.Count; gi++)
            {
                var matNames = mergedMaterialGroups[gi];
                if (matNames.Count == 1)
                {
                    // マージなし: 元のグループをそのまま使用
                    newMergedGroups[gi] = fallbackGroups.First(
                        g => g.Materials.Any(m => m.MaterialName == matNames[0]));
                }
                else
                {
                    // マージ: 新しいObjectGroupを作成
                    var newGroup = new ObjectGroup
                    {
                        ObjectName = matNames[0],
                        IsBakedMirror = false
                    };

                    // 材質を元の順序（MaterialIndex昇順）で追加
                    var allMatInfos = new List<MaterialObjectInfo>();
                    foreach (var matName in matNames)
                    {
                        var srcGroup = fallbackGroups.First(
                            g => g.Materials.Any(m => m.MaterialName == matName));
                        allMatInfos.Add(srcGroup.Materials.First(m => m.MaterialName == matName));
                    }
                    allMatInfos.Sort((a, b) => a.MaterialIndex.CompareTo(b.MaterialIndex));

                    foreach (var matInfo in allMatInfos)
                    {
                        newGroup.Materials.Add(matInfo);
                    }

                    // 頂点インデックスを再収集
                    PMXHelper.CollectGroupVertices(document, newGroup);

                    newMergedGroups[gi] = newGroup;
                }
            }

            // objectGroupsリストを再構築（元の順序を保持）
            var result = new List<ObjectGroup>();
            var processedMergeIndices = new HashSet<int>();

            for (int i = 0; i < objectGroups.Count; i++)
            {
                int fallbackPos = fallbackIndices.IndexOf(i);
                if (fallbackPos < 0)
                {
                    // フォールバックでないグループはそのまま
                    result.Add(objectGroups[i]);
                }
                else
                {
                    // フォールバックグループ → マージ結果に差し替え
                    var firstMatName = fallbackGroups[fallbackPos].Materials[0].MaterialName;
                    int mergedIdx = matToMergedIdx[firstMatName];

                    if (!processedMergeIndices.Contains(mergedIdx))
                    {
                        // このマージグループの最初の出現位置に挿入
                        result.Add(newMergedGroups[mergedIdx]);
                        processedMergeIndices.Add(mergedIdx);
                    }
                    // 以降の出現はスキップ（既にマージ済み）
                }
            }

            return result;
        }

        /// <summary>
        /// 材質グループをMeshContextに変換
        /// </summary>
        private static MeshContext ConvertMaterialGroup(
            PMXDocument document,
            List<string> materialNames,
            Dictionary<string, List<PMXFace>> materialToFaces,
            List<Material> unityMaterials,
            PMXImportSettings settings,
            int meshIndex)
        {
            // グループ内の全面を収集
            var allFaces = new List<PMXFace>();
            foreach (var matName in materialNames)
            {
                if (materialToFaces.TryGetValue(matName, out var faces))
                    allFaces.AddRange(faces);
            }

            // 使用する頂点インデックスを収集
            var usedVertexIndices = new HashSet<int>();
            foreach (var face in allFaces)
            {
                usedVertexIndices.Add(face.VertexIndex1);
                usedVertexIndices.Add(face.VertexIndex2);
                usedVertexIndices.Add(face.VertexIndex3);
            }

            // 元のインデックスから新しいインデックスへのマッピング
            var oldToNewIndex = new Dictionary<int, int>();
            var sortedIndices = usedVertexIndices.OrderBy(x => x).ToList();
            for (int i = 0; i < sortedIndices.Count; i++)
            {
                oldToNewIndex[sortedIndices[i]] = i;
            }

            // 材質名からグローバルインデックスへのマッピング（モデル全体での位置）
            var materialNameToGlobalIndex = new Dictionary<string, int>();
            for (int i = 0; i < materialNames.Count; i++)
            {
                int globalIndex = document.GetMaterialIndex(materialNames[i]);
                materialNameToGlobalIndex[materialNames[i]] = globalIndex >= 0 ? globalIndex : 0;
            }

            // MeshObjectを作成
            string meshName = materialNames.Count == 1
                ? materialNames[0]
                : $"Group_{meshIndex}_{materialNames[0]}";

            var meshObject = new MeshObject(meshName);
            meshObject.IsTriangulated = true;  // PMX は三角形化済み形式

            // 頂点を追加（スケールなしで追加し、法線計算後にスケール適用）
            int debugCount = 0;
            int multiWeightDebugCount = 0;
            foreach (int oldIdx in sortedIndices)
            {
                var pmxVert = document.Vertices[oldIdx];
                // スケールなしで頂点を作成（法線計算の精度確保のため）
                var vertex = ConvertVertexUnscaled(pmxVert, document, settings);
                meshObject.Vertices.Add(vertex);

                // デバッグ: BoneWeight情報を出力
                if (vertex.BoneWeight.HasValue)
                {
                    var bw = vertex.BoneWeight.Value;

                    // 最初の5頂点
                    if (meshIndex == 0 && debugCount < 5)
                    {
                        //Debug.Log($"[PMXImporter] Vertex[{oldIdx}] BoneWeight: " +
                        //          $"({bw.boneIndex0}:{bw.weight0:F2}, {bw.boneIndex1}:{bw.weight1:F2}, " +
                        //          $"{bw.boneIndex2}:{bw.weight2:F2}, {bw.boneIndex3}:{bw.weight3:F2})");
                        debugCount++;
                    }

                    // 複数ウェイトを持つ頂点（最初の3つ）
                    if (meshIndex == 0 && bw.weight1 > 0 && multiWeightDebugCount < 3)
                    {
                        //Debug.Log($"[PMXImporter] MultiWeight Vertex[{oldIdx}]: " +
                        //          $"({bw.boneIndex0}:{bw.weight0:F2}, {bw.boneIndex1}:{bw.weight1:F2}, " +
                        //          $"{bw.boneIndex2}:{bw.weight2:F2}, {bw.boneIndex3}:{bw.weight3:F2})");
                        multiWeightDebugCount++;
                    }
                }
            }

            // 面を追加
            foreach (var pmxFace in allFaces)
            {
                int newV1 = oldToNewIndex[pmxFace.VertexIndex1];
                int newV2 = oldToNewIndex[pmxFace.VertexIndex2];
                int newV3 = oldToNewIndex[pmxFace.VertexIndex3];

                // 材質インデックスを取得（グローバルインデックス）
                int materialIndex = materialNameToGlobalIndex.TryGetValue(pmxFace.MaterialName, out int idx)
                    ? idx
                    : 0;

                var face = new Face
                {
                    MaterialIndex = materialIndex
                };

                // 反転軸が奇数個（鏡映）のときだけ頂点順序を逆にする。
                // X・Z の両反転（Y軸180°回転）では巻き順を変えない。
                if (AxisFlipOps.ReverseWinding(settings.Flip))
                {
                    face.VertexIndices.Add(newV1);
                    face.VertexIndices.Add(newV3);
                    face.VertexIndices.Add(newV2);
                }
                else
                {
                    face.VertexIndices.Add(newV1);
                    face.VertexIndices.Add(newV2);
                    face.VertexIndices.Add(newV3);
                }

                // UVインデックス（頂点と同じ）
                for (int i = 0; i < 3; i++)
                {
                    face.UVIndices.Add(0);
                    face.NormalIndices.Add(0);
                }

                meshObject.Faces.Add(face);
            }

            // 法線を再計算（スケール適用前の座標で計算 → 精度問題回避）
            if (settings.RecalculateNormals)
            {
                meshObject.RecalculateSmoothNormals();
            }

            // スケールを適用（法線計算後）
            if (Mathf.Abs(settings.Scale - 1f) > 0.0001f)
            {
                foreach (var vertex in meshObject.Vertices)
                {
                    vertex.Position *= settings.Scale;
                }
            }

            // デバッグ: 最初のメッシュの法線を確認
            if (meshIndex == 0 && meshObject.Vertices.Count > 0)
            {
                int checkCount = Mathf.Min(5, meshObject.Vertices.Count);
                for (int vi = 0; vi < checkCount; vi++)
                {
                    var v = meshObject.Vertices[vi];
                    if (v.Normals.Count > 0)
                    {
                        var n = v.Normals[0];
                        //Debug.Log($"[PMXImporter] Normal[{vi}]: ({n.x:F3}, {n.y:F3}, {n.z:F3})");
                    }
                }
            }

            // MeshContext作成
            var meshContext = new MeshContext
            {
                Name = meshName,
                MeshObject = meshObject
            };

            // PMX材質名リストを保存（空メッシュのエクスポート時に使用）
            meshContext.PMXMaterialNames = new List<string>(materialNames);

            // Unity Mesh生成
            // Face.MaterialIndexはグローバルインデックスなので、使用されている最大インデックス+1をサブメッシュ数とする
            int maxMatIndex = materialNameToGlobalIndex.Count > 0 ? materialNameToGlobalIndex.Values.Max() : 0;
            int subMeshCount = maxMatIndex + 1;
            meshContext.UnityMesh = meshObject.ToUnityMesh(subMeshCount);

            // デバッグ: UnityMeshの各サブメッシュの三角形数を確認
            if (meshIndex < 3)
            {
                var unityMesh = meshContext.UnityMesh;
                //Debug.Log($"[PMXImporter] Mesh '{meshName}' SubMeshCount={unityMesh.subMeshCount}, VertexCount={unityMesh.vertexCount}");
                for (int sm = 0; sm < Mathf.Min(unityMesh.subMeshCount, 10); sm++)
                {
                    int triCount = unityMesh.GetTriangles(sm).Length / 3;
                    //if (triCount > 0)
                        //Debug.Log($"[PMXImporter]   SubMesh[{sm}]: {triCount} triangles, Mat='{document.Materials[sm].Name}'");
                }
            }

            // マテリアルはインポート後に ReplaceMaterials 経由で ModelContext に設定される

            //Debug.Log($"[PMXImporter] Created mesh '{meshName}': V={meshObject.VertexCount}, F={meshObject.FaceCount}, " +
            //          $"LocalMat={materialNames.Count}, GlobalMatCount={document.Materials.Count}, " +
            //          $"MatIndices=[{string.Join(",", materialNameToGlobalIndex.Values)}]");

            return meshContext;
        }

        // ================================================================
        // 頂点変換
        // ================================================================

        /// <summary>
        /// 頂点変換（スケールなし - 法線計算用）
        /// </summary>
        private static Vertex ConvertVertexUnscaled(PMXVertex pmxVert, PMXDocument document, PMXImportSettings settings)
        {
            // 座標変換（スケールなし）
            Vector3 pos = ConvertPositionUnscaled(pmxVert.Position, settings);
            Vector3 normal = ConvertNormal(pmxVert.Normal, settings);
            Vector2 uv = ConvertUV(pmxVert.UV, settings);

            var vertex = new Vertex(pos, uv, normal);

            // BoneWeight設定
            if (pmxVert.BoneWeights != null && pmxVert.BoneWeights.Length > 0)
            {
                var boneWeight = new BoneWeight();

                for (int i = 0; i < pmxVert.BoneWeights.Length && i < 4; i++)
                {
                    var pmxBw = pmxVert.BoneWeights[i];
                    int boneIndex = document.GetBoneIndex(pmxBw.BoneName);
                    if (boneIndex < 0) boneIndex = 0;

                    switch (i)
                    {
                        case 0:
                            boneWeight.boneIndex0 = boneIndex;
                            boneWeight.weight0 = pmxBw.Weight;
                            break;
                        case 1:
                            boneWeight.boneIndex1 = boneIndex;
                            boneWeight.weight1 = pmxBw.Weight;
                            break;
                        case 2:
                            boneWeight.boneIndex2 = boneIndex;
                            boneWeight.weight2 = pmxBw.Weight;
                            break;
                        case 3:
                            boneWeight.boneIndex3 = boneIndex;
                            boneWeight.weight3 = pmxBw.Weight;
                            break;
                    }
                }

                vertex.BoneWeight = boneWeight;
            }

            return vertex;
        }

        /// <summary>
        /// 頂点変換（スケール適用あり）
        /// </summary>
        private static Vertex ConvertVertex(PMXVertex pmxVert, PMXDocument document, PMXImportSettings settings)
        {
            // 座標変換
            Vector3 pos = ConvertPosition(pmxVert.Position, settings);
            Vector3 normal = ConvertNormal(pmxVert.Normal, settings);
            Vector2 uv = ConvertUV(pmxVert.UV, settings);

            var vertex = new Vertex(pos, uv, normal);

            // BoneWeight設定
            if (pmxVert.BoneWeights != null && pmxVert.BoneWeights.Length > 0)
            {
                var boneWeight = new BoneWeight();

                for (int i = 0; i < pmxVert.BoneWeights.Length && i < 4; i++)
                {
                    var pmxBw = pmxVert.BoneWeights[i];
                    int boneIndex = document.GetBoneIndex(pmxBw.BoneName);
                    if (boneIndex < 0) boneIndex = 0;

                    switch (i)
                    {
                        case 0:
                            boneWeight.boneIndex0 = boneIndex;
                            boneWeight.weight0 = pmxBw.Weight;
                            break;
                        case 1:
                            boneWeight.boneIndex1 = boneIndex;
                            boneWeight.weight1 = pmxBw.Weight;
                            break;
                        case 2:
                            boneWeight.boneIndex2 = boneIndex;
                            boneWeight.weight2 = pmxBw.Weight;
                            break;
                        case 3:
                            boneWeight.boneIndex3 = boneIndex;
                            boneWeight.weight3 = pmxBw.Weight;
                            break;
                    }
                }

                vertex.BoneWeight = boneWeight;
            }

            return vertex;
        }

        // ================================================================
        // マテリアル変換
        // ================================================================

        private static Material ConvertMaterial(PMXMaterial pmxMat, PMXDocument document, PMXImportSettings settings)
        {
            Shader shader = FindBestShader();
            var material = new Material(shader);
            material.name = pmxMat.Name;

            // 両面描画フラグ（DrawFlags bit0 = 1 → 両面）
            bool doubleSide = (pmxMat.DrawFlags & 0x01) != 0;
            if (doubleSide && material.HasProperty("_Cull"))
                material.SetFloat("_Cull", 0f); // CullMode.Off

            // 拡散色を設定（アルファ値も含む）
            Color color = pmxMat.Diffuse;
            SetMaterialColor(material, color);

            // アルファ処理（4ケース分岐）
            bool hasLowOpacity = color.a < 1f - 0.001f;
            bool hasTexture = !string.IsNullOrEmpty(pmxMat.TexturePath);

            if (hasLowOpacity && hasTexture)
            {
                // ケース4: 材質不透明度 < 1.0 かつ テクスチャあり（競合）
                if (settings.AlphaConflict == AlphaConflictMode.PreferTransparent)
                {
                    // 半透明ブレンディング優先
                    SetMaterialTransparent(material);
                }
                else
                {
                    // テクスチャアルファ優先（AlphaClip）
                    SetMaterialAlphaClip(material, settings.AlphaCutoff);
                }
            }
            else if (hasLowOpacity)
            {
                // ケース1: 材質不透明度 < 1.0、テクスチャなし → Transparent
                SetMaterialTransparent(material);
            }
            else if (hasTexture)
            {
                // ケース2: 不透明度 = 1.0、テクスチャあり → AlphaClip
                SetMaterialAlphaClip(material, settings.AlphaCutoff);
            }
            // ケース3: 不透明度 = 1.0、テクスチャなし → Opaque, AlphaClip=OFF（何もしない）

            // その他のプロパティ
            if (material.HasProperty("_Smoothness"))
            {
                // PMXのSpecularPowerを0-1に正規化
                float smoothness = Mathf.Clamp01(pmxMat.SpecularPower / 100f);
                material.SetFloat("_Smoothness", smoothness);
            }

            // テクスチャを設定
            string baseDir = GetBaseDirectory(document.FilePath);

            // メインテクスチャ（BaseMap）
            if (!string.IsNullOrEmpty(pmxMat.TexturePath))
            {
                var texture = LoadTexture(pmxMat.TexturePath, baseDir);
                if (texture != null)
                {
                    SetMaterialTexture(material, "_BaseMap", "_MainTex", texture);
                    //Debug.Log($"[PMXImporter] Loaded texture: {pmxMat.TexturePath}");
                }
            }

            // スフィアテクスチャ（使用する場合）
            // TODO: スフィアマップ対応（必要に応じて）

            return material;
        }

        /// <summary>
        /// マテリアルを透過モードに設定（URP/Standard両対応）
        /// </summary>
        private static void SetMaterialTransparent(Material material)
        {
            // URP Lit用設定
            if (material.HasProperty("_Surface"))
            {
                material.SetFloat("_Surface", 1); // 0=Opaque, 1=Transparent
                material.SetOverrideTag("RenderType", "Transparent");
            }
            if (material.HasProperty("_Blend"))
            {
                material.SetFloat("_Blend", 0); // 0=Alpha, 1=Premultiply, 2=Additive, 3=Multiply
            }
            if (material.HasProperty("_AlphaClip"))
            {
                material.SetFloat("_AlphaClip", 0);
            }
            if (material.HasProperty("_SrcBlend"))
            {
                material.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
            }
            if (material.HasProperty("_DstBlend"))
            {
                material.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            }
            if (material.HasProperty("_SrcBlendAlpha"))
            {
                material.SetFloat("_SrcBlendAlpha", (float)UnityEngine.Rendering.BlendMode.One);
            }
            if (material.HasProperty("_DstBlendAlpha"))
            {
                material.SetFloat("_DstBlendAlpha", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            }
            if (material.HasProperty("_ZWrite"))
            {
                material.SetFloat("_ZWrite", 0);
            }

            // Standard Shader用設定
            if (material.HasProperty("_Mode"))
            {
                material.SetFloat("_Mode", 3); // 0=Opaque, 1=Cutout, 2=Fade, 3=Transparent
            }

            // レンダーキュー設定
            material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;

            // キーワード設定（URP）
            material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");

            // Standard Shader用キーワード
            material.EnableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHATEST_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        }

        /// <summary>
        /// マテリアルをアルファクリップモードに設定（URP/Standard両対応）
        /// Opaque + AlphaTest で、しきい値以下のピクセルを切り抜く
        /// </summary>
        private static void SetMaterialAlphaClip(Material material, float cutoff)
        {
            if (material.HasProperty("_AlphaClip"))
            {
                material.SetFloat("_AlphaClip", 1f);
                material.EnableKeyword("_ALPHATEST_ON");
            }
            if (material.HasProperty("_Cutoff"))
            {
                material.SetFloat("_Cutoff", cutoff);
            }
        }

        /// <summary>
        /// CSVファイルのディレクトリを取得
        /// </summary>
        private static string GetBaseDirectory(string filePath)
        {
            if (string.IsNullOrEmpty(filePath))
                return "";

            return Path.GetDirectoryName(filePath);
        }

        /// <summary>
        /// テクスチャパスを絶対パスに解決（SourceTexturePath保存用）
        /// </summary>
        private static string ResolveTextureFullPath(string texturePath, string baseDir)
        {
            if (string.IsNullOrEmpty(texturePath)) return null;

            string normalized = texturePath.Replace('\\', '/');
            if (Path.IsPathRooted(normalized)) return normalized;

            if (!string.IsNullOrEmpty(baseDir))
            {
                try { return Path.GetFullPath(Path.Combine(baseDir, normalized)).Replace('\\', '/'); }
                catch { return normalized; }
            }
            return normalized;
        }

        /// <summary>
        /// テクスチャを読み込み
        /// </summary>
        private static Texture2D LoadTexture(string texturePath, string baseDir)
        {
            if (string.IsNullOrEmpty(texturePath))
                return null;

            // パス区切り文字を正規化（\ → /）
            string normalizedPath = texturePath.Replace('\\', '/');
            string normalizedBaseDir = baseDir?.Replace('\\', '/') ?? "";

            // 実際のファイルパスを構築
            string fullPath;
            if (Path.IsPathRooted(normalizedPath))
            {
                fullPath = normalizedPath;
            }
            else
            {
                if (!string.IsNullOrEmpty(normalizedBaseDir))
                {
                    fullPath = Path.Combine(normalizedBaseDir, normalizedPath).Replace('\\', '/');
                }
                else
                {
                    fullPath = normalizedPath;
                }
            }

            // アセットパスを構築（Assets/から始まる形式）
            string assetPath = fullPath;
            bool isInsideAssets = false;
            if (!assetPath.StartsWith("Assets/"))
            {
                int assetsIdx = assetPath.IndexOf("/Assets/", StringComparison.OrdinalIgnoreCase);
                if (assetsIdx >= 0)
                {
                    assetPath = assetPath.Substring(assetsIdx + 1);
                    isInsideAssets = true;
                }
                else
                {
                    assetsIdx = assetPath.IndexOf("Assets/", StringComparison.OrdinalIgnoreCase);
                    if (assetsIdx >= 0)
                    {
                        assetPath = assetPath.Substring(assetsIdx);
                        isInsideAssets = true;
                    }
                }
            }
            else
            {
                isInsideAssets = true;
            }

            // 1. まずEditorBridge経由でAssetDatabaseから読み込みを試す
            Texture2D texture = null;
            if (isInsideAssets)
            {
                texture = Poly_Ling.EditorBridge.PLEditorBridge.I.LoadAssetAtPath<Texture2D>(assetPath);
            }

            // 2. Assets内の場合のみ、同じbaseDir内でファイル名検索
            if (texture == null && isInsideAssets)
            {
                string fileName = Path.GetFileName(normalizedPath);
                string fileNameWithoutExt = Path.GetFileNameWithoutExtension(fileName);

                // baseDirをAssets/形式に変換
                string searchFolder = normalizedBaseDir;
                if (!searchFolder.StartsWith("Assets/"))
                {
                    int idx = searchFolder.IndexOf("Assets/", StringComparison.OrdinalIgnoreCase);
                    if (idx >= 0)
                    {
                        searchFolder = searchFolder.Substring(idx);
                    }
                }

                string[] guids = Poly_Ling.EditorBridge.PLEditorBridge.I.FindAssets($"t:Texture2D {fileNameWithoutExt}",
                    new[] { searchFolder });
                foreach (var guid in guids)
                {
                    string foundPath = Poly_Ling.EditorBridge.PLEditorBridge.I.GUIDToAssetPath(guid);
                    if (Path.GetFileName(foundPath).Equals(fileName, StringComparison.OrdinalIgnoreCase))
                    {
                        texture = Poly_Ling.EditorBridge.PLEditorBridge.I.LoadAssetAtPath<Texture2D>(foundPath);
                        if (texture != null)
                        {
                            //Debug.Log($"[PMXImporter] Texture found in baseDir: {foundPath}");
                            break;
                        }
                    }
                }
            }

            // 3. それでも失敗した場合、File.ReadAllBytesで直接読み込み
            if (texture == null && File.Exists(fullPath))
            {
                try
                {
                    byte[] fileData = File.ReadAllBytes(fullPath);
                    texture = new Texture2D(2, 2);
                    if (texture.LoadImage(fileData))
                    {
                        texture.name = Path.GetFileNameWithoutExtension(fullPath);
                        //Debug.Log($"[PMXImporter] Texture loaded from file: {fullPath}");
                    }
                    else
                    {
                        UnityEngine.Object.DestroyImmediate(texture);
                        texture = null;
                        //Debug.LogWarning($"[PMXImporter] Failed to load image data: {fullPath}");
                    }
                }
                catch// (System.Exception e)
                {
                    //Debug.LogWarning($"[PMXImporter] Failed to read texture file: {fullPath} - {e.Message}");
                }
            }

            if (texture == null)
            {
                //Debug.LogWarning($"[PMXImporter] Texture not found: {fullPath} (original: {texturePath})");
            }

            return texture;
        }

        /// <summary>
        /// マテリアルにテクスチャを設定
        /// </summary>
        private static void SetMaterialTexture(Material material, string urpPropertyName, string standardPropertyName, Texture texture)
        {
            if (material.HasProperty(urpPropertyName))
            {
                material.SetTexture(urpPropertyName, texture);
            }
            if (material.HasProperty(standardPropertyName))
            {
                material.SetTexture(standardPropertyName, texture);
            }
        }

        private static Shader FindBestShader()
        {
            string[] shaderNames = new[]
            {
                "Universal Render Pipeline/Lit",
                "Universal Render Pipeline/Simple Lit",
                "HDRP/Lit",
                "Standard",
                "Unlit/Color"
            };

            foreach (var name in shaderNames)
            {
                var shader = Shader.Find(name);
                if (shader != null)
                    return shader;
            }

            return Shader.Find("Standard");
        }

        private static void SetMaterialColor(Material material, Color color)
        {
            if (material.HasProperty("_BaseColor"))
                material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color"))
                material.SetColor("_Color", color);
        }

        private static Material CreateDefaultMaterial()
        {
            var shader = FindBestShader();
            var material = new Material(shader);
            material.name = "Default";
            SetMaterialColor(material, new Color(0.7f, 0.7f, 0.7f, 1f));
            return material;
        }

        // ================================================================
        // 座標変換
        // ================================================================

        /// <summary>
        /// 座標変換（スケール適用あり）
        /// </summary>
        public static Vector3 ConvertPosition(Vector3 pmxPos, PMXImportSettings settings)
        {
            return AxisFlipOps.Position(settings.Flip, pmxPos, settings.Scale);
        }

        /// <summary>
        /// 座標変換（スケールなし - 法線計算用）
        /// </summary>
        private static Vector3 ConvertPositionUnscaled(Vector3 pmxPos, PMXImportSettings settings)
        {
            return AxisFlipOps.Position(settings.Flip, pmxPos);
        }

        private static Vector3 ConvertNormal(Vector3 pmxNormal, PMXImportSettings settings)
        {
            return AxisFlipOps.Normal(settings.Flip, pmxNormal);
        }

        private static Vector2 ConvertUV(Vector2 pmxUV, PMXImportSettings settings)
        {
            if (settings.FlipUV_V)
                return new Vector2(pmxUV.x, 1f - pmxUV.y);
            return pmxUV;
        }

        // ================================================================
        // MaterialGroupInfo 構築
        // ================================================================

        /// <summary>
        /// 材質グループから MaterialGroupInfo を構築
        /// </summary>
        private static MaterialGroupInfo BuildMaterialGroupInfo(
            List<string> materialNames,
            Dictionary<string, List<PMXFace>> materialToFaces,
            int meshIndex)
        {
            var info = new MaterialGroupInfo
            {
                MaterialNames = new List<string>(materialNames)
            };

            // グループ内の全面から使用頂点を収集
            foreach (var matName in materialNames)
            {
                if (materialToFaces.TryGetValue(matName, out var faces))
                {
                    foreach (var face in faces)
                    {
                        info.UsedVertexIndices.Add(face.VertexIndex1);
                        info.UsedVertexIndices.Add(face.VertexIndex2);
                        info.UsedVertexIndices.Add(face.VertexIndex3);
                    }
                }
            }

            // PMX頂点インデックス → ローカルインデックス のマッピングを構築
            // ConvertMaterialGroup と同じロジック
            var sortedIndices = info.UsedVertexIndices.OrderBy(x => x).ToList();
            for (int i = 0; i < sortedIndices.Count; i++)
            {
                info.PmxToLocalIndex[sortedIndices[i]] = i;
            }

            return info;
        }

        // ================================================================
        // モーフ変換
        // ================================================================

        /// <summary>
        /// PMXモーフをMeshContext + MorphExpressionに変換
        /// グループモーフ対応：
        /// 1. 頂点/UVモーフを仮MorphExpressionとして生成
        /// 2. グループモーフを読み、子モーフのMeshEntriesをweight付きでフラット展開した親MorphExpressionを作成
        /// 3. グループに属さない仮MorphExpressionはweight=1.0で正規のMorphExpressionにする
        /// </summary>
        /// <summary>
        /// PolyLingメタUVモーフ（__PLM_ プレフィックス）を適用する。
        /// 各MeshContextの頂点IDとUVサブインデックスを復元する。
        /// </summary>
        private static void ApplyPolyLingMetaMorphs(PMXDocument document, PMXImportResult result)
        {
            foreach (var pmxMorph in document.Morphs)
            {
                if (pmxMorph.MorphType != 3) continue;
                if (pmxMorph.Name?.StartsWith("__PLM_") != true) continue;

                // 対象MeshContextを特定（MaterialGroupInfoのPmxToLocalIndexで検索）
                foreach (var offset in pmxMorph.Offsets)
                {
                    if (offset is not PMXUVMorphOffset uvOffset) continue;

                    int pmxVertexIndex = uvOffset.VertexIndex;
                    int uvSubIndex = Mathf.RoundToInt(uvOffset.Offset.y);
                    int localIndex = Mathf.RoundToInt(uvOffset.Offset.z);
                    int vertexId = Mathf.RoundToInt(uvOffset.Offset.w);

                    // このPMX頂点インデックスが属するMeshContextを探す
                    for (int gi = 0; gi < result.MaterialGroupInfos.Count; gi++)
                    {
                        var groupInfo = result.MaterialGroupInfos[gi];
                        if (!groupInfo.PmxToLocalIndex.TryGetValue(pmxVertexIndex, out int mappedLocal)) continue;
                        // mappedLocalはインポート時に再構築されたローカルインデックス
                        // localIndexはエクスポート時のMeshObjectインデックス（一致するはず）

                        if (groupInfo.MeshContextIndex < 0 || groupInfo.MeshContextIndex >= result.MeshContexts.Count) break;
                        var meshContext = result.MeshContexts[groupInfo.MeshContextIndex];
                        if (meshContext?.MeshObject == null) break;
                        var meshObject = meshContext.MeshObject;

                        // 頂点IDを復元
                        if (mappedLocal < meshObject.VertexCount)
                        {
                            meshObject.Vertices[mappedLocal].Id = vertexId;
                            meshObject.RegisterVertexId(vertexId);
                        }

                        // 面コーナーのUVサブインデックスを復元
                        foreach (var face in meshObject.Faces)
                        {
                            for (int ci = 0; ci < face.VertexIndices.Count; ci++)
                            {
                                if (face.VertexIndices[ci] == mappedLocal)
                                {
                                    while (face.UVIndices.Count <= ci)
                                        face.UVIndices.Add(0);
                                    face.UVIndices[ci] = uvSubIndex;
                                }
                            }
                        }
                        break;
                    }
                }
            }
        }

        private static void ConvertMorphs(PMXDocument document, PMXImportSettings settings, PMXImportResult result)
        {
            if (result.MaterialGroupInfos.Count == 0)
            {
                Debug.LogWarning("[PMXImporter] No material group info available for morph conversion");
                return;
            }

            // Phase 1: 頂点/UVモーフを仮MorphExpressionとして生成
            // PMXモーフインデックス → 仮MorphExpression のマッピング
            var tempMorphExpressions = new Dictionary<int, MorphExpression>();

            for (int i = 0; i < document.Morphs.Count; i++)
            {
                var pmxMorph = document.Morphs[i];
                int beforeCount = result.MorphExpressions.Count;

                if (pmxMorph.MorphType == 1)
                {
                    ConvertVertexMorph(document, pmxMorph, settings, result);
                }
                else if (pmxMorph.MorphType >= 3 && pmxMorph.MorphType <= 7)
                {
                    // PolyLingメタモーフはApplyPolyLingMetaMorphsで処理するのでスキップ
                    if (pmxMorph.Name?.StartsWith("__PLM_") == true) continue;
                    ConvertUVMorph(document, pmxMorph, settings, result);
                }
                // ボーンモーフ(2)、マテリアルモーフ(8)等は未対応

                // 直前の呼び出しでMorphExpressionが追加された場合のみ記録
                if (result.MorphExpressions.Count > beforeCount)
                {
                    tempMorphExpressions[i] = result.MorphExpressions[result.MorphExpressions.Count - 1];
                }
            }

            // Phase 2: グループモーフを処理
            // グループに所属した仮MorphExpressionを追跡
            var groupedMorphIndices = new HashSet<int>();

            //Debug.Log($"[PMXImporter] Phase 1 complete: {tempMorphExpressions.Count} temp morph sets created, {result.MorphExpressions.Count} total morph sets");

            for (int i = 0; i < document.Morphs.Count; i++)
            {
                var pmxMorph = document.Morphs[i];
                if (pmxMorph.MorphType != 0) continue;  // グループモーフのみ

                //Debug.Log($"[PMXImporter] Processing group morph [{i}] '{pmxMorph.Name}': {pmxMorph.Offsets.Count} offsets");

                var groupSet = new MorphExpression(pmxMorph.Name, MorphType.Group)
                {
                    NameEnglish = pmxMorph.NameEnglish ?? "",
                    Panel = pmxMorph.Panel
                };

                foreach (var offset in pmxMorph.Offsets)
                {
                    if (offset is not PMXGroupMorphOffset groupOffset) continue;

                    int childMorphIndex = groupOffset.MorphIndex;

                    // 名前ベースのフォールバック（CSV入力でインデックスが-1の場合）
                    if (childMorphIndex < 0 && !string.IsNullOrEmpty(groupOffset.MorphName))
                    {
                        for (int j = 0; j < document.Morphs.Count; j++)
                        {
                            if (document.Morphs[j].Name == groupOffset.MorphName)
                            {
                                childMorphIndex = j;
                                break;
                            }
                        }
                    }

                    MorphExpression childSet = null;
                    bool found = childMorphIndex >= 0 && tempMorphExpressions.TryGetValue(childMorphIndex, out childSet);
                    if (!found)
                    {
                        string childName = (childMorphIndex >= 0 && childMorphIndex < document.Morphs.Count) 
                            ? document.Morphs[childMorphIndex].Name : "?";
                        int childType = (childMorphIndex >= 0 && childMorphIndex < document.Morphs.Count) 
                            ? document.Morphs[childMorphIndex].MorphType : -1;
                        //Debug.Log($"[PMXImporter]   Child [{childMorphIndex}] '{childName}' (type={childType}): NOT in tempMorphExpressions (tempKeys: {string.Join(",", tempMorphExpressions.Keys.Take(10))})");
                        continue;
                    }

                    float groupWeight = groupOffset.Weight;

                    // 子MorphExpressionのMeshEntriesを親にフラット展開（weight乗算）
                    foreach (var childEntry in childSet.MeshEntries)
                    {
                        groupSet.AddMesh(childEntry.MeshIndex, childEntry.Weight * groupWeight);
                    }

                    //Debug.Log($"[PMXImporter]   Child [{childMorphIndex}] '{childSet.Name}': {childSet.MeshEntries.Count} entries, weight={groupWeight}");
                    groupedMorphIndices.Add(childMorphIndex);
                }

                if (groupSet.MeshCount > 0)
                {
                    result.MorphExpressions.Add(groupSet);
                    //Debug.Log($"[PMXImporter] Group morph '{pmxMorph.Name}': {groupSet.MeshCount} meshes from {pmxMorph.Offsets.Count} children");
                }
            }

            // Phase 3: グループに属さない仮MorphExpressionはそのまま残す（weight=1.0で既に追加済み）
            // グループに属した仮MorphExpressionをresult.MorphExpressionsから除去
            if (groupedMorphIndices.Count > 0)
            {
                var groupedSets = new HashSet<MorphExpression>();
                foreach (var idx in groupedMorphIndices)
                {
                    if (tempMorphExpressions.TryGetValue(idx, out var set))
                        groupedSets.Add(set);
                }
                result.MorphExpressions.RemoveAll(s => groupedSets.Contains(s));

                //Debug.Log($"[PMXImporter] Removed {groupedSets.Count} child morph sets absorbed by group morphs");
            }
        }

        /// <summary>
        /// 頂点モーフを変換
        /// </summary>
        private static void ConvertVertexMorph(
            PMXDocument document,
            PMXMorph pmxMorph,
            PMXImportSettings settings,
            PMXImportResult result)
        {
            // 各MaterialGroupに対するオフセットを分類
            // key: MaterialGroupInfo のインデックス, value: (ローカル頂点Index, オフセット) のリスト
            var groupOffsets = new Dictionary<int, List<(int localIndex, Vector3 offset)>>();

            foreach (var offset in pmxMorph.Offsets)
            {
                if (offset is PMXVertexMorphOffset vertexOffset)
                {
                    int pmxVertexIndex = vertexOffset.VertexIndex;

                    // この頂点がどのグループに属するか検索
                    for (int gi = 0; gi < result.MaterialGroupInfos.Count; gi++)
                    {
                        var groupInfo = result.MaterialGroupInfos[gi];
                        if (groupInfo.PmxToLocalIndex.TryGetValue(pmxVertexIndex, out int localIndex))
                        {
                            if (!groupOffsets.ContainsKey(gi))
                                groupOffsets[gi] = new List<(int, Vector3)>();

                            // オフセットを座標変換
                            Vector3 convertedOffset = ConvertPosition(vertexOffset.Offset, settings);
                            groupOffsets[gi].Add((localIndex, convertedOffset));
                            break;  // 1つの頂点は1つのグループにのみ属する
                        }
                    }
                }
            }

            if (groupOffsets.Count == 0)
            {
                //Debug.LogWarning($"[PMXImporter] Vertex morph '{pmxMorph.Name}' has no valid offsets");
                return;
            }

            // MorphExpressionを作成
            var morphExpression = new MorphExpression(pmxMorph.Name, MorphType.Vertex)
            {
                NameEnglish = pmxMorph.NameEnglish ?? "",
                Panel = pmxMorph.Panel
            };

            // 影響する各グループについてモーフメッシュを作成
            foreach (var kvp in groupOffsets)
            {
                int groupIndex = kvp.Key;
                var offsets = kvp.Value;
                var groupInfo = result.MaterialGroupInfos[groupIndex];

                if (groupInfo.MeshContextIndex < 0 || groupInfo.MeshContextIndex >= result.MeshContexts.Count)
                    continue;

                var baseMesh = result.MeshContexts[groupInfo.MeshContextIndex];
                if (baseMesh?.MeshObject == null) continue;

                // メッシュをクローン
                var morphMesh = new MeshContext
                {
                    MeshObject = baseMesh.MeshObject.Clone(),
                    Type = MeshType.Morph,
                    IsVisible = false,  // モーフメッシュは非表示
                    ExcludeFromExport = true  // エクスポートから除外
                };
                morphMesh.MeshObject.Type = MeshType.Morph;  // MeshObject.Typeも設定（TypedMeshIndices用）
                morphMesh.MeshObject.Name = $"{baseMesh.Name}_{pmxMorph.Name}";
                morphMesh.Name = morphMesh.MeshObject.Name;

                // MorphBaseDataを設定（現在の位置を基準として保存）
                morphMesh.SetAsMorph(pmxMorph.Name);
                morphMesh.MorphPanel = pmxMorph.Panel;

                // オフセットを適用
                foreach (var (localIndex, offset) in offsets)
                {
                    if (localIndex < morphMesh.MeshObject.VertexCount)
                    {
                        morphMesh.MeshObject.Vertices[localIndex].Position += offset;
                    }
                }

                // Unity Meshを再構築
                morphMesh.UnityMesh = morphMesh.MeshObject.ToUnityMeshShared();
                morphMesh.UnityMesh.name = morphMesh.MeshObject.Name;
                morphMesh.UnityMesh.hideFlags = UnityEngine.HideFlags.HideAndDontSave;

                // 結果に追加
                int morphMeshIndex = result.MeshContexts.Count;
                result.MeshContexts.Add(morphMesh);
                morphExpression.AddMesh(morphMeshIndex);
            }

            if (morphExpression.MeshCount > 0)
            {
                result.MorphExpressions.Add(morphExpression);
            }
        }

        /// <summary>
        /// UVモーフを変換
        /// </summary>
        private static void ConvertUVMorph(
            PMXDocument document,
            PMXMorph pmxMorph,
            PMXImportSettings settings,
            PMXImportResult result)
        {
            // 各MaterialGroupに対するオフセットを分類
            var groupOffsets = new Dictionary<int, List<(int localIndex, Vector2 offset)>>();

            foreach (var offset in pmxMorph.Offsets)
            {
                if (offset is PMXUVMorphOffset uvOffset)
                {
                    int pmxVertexIndex = uvOffset.VertexIndex;

                    // この頂点がどのグループに属するか検索
                    for (int gi = 0; gi < result.MaterialGroupInfos.Count; gi++)
                    {
                        var groupInfo = result.MaterialGroupInfos[gi];
                        if (groupInfo.PmxToLocalIndex.TryGetValue(pmxVertexIndex, out int localIndex))
                        {
                            if (!groupOffsets.ContainsKey(gi))
                                groupOffsets[gi] = new List<(int, Vector2)>();

                            // UV オフセット（Vector4のXYのみ使用）
                            Vector2 uvOffsetValue = new Vector2(uvOffset.Offset.x, uvOffset.Offset.y);

                            // UV V反転設定に応じて調整
                            if (settings.FlipUV_V)
                                uvOffsetValue.y = -uvOffsetValue.y;

                            groupOffsets[gi].Add((localIndex, uvOffsetValue));
                            break;
                        }
                    }
                }
            }

            if (groupOffsets.Count == 0)
            {
                Debug.LogWarning($"[PMXImporter] UV morph '{pmxMorph.Name}' has no valid offsets");
                return;
            }

            // MorphTypeを決定
            MorphType morphType = pmxMorph.MorphType switch
            {
                3 => MorphType.UV,
                4 => MorphType.UV1,
                5 => MorphType.UV2,
                6 => MorphType.UV3,
                7 => MorphType.UV4,
                _ => MorphType.UV
            };

            // MorphExpressionを作成
            var MorphExpression = new MorphExpression(pmxMorph.Name, morphType)
            {
                NameEnglish = pmxMorph.NameEnglish ?? "",
                Panel = pmxMorph.Panel
            };

            // 影響する各グループについてモーフメッシュを作成
            foreach (var kvp in groupOffsets)
            {
                int groupIndex = kvp.Key;
                var offsets = kvp.Value;
                var groupInfo = result.MaterialGroupInfos[groupIndex];

                if (groupInfo.MeshContextIndex < 0 || groupInfo.MeshContextIndex >= result.MeshContexts.Count)
                    continue;

                var baseMesh = result.MeshContexts[groupInfo.MeshContextIndex];
                if (baseMesh?.MeshObject == null) continue;

                // メッシュをクローン
                var morphMesh = new MeshContext
                {
                    MeshObject = baseMesh.MeshObject.Clone(),
                    Type = MeshType.Morph,
                    IsVisible = false,
                    ExcludeFromExport = true
                };
                morphMesh.MeshObject.Type = MeshType.Morph;  // MeshObject.Typeも設定（TypedMeshIndices用）
                morphMesh.MeshObject.Name = $"{baseMesh.Name}_{pmxMorph.Name}";
                morphMesh.Name = morphMesh.MeshObject.Name;

                // MorphBaseDataを設定
                morphMesh.SetAsMorph(pmxMorph.Name);
                morphMesh.MorphPanel = pmxMorph.Panel;

                // UVオフセットを適用
                foreach (var (localIndex, uvOffset) in offsets)
                {
                    if (localIndex < morphMesh.MeshObject.VertexCount)
                    {
                        var vertex = morphMesh.MeshObject.Vertices[localIndex];
                        if (vertex.UVs.Count > 0)
                        {
                            vertex.UVs[0] += uvOffset;
                        }
                    }
                }

                // Unity Meshを再構築
                morphMesh.UnityMesh = morphMesh.MeshObject.ToUnityMeshShared();
                morphMesh.UnityMesh.name = morphMesh.MeshObject.Name;
                morphMesh.UnityMesh.hideFlags = UnityEngine.HideFlags.HideAndDontSave;

                // 結果に追加
                int morphMeshIndex = result.MeshContexts.Count;
                result.MeshContexts.Add(morphMesh);
                MorphExpression.AddMesh(morphMeshIndex);
            }

            if (MorphExpression.MeshCount > 0)
            {
                result.MorphExpressions.Add(MorphExpression);
            }
        }

        // ================================================================
        // 剛体・JOINT インポート（段階②）
        // ================================================================
        //
        // 【方針】
        //   剛体/JOINTを頂点ゼロの空 MeshObject（Type=RigidBody / RigidBodyJoint）
        //   ＋付帯POCO（RigidBodyData / JointData）として取り込み、ボーン・モーフと
        //   同様に result.MeshContexts へ追加する。形状はギズモとして利用時に生成し、
        //   ここではジオメトリを持たせない（Drawableカテゴリ外のためGPU構築に入らない）。
        //
        // 【参照系：name主・index従】
        //   剛体→関連ボーン：RelatedBoneName（PMXReaderで解決済み）。BoneIndexはPMX
        //   ボーンindexで、ボーンを先頭に追加する本インポータでは MeshContextList の
        //   ボーンindexと一致する。
        //   JOINT→剛体A/B：BodyAName/BodyBName（解決済み）。indexは
        //   「剛体コンテキスト開始index ＋ PMX剛体index」で MeshContextList 上に解決する。
        //
        // 【座標変換】
        //   位置：ConvertPosition（×Scale ＋ FlipZ で z=-z）。頂点・ボーンと同一。
        //   回転：ConvertEulerRotation（PMX Euler(rad)→Quaternion→FlipZ共役→Euler(rad)）。
        //   サイズ：×Scale のみ（範囲量のためZ反転しない）。
        //   質量・減衰・反発・摩擦・Group・Mask・JointType・各min/max・Spring：生値。
        //   （JOINTのmin/max・SpringのFlipZ軸入替えは段階③エクスポート整合と併せて扱う）
        // ----------------------------------------------------------------

        /// <summary>剛体をMeshContext（Type=RigidBody）に変換して追加する。</summary>
        private static void ConvertRigidBodies(PMXDocument document, PMXImportSettings settings, PMXImportResult result)
        {
            foreach (var body in document.RigidBodies)
            {
                // 頂点/面を持たない空MeshObject（ボーンと同形）
                var meshObject = new MeshObject(body.Name)
                {
                    Type = MeshType.RigidBody
                };

                meshObject.RigidBodyData = new RigidBodyData
                {
                    NameEnglish     = body.NameEnglish ?? "",
                    RelatedBoneName = body.RelatedBoneName ?? "",
                    // ボーンを先頭に追加する本インポータでは PMXボーンindex == MeshContextListボーンindex
                    BoneIndex       = body.BoneIndex,
                    Group           = body.Group,
                    CollisionMask   = body.CollisionMask,
                    Shape           = (RigidBodyShape)body.Shape,
                    Size            = body.Size * settings.Scale,
                    Position        = ConvertPosition(body.Position, settings),
                    Rotation        = ConvertEulerRotation(body.Rotation, settings),
                    Mass            = body.Mass,
                    LinearDamping   = body.LinearDamping,
                    AngularDamping  = body.AngularDamping,
                    Restitution     = body.Restitution,
                    Friction        = body.Friction,
                    PhysicsMode     = (RigidBodyPhysicsMode)body.PhysicsMode
                };

                // MeshContextでラップ（MeshObjectを先に設定 → Name/Type委譲が成立）
                var meshContext = new MeshContext
                {
                    MeshObject = meshObject,
                    Name       = body.Name,
                    Type       = MeshType.RigidBody,
                    IsVisible  = true
                };

                result.MeshContexts.Add(meshContext);
            }
        }

        /// <summary>
        /// ジョイントをMeshContext（Type=RigidBodyJoint）に変換して追加する。
        /// </summary>
        /// <param name="rigidBodyContextBase">
        /// 剛体コンテキストの開始index（MeshContextList上）。-1=剛体未インポート。
        /// </param>
        private static void ConvertJoints(PMXDocument document, PMXImportSettings settings, PMXImportResult result, int rigidBodyContextBase)
        {
            foreach (var joint in document.Joints)
            {
                var meshObject = new MeshObject(joint.Name)
                {
                    Type = MeshType.RigidBodyJoint
                };

                // 剛体A/BのMeshContextList index（剛体未インポート時は-1のまま）
                int idxA = (rigidBodyContextBase >= 0 && joint.RigidBodyIndexA >= 0)
                    ? rigidBodyContextBase + joint.RigidBodyIndexA : -1;
                int idxB = (rigidBodyContextBase >= 0 && joint.RigidBodyIndexB >= 0)
                    ? rigidBodyContextBase + joint.RigidBodyIndexB : -1;

                meshObject.JointData = new JointData
                {
                    NameEnglish       = joint.NameEnglish ?? "",
                    JointType         = joint.JointType,
                    BodyAName         = joint.BodyAName ?? "",
                    BodyBName         = joint.BodyBName ?? "",
                    RigidBodyIndexA   = idxA,
                    RigidBodyIndexB   = idxB,
                    Position          = ConvertPosition(joint.Position, settings),
                    Rotation          = ConvertEulerRotation(joint.Rotation, settings),
                    TranslationMin    = joint.TranslationMin,
                    TranslationMax    = joint.TranslationMax,
                    RotationMin       = joint.RotationMin,
                    RotationMax       = joint.RotationMax,
                    SpringTranslation = joint.SpringTranslation,
                    SpringRotation    = joint.SpringRotation
                };

                var meshContext = new MeshContext
                {
                    MeshObject = meshObject,
                    Name       = joint.Name,
                    Type       = MeshType.RigidBodyJoint,
                    IsVisible  = true
                };

                result.MeshContexts.Add(meshContext);
            }
        }

        /// <summary>
        /// PMXのオイラー角回転（ラジアン）をモデル空間のオイラー角（ラジアン）へ変換する。
        ///
        /// ■ ボーン基底とは別扱いであること（注意）
        ///   剛体・JOINT の回転は「その物体の姿勢」であり、ボーンの局所軸ラベルでは
        ///   ないため、共役変換 S·R·S（AxisFlipOps.EulerRad）のままで正しい。
        ///   ボーン側は局所軸の合成そのものを廃止した（BoneModelRotation は恒等）。
        ///   こちらは追随させない。両者を同一視した旧コメントは誤りだった。
        /// 入力/出力ともラジアン。
        /// </summary>
        private static Vector3 ConvertEulerRotation(Vector3 pmxEulerRad, PMXImportSettings settings)
        {
            return AxisFlipOps.EulerRad(settings.Flip, pmxEulerRad);
        }
    }
}